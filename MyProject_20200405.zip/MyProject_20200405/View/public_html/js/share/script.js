//---Turn off ctrl+n       20160610  
var fields;
var isInIframe ;
$(function()
{
	$(document).on("keydown", function (e) { 
      //alert(e.which);
       if ((e.which === 8 && !$(e.target).is("input, textarea"))  // Backspace
            ||(e.ctrlKey && e.keyCode == 78)  // ctrl+n
            ||(e.keyCode == 116)   // f5
            ||(e.keyCode == 27)   // esc
            ) 
       {  
           e.preventDefault(); 
       } 
   });
	
	$(document).on("contextmenu",function(e){
        if(!$(e.target).is("input, textarea"))
             e.preventDefault();
   });
   
    isInIframe = (window.location != window.parent.location) ? true : false;
    //================PACO============ //        
    
   $('form.form-horizontal.form-sm').scroll(function()
   {
      $('.datepicker').remove();
   });
   //=============//
   $("#bodyright").append("<div id='loader' align='center'><div class=\"card border-light\" style=\"margin-bottom: 5px;\"><div class=\"card-header\"><h3 class=\"card-title\">&nbsp;<\/div><div class='card-body well' style=\"margin-bottom: 0px; padding-bottom: 0px;\"><span class='glyphicon glyphicon-refresh spinning'><\/span> Loading...<br\/><br\/><\/div><\/div><\/div>");
   if(isInIframe==false)
   {
      //==========Keep status of menu before go out of the page=============//
       $(window).on('beforeunload ',function() {
           localStorage.NotOnly = 0;//reset duplicate checker before go out of page
           //alert(localStorage.checkSideMenu);
           
           //alert(window.GlobalSideMenuStatus);
           localStorage.SideMenuStatus = (window.GlobalSideMenuStatus)?1:0;        
       });
       //==================//
      window.GlobalSideMenuStatus = true;
   
   
      $("#menu-toggle").click(function()
      {
      //alert("toggle : click");
         $('#wrapper').toggleClass('toggle');
         if (window.GlobalSideMenuStatus == false)
         {
         //alert(document.getElementById("bodyright").style.width);
         setTimeout(function()
            {
               document.getElementById("bodyright").style.minHeight = "100%";
               document.getElementById("bodyright").style.minWidth = "100%";
            }, 400);
            //document.getElementById("bodyright").style.width= "1024px";
            /*setTimeout(function()
            {
               //document.getElementById("bodyright").style.minHeight = "100%";
               //document.getElementById("bodyright").style.minWidth = "100%";
               $("table").each(function(object)
               {
                  var vaGridId = $(this).attr('id');
                  
                  if (vaGridId != null)
                  {
                     if (vaGridId.indexOf('masterGridDetail') != -1)
                     {
                        $("#" + vaGridId).setGridWidth($("#form_body").width() - 70);
                     }
                     else if (vaGridId.indexOf('masterGrid') != -1)
                     {
                     //alert(vaGridId);
                        $("#" + vaGridId).setGridWidth($("#form_body").width() - 40);
                     }
                  }
               });
   
            }, 400);*/
            setTimeout(resizeGrid, 350);
   
            window.GlobalSideMenuStatus = true;
            if (window.matchMedia('(max-width: 768px)').matches)
            {
               $("#form_body").hide("fast", function()
               {
                  $("html,body").animate(
                  {
                     scrollTop: 0
                  }, "fast");
                  $("html,body").animate(
                  {
                     scrollTop: 1
                  }, "fast");
                  $("html,body").animate(
                  {
                     scrollTop: 0
                  }, "fast");
                  $("#form_body").show();
               });
            }
         }
         else
         {
            //document.getElementById("bodyright").style.width= "704px";
            document.getElementById("bodyright").style.minHeight = "0";
            document.getElementById("bodyright").style.minWidth = "0";
            /*setTimeout(function()
            {
               //$("#masterGrid").setGridWidth($("#form_body").width() - 40);
               $("table").each(function(object)
               {
                  var vaGridId = $(this).attr('id');
                  if (vaGridId != null)
                  {
                     if (vaGridId.indexOf('masterGridDetail') != -1)
                     {
                        $("#" + vaGridId).setGridWidth($("#form_body").width() - 70);
                     }
                     else if (vaGridId.indexOf('masterGrid') != -1)
                     {
                        $("#" + vaGridId).setGridWidth($("#form_body").width() - 40);
                     }
                  }
               });
            }, 400);*/
            setTimeout(resizeGrid, 350);
            //alert("set false");
            window.GlobalSideMenuStatus = false;
            if (window.matchMedia('(max-width: 768px)').matches)
            {
               $("#form_body").hide("fast", function()
               {
                  $("html,body").animate(
                  {
                     scrollTop: 0
                  }, "fast");
                  $("html,body").animate(
                  {
                     scrollTop: 1
                  }, "fast");
                  $("html,body").animate(
                  {
                     scrollTop: 0
                  }, "fast");
                  $("#form_body").show();
               });
            }
         }
         //document.getElementById("bodyright").style.width="1300px"; //$(window).width(); 
      });
   }
   $('#menu_collapse').collapse(
   {
      toggle: true
   });
   $("#demo1").navgoco(
   {
      caret: '<span class="caret"><\/span>',
      accordion: false,
      openClass: 'open',
      save: true,
      cookie:
      {
         name: 'navgoco',
         expires: false,
         path: '/'
      },
      slide:
      {
         duration: 400,
         easing: 'swing'
      }
   });
   $("#collapseAll").click(function(e)
   {
      e.preventDefault();
      $("#demo1").navgoco('toggle', false);
   });
   $("#expandAll").click(function(e)
   {
      e.preventDefault();
      $("#demo1").navgoco('toggle', true);
      // Show|Hide sub-menus with specific indexes
      // It will also open parent sub-menus since v0.1.2      
      //$("#demo1").navgoco('toggle', true, 1, 2, 4);
   });

   /*setTimeout(function()
   {
      $("table").each(function(object)
      {
         var vaGridId = $(this).attr('id');
         if (vaGridId != null)
         {
            if (vaGridId.indexOf('masterGridDetail') != -1)
            {
               $("#" + vaGridId).setGridWidth($("#form_body").width() - 70);
            }
            else if (vaGridId.indexOf('masterGrid') != -1)
            {
               $("#" + vaGridId).setGridWidth($("#form_body").width() - 40);
            }
         }
      });

   }, 400);*/
   setTimeout(resizeGrid, 350);

   $(window).bind('resize', function()
   {
      //$("#masterGrid").setGridWidth($("#form_body").width() - 20);
      /*$("table").each(function(object)
      {
         var vaGridId = $(this).attr('id');
         if (vaGridId != null)
         {
            if (vaGridId.indexOf('masterGridDetail') != -1)
            {
               $("#" + vaGridId).setGridWidth($("#form_body").width() - 70);
            }
            else if (vaGridId.indexOf('masterGrid') != -1)
            {
               $("#" + vaGridId).setGridWidth($("#form_body").width() - 40);
            }
         }
      });*/
      $('.modal:visible').each(setModalCenter);
      resizeGrid();
   }).trigger('resize');


   //$("body").attr("onload", "firstLoad();afterLoad();");
   if ($("body").attr("onload") != undefined && $("body").attr("onload").indexOf('firstLoad') != -1)
   {
      $("body").attr("onload", "firstLoad();afterLoad();");
   }
   
   $( "#OPNSRH" ).click(function() {
   // alert("opnsrh423");
    setAutoTabForm();
});

 
   //setModalCenter();
   $(document).on('show.bs.modal', '.modal', setModalCenter);
   
   //---------- แก้ไขเรื่อง date picker ----------
   $('.date-picker').datepicker({
      language:'th-th'
      , autoclose : true
      , todayBtn : true
      , todayHighlight : true
      , format: "dd/mm/yyyy"
      //, clearBtn: true
   }).off('focus');
   //-------------- date picker ---------------
	
	//---------- แก้ไขเรื่องลบ Session ตอนกดปุ่มกากบาท Close Window ----------
	window.onbeforeunload = logoutByCloseWindow;
   $(window).on('mouseover', (function () {
       window.onbeforeunload = null;
   }));
   $(window).on('mouseout', (function () {
       window.onbeforeunload = logoutByCloseWindow;
   }));
   
    jQuery('form').submit(function() {
       window.onbeforeunload = null;
   });
   
   var prevKey="";
   $(document).keydown(function (e) {            
       if (e.key=="F5") {
           window.onbeforeunload = logoutByCloseWindow;
       }
       else if (e.key.toUpperCase() == "W" && prevKey == "CONTROL") {                
           window.onbeforeunload = logoutByCloseWindow;   
       }
       else if (e.key.toUpperCase() == "R" && prevKey == "CONTROL") {
           window.onbeforeunload = logoutByCloseWindow;
       }
       else if (e.key.toUpperCase() == "F4" && (prevKey == "ALT" || prevKey == "CONTROL")) {
           window.onbeforeunload = logoutByCloseWindow;
       }
       prevKey = e.key.toUpperCase();
       
      // alert(prevKey);
   });
});

/*function setModalCenter()
{
   $('.modal').attr('data-backdrop', 'static');//click outside not colse modal
   $('.modal').on('show.bs.modal', function () {
         $('.modal').each(function () {
        var t = $(this),
            d = t.find('.modal-dialog'),
            fadeClass = (t.is('.fade') ? 'fade' : '');
        // render dialog
        t.removeClass('fade')
            .addClass('invisible')
            .css('display', 'block');
        // read and store dialog height
        d.data('height', d.height());
        // hide dialog again
        t.css('display', '')
            .removeClass('invisible')
            .addClass(fadeClass);
    });
    
        var t = $(this),
            d = t.find('.modal-dialog'),
            dh = d.data('height'),
            //dh = d.height(),
            w = $(window).width(),
            h = $(window).height();
        // if it is desktop & dialog is lower than viewport
        // (set your own values)
        //alert("h="+h+"     dh="+dh);
        if (w > 380 && (dh + 60) < h) {
            d.css('margin-top', Math.round(0.96 * (h - dh) / 2));
        } else {
            d.css('margin-top', '');
        }
    });
}*/

function setModalCenter()
{
   $(this).css('display', 'block');
   var $dialog  = $(this).find(".modal-dialog"),
   offset       = ($(window).height() - $dialog.height()) / 2,
   bottomMargin = parseInt($dialog.css('marginBottom'), 10);
   
   // Make sure you don't hide the top part of the modal w/ a negative margin if it's longer than the screen height, and keep the margin equal to the bottom margin of the modal
   if(offset < bottomMargin) offset = bottomMargin;
   $dialog.css("margin-top", offset);
}

function setAutoTabForm()
{
   fields = $("form[name!=frmMenu] :input:visible:not([readonly]):enabled");
   fields.each(function(i)
   {

      $(this).off("keyup.tab");
      $(this).off("keydown.tab");
      $(this).on("keyup.tab", function(e)
      {
         //alert($(this).attr('id'));
         //alert(e.keyCode);
         if ((e.keyCode != 9 && e.keyCode != 16 && e.keyCode != 37 
            && e.keyCode != 38 && e.keyCode != 39 && e.keyCode != 40
            && e.keyCode != 45 && e.keyCode != 46 && e.keyCode != 8) 
            && $(this).val().length >= $(this).attr('maxlength'))
         {

            var index = fields.index(this);

            $('.datepicker').remove();
            if (index > -1 && (index + 1) < fields.length)
            {
               fields.eq(index + 1).focus();
            }
         }
      });

      $(this).on("keydown.tab", function(e)
      {
         if (e.keyCode == 9 && e.shiftKey == true)
         {
            var index = fields.index(this);
            $('.datepicker').remove();
            if (index == 0)
            {
               e.preventDefault();
               fields[fields.length - 1].focus();
            }
         }
         else if (e.keyCode == 9 && e.shiftKey == false)
         {
            var index = fields.index(this);
            $('.datepicker').remove();
            if (index == fields.length - 1)
            {
               e.preventDefault();
               fields[0].focus();
            }
         }

      });
   });
   //$(":input[readonly]").attr("tabindex", "-1");
   $(":input").not("select.select2-offscreen").removeAttr("tabindex");
   $(":input[readonly]").attr("tabindex", "-1");
}

function afterLoad()
{
   //alert("in afterload(404)");
   //$("#loadingPage").hide();
   //$("#displayPage").show();
   //$("#form_body div:nth-child(2)").show();
   //$("#firstLoadPage").remove();
   //$.when(firstLoad()).then(afterLoad());

   setAutoTabForm();
   //$.when(firstLoad()).then(afterLoad());
   setTimeout(function()
   {
      /*$("#loader").fadeOut(function(){
        setTimeout(function(){
            setSideMenu();
        },1);
          
      });   */
     // alert("loader fadeout(421)");
      $("#loader").fadeOut();
   }, 1000);
   setTimeout(function()
   {
            setSideMenu();
               
   }, 100);
   
   ReloadDOMEvent();
   adjustForm();
   overridCreateGrid();
  /*setTimeout(function(){
            setSideMenu();
        },1);*/
   //=====================Paco========================//
    
    //==============================================//
}

function ReloadDOMEvent()
{
   $("#reloading").bind("DOMSubtreeModified", function()
   {
      if (window.matchMedia('(max-width: 768px)').matches)
      {
        //alert("443 The screen is less than, or equal to, 768 pixels wide");
      }
      else
      {
         adjustForm();
      }

   });
}

function adjustForm()
{
   if (window.matchMedia('(max-width: 768px)').matches)
   {
        //alert("457 The screen is less than, or equal to, 768 pixels wide");
   }
   else
   {
      if ($("#reloading").html() != "")
      {
         $("form.form-horizontal.form-sm").css("max-height", "100vh").css("max-height", "-=125px").css("max-height", "-=" + $("#reloading").height() + "px");
      }
      else
      {
         $("form.form-horizontal.form-sm").css("max-height", "100vh").css("max-height", "-=125px");
      }
   }

}

$(window).resize(function()
{
   if ($("#menu_collapse").is(":visible"))
   {
      $("#reloading").css("margin-top", "auto");
   }
   else
   {
      if ($(window).scrollTop() < $(".card-header:first").outerHeight())
      {
         $("#reloading").css("position", "static");
         $("#reloading").css("margin-top", "45px");
      }
      else
      {
         $("#reloading").css("margin-top", "auto");
      }
   }
   if ($("#form_body").height() + $("#form_body").offset().top + 1 > $(window).height())
   {
      $("form.form-horizontal.form-sm").css("max-height", $("#form_body").height() - 100);
   }
   else
   {
      adjustForm();
   }

   if (window.matchMedia('(max-width: 768px)').matches)
   {
      $("#reloading").css("position", "relative");
      $("#reloading").css("top", "auto");

   }
   else
   {
      $("#reloading").css("position", "relative");
      $("#reloading").css("top", "auto");
      $("#reloading").css("margin-top", "auto");
      adjustForm();
   }
});
//Short Hand of document.ready!!!!!! use it carefully
$(function(){
//    $( window ).unload(function() {
//      return "Bye now!";
//    });

   
});



$(window).scroll(function()
{   
   if (window.matchMedia('(max-width: 768px)').matches)
   {

      var repos = $("#form_body").offset().top - $("#reloading").outerHeight() - $(".card-header:first").outerHeight() - 5;
      if ($("#menu_collapse").is(":visible"))
      {
         $("#reloading").css("margin-top", "auto");
         if (($(".card-header:first").offset().top + $(".card-header:first").outerHeight() >= $("#reloading").offset().top) && !($(window).scrollTop() <= repos) && $(window).scrollTop() != 0)
         {

            $("#reloading").css("position", "fixed");
            $("#reloading").css("top", $(".card-header:first").outerHeight());
         }
         else
         {
            $("#reloading").css("position", "relative");
            $("#reloading").css("top", "auto");
         }
      }
      else
      {
         if ($(window).scrollTop() == 0)
         {
            $("#reloading").css("position", "static");
            $("#reloading").css("margin-top", "45px");
         }
         else
         {
            $("#reloading").css("margin-top", "auto");
            $("#reloading").css("position", "fixed");
            $("#reloading").css("top", $(".card-header:first").outerHeight());
         }
      }

   }
});

function overridCreateGrid()
{
   try
   {
      (function()
      {
         var oldVersion = createGrid;
         createGrid = function()
         {
            // do some stuff
            var result = oldVersion.apply(this, arguments);
            // do some more stuff
            setTimeout(function()
            {
               $("#masterGrid").setGridWidth(parseInt($("#barSearch").width()+35));
            }, 330);
   
            $(window).bind('resize', function()
            {
               $("#masterGrid").setGridWidth($("#barSearch").width()+35);
            });
            return result;
         };
      })();
   }
   catch(e)
   {
      //console.log("No Grid");
   }
   
}
//=============Paco====================//
function setSideMenu()
{
   if(isInIframe)
   {
      return false;
   }
     //(window.localStorage.SideMenuStatus == 1)?false:true
   var status = localStorage.SideMenuStatus            
   if(localStorage.checkSideMenu == null)
   {
     status = 1;
     localStorage.checkSideMenu = 0;
     window.GlobalSideMenuStatus = false;
   }
   var focused = $(':focus');
     //$('#menu_collapse').collapse('toggle');
     //status=true;
   //alert("setSideMenu : "+status+"       window.GlobalSideMenuStatus : "+window.GlobalSideMenuStatus+"    isInIframe:"+isInIframe);
   if(status == 1)
   {          
   }
   else if(status == 0 && window.GlobalSideMenuStatus)
   {        
     $('#toggle').click();   
   }      
   
   focused.focus();
  
   
}


function resizeGrid()
{
   $("table").each(function(object)
   {
      var vaGridId = $(this).attr('id');
      if (vaGridId != null)
      {
         if (vaGridId.indexOf('masterGridDetail') != -1)
         {
            $("#" + vaGridId).setGridWidth($("#form_body").width() - 70);
         }
         else if (vaGridId.indexOf('masterGrid') != -1)
         {
            $("#" + vaGridId).setGridWidth($("#form_body").width() - 40);
         }
         else if (vaGridId.indexOf('Graph') != -1)
         {
            //alert(vaGridId);
            //$("#" + vaGridId).setGridWidth($("#form_body").width() - 40);
            if($("#" + vaGridId).highcharts() != null)
            {
               $("#" + vaGridId).highcharts().setSize(parseInt($("#form_body").width()) - 40, '500', false);
            }
         }
      }
   });
}

function jqgridError(xhr,st,err)
{
   if(xhr.status == '408')// session time out
   {
      window.location = "../index.jsp?vaErrMsg=Session%20Time%20Out";
   }
}

function getContextPath() {
   return window.location.pathname.substring(0, window.location.pathname.indexOf("/",2));
}

function logoutByCloseWindow() {
   //alert(getContextPath()+'/SecurityServlet');
   var isInIFrame = (window.location != window.parent.location);
   if(isInIFrame==false)
   {
    jQuery.ajax({
        url: getContextPath()+'/SecurityServlet'
        , type: "POST"
        , async:false
        , cache:false
        , data:{
                  act : "Logout1"
                  //, screenId : $("#screenId").val()
               }
        , success:function(data)
                 {
                 
                 }
         , error:function()
                 {
                     //alert('error');
                 }
     });
   }
}