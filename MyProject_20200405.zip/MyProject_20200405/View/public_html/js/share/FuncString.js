// function for set
// 1. setFieldPattern(objectID, condition)
// parameter 
// - objectID : name of id object
// - condition : 7 digit (0 not used, 1 used)
//   1 english
//   2 thai
//   3 number
//   4 special charactor
//   5 white space
//   6 single quote
//   7 double quote
// Example.
// $("document").ready(function(){
//       setFieldPattern("englishName", "1010101");
// });
//
// function for onkeypress
// 1. setFieldPattern(event)
// Example.
//    $("#thaiName").on("keypress", function(e) {
//        return tnThSpaceOnly(e);
//    });
//------set
//1.
function setFieldPattern(objectID, condition) {

    var format = /^[0-1]{7}$/;
    var match = false;
    var conditionArray = null;
    
    var en = true; 
    var th = true; 
    var num = true; 
    var spchar = true; 
    var wspace = true; 
    var sgq = true; 
    var dbq = true;
    
    if(condition != undefined){
        match = condition.match(format);
        if(match != null){
            conditionArray = condition.split("");
            en = parseInt(conditionArray[0]);
            th = parseInt(conditionArray[1]);
            num = parseInt(conditionArray[2]); 
            spchar = parseInt(conditionArray[3]); 
            wspace = parseInt(conditionArray[4]); 
            sgq = parseInt(conditionArray[5]); 
            dbq = parseInt(conditionArray[6]);
        }else{
            alert(objectID+" : condition not format 1111111");
        }
    }
    
    
    //var paRegex = (en ? "A-Za-z" : "") + (th ? "ก-๙" : "") + (num ? "0-9" : "") + (spchar ? "-*/+=.()~%!@#$^&_{}\\[\\]:;?<>,|\\\\" : "") + (wspace ? "\\s" : "") + (sgq ? "\'" : "") + (dbq ? "\"" : "");
    //var paRegex = (en ? "A-Za-z" : "") + (th ? "ก-๙" : "") + (num ? "0-9" : "") + (spchar ? ".()-/$" : "") + (wspace ? "\\s" : "") + (sgq ? "\'" : "") + (dbq ? "\"" : "");
    var paRegex = (en ? "A-Za-z" : "") + (th ? "ก-๙" : "") + (num ? "0-9" : "") + (spchar ? ".()-/$@&" : "") + (wspace ? "\\s" : "") + (sgq ? "\'" : "") + (dbq ? "\"" : "");//Modified By Tunyakorn.ch 05/09/2560 -- กลุ่มสบน.ขอเพิ่มให้กรอก @ & ได้

    $("#" + objectID).on("keypress", function (e) {
        var vaRegex = new RegExp("[" + paRegex + "]", "g");
        return pressOnly(e, vaRegex);
    });

    $('#' + objectID).blur(function (e) {
        vaNotRegex = new RegExp("[^" + paRegex + "]", "g");
        var vaTmp = $(this).val().replace(vaNotRegex, '');
        $(this).val(vaTmp);
    });
}
// Description : Check E-Mail Address
function checkEmail(email) {
    var strVal = email;
    var emailFilter = /^.+@.+\..{2,3}$/;
    if (!(emailFilter.test(strVal)) && strVal.length != 0) {
        return false;
    }
    else {
        return true;
    }
}

//internal function for onkeypress
function pressOnly(e, paRegex) {
    var key;
    var keychar;
    var vaRegex = /[A-Za-z]/g;//default
    if (paRegex != undefined) {
        vaRegex = paRegex;
    }

    // Retrieving the key from the char code passed in event.which
    // For more info on even.which, look here: http://stackoverflow.com/q/3050984/114029
    if (window.event) {
        key = event.keyCode;
    }
    else if (e) {
		if(e.ctrlKey){
            return true;
        }
        key = e.which;
    }
    else {
        return true;
    }

    keychar = String.fromCharCode(key);
    // For the keyCodes, look here: http://stackoverflow.com/a/3781360/114029
    // keyCode == 0  is null character
    // keyCode == 8  is backspace
    // keyCode == 9  is Horizatal Tab
    // keyCode == 13 is Enter
    // keyCode == 27 is esc
    // vaRegex.test(key) does the matching, that is, test the key just typed against the regex pattern
    if (key == 0 || key == 8 || key == 9 || key == 13 || key == 27 || vaRegex.test(keychar)) {
        return true;
    }

    // If we got this far, just return false because a disallowed key was typed.
    return false;
}

// Description : Trim all spaces
function removeString(strVal, strRmv) {
    var tstring = "";
    string = strVal;
    string = '' + string;
    splitstring = string.split(strRmv);
    for (i = 0;i < splitstring.length;i++)
        tstring += splitstring[i];
    strVal = tstring;
    return (strVal);
}

// Description : Fill '0' : ��� '0' ŧ� obj
function fillString(strVal, charVal, a) {
    if (strVal.length == 0) {
        strVal = "";
    }
    else {
        a = a - strVal.length;
        for (i = 0;i < a;i++)
            strVal = charVal + strVal;
    }
    return (strVal);
}

// Description : Check whether string s is empty.
function isEmpty(s) {
    return ((s == null) || (s.length == 0))
}

// Description : Left trim method: strltrim
function strLtrim(strVal) {
    //Match spaces at beginning of text and replace with a null string
    return strVal.replace(/^\s+/, '');
}

// Description : Right trim method: strrtrim
function strRtrim(strVal) {
    //Match spaces at end of text and replace with a null string
    return strVal.replace(/\s+$/, '');
}

// Description : function trim Text [must use function RTrim and LTrim]
function trim(trimValue) {
    if (trimValue.length < 1) {
        return "";
    }
    trimValue = strRtrim(trimValue);
    trimValue = strLtrim(trimValue);
    if (trimValue == "") {
        return "";
    }
    else {
        return trimValue;
    }
}

// Description :  Fix '"' = fix double quote (can not enter double quote in text box)
function fixDoubleQuote(str) {
    var s = '';
    var vaRegex = /[\"]/g;
    s = str.replace(vaRegex, '');
    return (s);
}

// Description :  Fix single quote (can not enter single quote in text box)
function fixSingleQuote(str) {
    var s = '';
    var vaRegex = /[\']/g;
    s = str.replace(vaRegex, '');
    return (s);
}

// Description : Fix single & double quote (can not enter single & double quote in text box)
function fixQuote(str) {
    var s = '';
    var vaRegex = /[\"\']/g;
    s = str.replace(vaRegex, '');
    return (s);
}

// Description : Set Upper Case in text box (Use in event onkeyup)
// Use in html : <input type=text name=a onkeyup="setUpperCase(this)">
function setUpperCase(obj) {
    obj.value = obj.value.toUpperCase();
    if (event.keyCode == 16 || event.keyCode == 9) {
        obj.select();
    }
}

// Description : Set Lower Case in text box (Use in event onkeyup)
// Use in html : <input type=text name=a onkeyup="setLowerCase(this)">
function setLowerCase(obj) {
    obj.value = obj.value.toLowerCase();
    if (event.keyCode == 16 || event.keyCode == 9) {
        obj.select();
    }
}

function setFormatTel(objectID, dateType)//dataType 2=โทรศัพท์บ้าน,โทรสาร, 3=โทรศัพท์มือถือ
{
   var vDateType = 2;

   if (dateType != undefined)
      vDateType = dateType;

   $("#" + objectID).on("keypress", function (event)
   {
      var key;
      var keychar;

      if (window.event)
      {
         key = event.keyCode;
      }
      else if (event)
      {
         if (event.ctrlKey)
         {
            return true;
         }
         key = event.which;
      }
      else 
      {
         return true;
      }

      keychar = String.fromCharCode(key);

      // control keys
      if ((key == null) || (key == 0) || (vDateType == 2 && key == 9) || (vDateType == 3 && key == 10))
      {
         return true;
      }
      // numbers 
      else if ((("0123456789").indexOf(keychar) >  - 1))
      {

         if (vDateType == 2)
         {

            if ($("#" + objectID).val().length == 2 || $("#" + objectID).val().length == 6)
            {
               $("#" + objectID).val($("#" + objectID).val() + "-");
               return true;
            }
         }
         else if (vDateType == 3)
         {
            if ($("#" + objectID).val().length == 3 || $("#" + objectID).val().length == 7)
            {
               $("#" + objectID).val($("#" + objectID).val() + "-");
               return true;
            }
         }

         if ((vDateType == 2 && $("#" + objectID).val().length >= 11) || (vDateType == 3 && $("#" + objectID).val().length >= 12))
         {
            return false;
         }
      }
      else 
      {
         return false;
      }

      return true;
   });
   
   
   
   $("#" + objectID).on("blur", function (event)
   {
      if ($("#" + objectID).val()!='')
      {
         var numbers = $(this).val().replace(/\D/g, ''),
         char2 = {2:'-',5:'-'}, char3 = {3:'-',6:'-'};;
         $(this).val('');
         
         if (vDateType == 2)
         {
            for (var i = 0; i < numbers.length; i++) {
               $(this).val($(this).val() + (char2[i]||'') + numbers[i])
            }
            
            if($(this).val().length!=11)//หมายเลขรวมขีด
            {
               calModal(objectID, 'กรุณาระบุหมายเลขโทรศัพท์/โทรสาร 9 หลัก');
               return false;
            }
         }
         else if (vDateType == 3)
         {
            for (var i = 0; i < numbers.length; i++) {
               $(this).val($(this).val() + (char3[i]||'') + numbers[i])
            }
            
            if($(this).val().length!=12)//หมายเลขรวมขีด
            {
               calModal(objectID, 'กรุณาระบุหมายเลขโทรศัพท์มือถือ 10 หลัก');
               return false;
            }
         }
      }

   });
}

function setFormatIDCard(cardId)
{
   $("#" + cardId).on("keypress", function (event)
   {
      var key;
      var keychar;

      if (window.event)
      {
         key = event.keyCode;
      }
      else if (event)
      {
         if (event.ctrlKey)
         {
            return true;
         }
         key = event.which;
      }
      else 
      {
         return true;
      }

      keychar = String.fromCharCode(key);

      // control keys
      if ((key == null) || (key == 0))
      {
         return true;
      }
      // numbers 
      else if ((("0123456789").indexOf(keychar) >  - 1))
      {
         if ($("#" + cardId).val().length == 1 || $("#" + cardId).val().length == 6 || $("#" + cardId).val().length == 12 || $("#" + cardId).val().length == 15)
         {
            $("#" + cardId).val($("#" + cardId).val() + "-");
            return true;
         }
      }
      else 
      {
         return false;
      }
      return true;
   });
      
   $("#" + cardId).on("blur", function (event)
   {
      if ($("#" + cardId).val()!='')
      {
         var numbers = $(this).val().replace(/\D/g, ''),
         char = {1:'-',5:'-',10:'-',12:'-'};
         $(this).val('');
         for (var i = 0; i < numbers.length; i++) {
            $(this).val($(this).val() + (char[i]||'') + numbers[i])
         }
         
         if($(this).val().length!=17)//หมายเลขบัตรรวมขีด
         {
            /*alert("กรุณาระบุเลขประจำตัวประชาชน 13 หลัก");
            $(this).select();
            $("#gobleModalFocus").val(cardId);
            $("#modalConfirm").html("กรุณาระบุเลขประจำตัวประชาชน 13 หลัก");
            $("#modalButton").html("<button type=\"button\" class=\"btn btn-primary btn-xs\" data-dismiss=\"modal\"><b>&nbsp;&nbsp;ตกลง&nbsp;&nbsp;<\/b><\/button>");
            $('#myModal').modal('show');*/
            
            calModal(cardId, 'กรุณาระบุเลขประจำตัวประชาชน 13 หลัก');
            return false;
         }
      }
   });
}


//Check House Id key 10 Integer to Function
// parameter		:		houseID typeof String
// return			:		boolean
function setFormatIDHouseForCR(houseId) 
{//Added by YITPN 21/05/2562 แก้ไขตาม CRF0046-62 - เพิ่มการตรวจสอบ Check Digit รหัสประจำบ้าน
   $("#" + houseId).on("keypress", function (event)
   {
      var key;
      var keychar;

      if (window.event)
      {
         key = event.keyCode;
      }
      else if (event)
      {
         if (event.ctrlKey)
         {
            return true;
         }
         key = event.which;
      }
      else 
      {
         return true;
      }

      keychar = String.fromCharCode(key);

      // control keys
      if ((key == null) || (key == 0))
      {
         return true;
      }
      // numbers 
      else if ((("0123456789").indexOf(keychar) >  - 1))
      {
         /*if ($("#" + houseId).val().length == 4 || $("#" + houseId).val().length == 11)
         {
            $("#" + houseId).val($("#" + houseId).val() + "-");*/
            return true;
         //}
      }
      else 
      {
         return false;
      }
      return true;
   });

   $("#" + houseId).on("blur", function (event)
   {
		if( $("#" + houseId).prop("readonly") == false )
		{
			if ($("#" + houseId).val() != '')
			{
				//XXXX-XXXXXX-X
				/*var numbers = $(this).val().replace(/\D/g, ''), 
				char = {4:'-',10:'-'};
				$(this).val('');
				for (var i = 0;i < numbers.length;i++)
				{
					$(this).val($(this).val() + (char[i] || '') + numbers[i])
				}
            
				var newHouseNum = '';
				if ($(this).val() != '')
				{
					newHouseNum = $(this).val().replace(/-/g, '');
				}*/
            
				//if ($(this).val().length != 13)//รหัสประจำบ้านรวมขีด
				if ($(this).val().length != 11)
				{
					$("#gobleModalFocus").val(houseId);
					$("#modalConfirm").html("กรุณาระบุรหัสประจำบ้าน 11 หลัก");
					$("#modalButton").html("<button type=\"button\" class=\"btn btn-primary btn-sm raised\" data-dismiss=\"modal\"><b>&nbsp;&nbsp;ตกลง&nbsp;&nbsp;<\/b><\/button>");
					$('#myModal').modal('show');
					return false;
				}
				else 
				{
					//openLoading('houseId');
               //ถ้าครบ 11 หลัก ทำการตรวจสอบ Check Digit รหัสประจำบ้านต่อไป
					jQuery.ajax(
					{
						cache : false
						, url : '../rq/RequestCentralServlet'
						, type : 'POST'
						, data : 
						{
							act : "CHKHOUSEID", 
							houseID : $("#" + houseId).val()
						},
						success : function (data)
						{
							if (data != '')
							{
								if (data.vaResult != '' && data.vaResult != null && typeof data.vaResult != "undefined" && data.vaResult == '0')
								{
									$("#gobleModalFocus").val(houseId);
									$("#modalConfirm").html("รหัสประจำบ้าน " + data.vaHouseID + " ไม่ถูกต้อง กรุณาตรวจสอบ");
									$("#modalButton").html("<button type=\"button\" class=\"btn btn-primary btn-sm raised\" data-dismiss=\"modal\"><b>&nbsp;&nbsp;ตกลง&nbsp;&nbsp;<\/b><\/button>");
									$('#myModal').modal('show');
									return false;
								}
							}
						},
						error : function ()
						{
							//closeLoading('houseId');
						}
					});
				}
				//End ถ้าครบ 11 หลัก ทำการตรวจสอบ Check Digit รหัสประจำบ้านต่อไป
			}
			//End ถ้า มีค่า
		}//End กรณี เปิด Field (ไม่ได้มาจากคำร้อง) ถึงค่อยตรวจสอบตอน Onblur 
   });
}

function calModal(objectID, errMsg)
{
    if ($('.modal.checkModal').is(':visible'))
    {
        $('#' + objectID).val('');
        return false;
    }
    
    if ($('#modalStringTmp').length == 0)
    {
        $('<div class="modal checkModal fade" data-backdrop="static" id="modalStringTmp">'
        + '<div class="modal-dialog modal-sm">'
        + '<div class="modal-content">'
        + '<div class="modal-header">'
        + '<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;<\/button>'
        + '<h5 class="modal-title">&nbsp;<\/h5>'
        + '<\/div>'
        + '<div class="modal-body" style="text-align: center;" id="modalStringTmpDesc"><\/div>'
        + '<div class="modal-footer" style="text-align: right;">'
        + '<button type="button" class="btn btn-primary btn-sm raised" data-dismiss="modal" id="btnModalTmp"><b>&nbsp;&nbsp;ตกลง&nbsp;&nbsp;<\/b>'
        + '<\/div>'
        + '<\/div><\/div><\/div>').appendTo("body");
    }
    $("#modalStringTmpDesc").html(errMsg);
    $("#modalStringTmp").off('shown.bs.modal');
    $("#modalStringTmp").on('shown.bs.modal', function ()
    {
        $("#btnModalTmp").focus();
    })
    $("#btnModalTmp").off("keydown.tab");
    $("#btnModalTmp").on("keydown.tab", function (e)
    {
        if (e.keyCode == 9)
        {
            e.preventDefault();
        }
    });
    $("#modalStringTmp").off("hidden.bs.modal");
    $("#modalStringTmp").on("hidden.bs.modal", function ()
    {
        $('#' + objectID).focus();
    });
    setModalCenter();
    $(this).val("");
    $('#modalStringTmp').modal('show');
}