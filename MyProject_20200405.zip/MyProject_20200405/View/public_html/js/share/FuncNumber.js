/*  Description    :: Key  0123456789 only and convert to format Number
 * Parameter :	1) objectID = string object id
 *    
 *  The syntax for the formatting is:
 *    0 = Digit
 *    # = Digit, zero shows as absent
 *    . = Decimal separator
 *    - = Negative sign
 *    , = Grouping Separator
 *    % = Percent (multiplies number by 100)
 *    
 *   example :
 *   $("document").ready(function(){
 *      setFormatNumber("objectID","#,##0.00");
 *   }
 */
function setFormatNumber(objectID, paFormat) {
    $("#" + objectID).on("keypress", function (e) {
        var vaRegex = /[0-9.,]/g;
        if(paFormat.substring(0, 1) == '-')
        {
           vaRegex = /[0-9.,-]/g;
        }
        return pressOnly(e, vaRegex);
    });

    $("#" + objectID).blur(function () {
    
        if (paFormat != undefined) {
            if(paFormat.substring(0, 1) != '-')
            {
               $(this).val(Math.abs(noFormat($(this).val())));
            }
            $(this).parseNumber( {
                format : paFormat, locale : "us"
            });
            $(this).formatNumber( {
                format : paFormat, locale : "us"
            });
        }
        else {
            $(this).val(noString($("#" + objectID).val()));
        }
    });

}

// Description    :: To Convert number to format
// Parameter :	1) paNumber = string number
//					2) paFormat = string format
//   
//     The syntax for the formatting is:
//     0 = Digit
//     # = Digit, zero shows as absent
//     . = Decimal separator
//     - = Negative sign
//     , = Grouping Separator
//     % = Percent (multiplies number by 100)
//  example :
//    cnvToFormat(1024,"#,##0.00"); --> 1,024.00
//    cnvToFormat(0,"#,##0.00"); --> 0.00
function cnvToFormat(paNumber, paFormat) {
    var vaFormat = "#,##0.00";
    if (paFormat != undefined) {
        vaFormat = paFormat;
    }

    var vaNumber = "" + paNumber;

    vaNumber = $.parseNumber(vaNumber, 
    {
        format : vaFormat, locale : "us"
    });
    vaNumber = $.formatNumber(vaNumber, 
    {
        format : vaFormat, locale : "us"
    });

    return vaNumber;
}

// Function convertNumToText : convert number to english wording
// Include function OnePos(nopkg),TwoPos(nopkg),ThreePos(pkgitem) 
var pkgtxt, pkgtxtlast, nopkg, nopkg1, onetxt, pkgitem;

function convertNumToText(obj) {
    nopkg = obj.value;
    nopkg = nopkg.replace(',', '');
    pkgtxt = '';
    OnePos(nopkg.substring((nopkg.length), (nopkg.length) - 1));
    pkgtxt = onetxt;
    pkgitem = nopkg.substring((nopkg.length) - 2);

    if (pkgitem.length == 2) {
        TwoPos(pkgitem);
    }

    pkgitem = nopkg.substring((nopkg.length) - 3);
    if (pkgitem.length == 3) {
        ThreePos(pkgitem);
    }

    if (nopkg.length > 3) {
        pkgitem = nopkg.substring(0, (nopkg.length) - 3);
        pkgtxtlast = pkgtxt;
        pkgtxt = '';
        OnePos(pkgitem.substring((pkgitem.length) - 1, (pkgitem.length)));
        pkgtxt = onetxt;
        if (pkgitem.substring((pkgitem.length) - 2, (pkgitem.length)) != 0) {
            TwoPos(pkgitem.substring((pkgitem.length) - 2, (pkgitem.length)));
        }
        if (pkgitem.substring(0, 1) != 0 & pkgitem.length == 3) {
            ThreePos(pkgitem.substring(0, 1));
        }
        if (pkgtxtlast == '') {
            pkgtxt = pkgtxt + " THOUSAND";
        }
        else if (pkgtxtlast.indexOf('HUNDRED') !=  - 1) {
            pkgtxt = pkgtxt + " THOUSAND " + pkgtxtlast;
        }
        else {
            pkgtxt = pkgtxt + " THOUSAND AND " + pkgtxtlast;
        }
    }
    return pkgtxt;
}

function OnePos(nopkg) {
    if (nopkg == 0)
        onetxt = '';
    if (nopkg == 1)
        onetxt = 'ONE';
    if (nopkg == 2)
        onetxt = 'TWO';
    if (nopkg == 3)
        onetxt = 'THREE';
    if (nopkg == 4)
        onetxt = 'FOUR';
    if (nopkg == 5)
        onetxt = 'FIVE';
    if (nopkg == 6)
        onetxt = 'SIX';
    if (nopkg == 7)
        onetxt = 'SEVEN';
    if (nopkg == 8)
        onetxt = 'EIGHT';
    if (nopkg == 9)
        onetxt = 'NINE';
    return onetxt;
}

function TwoPos(nopkg) {
    if (nopkg == 10)
        pkgtxt = 'TEN';
    if (nopkg == 11)
        pkgtxt = 'ELEVEN';
    if (nopkg == 12)
        pkgtxt = 'TWELVE';
    if (nopkg == 13)
        pkgtxt = 'THIRTEEN';
    if (nopkg == 14)
        pkgtxt = 'FOURTEEN';
    if (nopkg == 15)
        pkgtxt = 'FIFTEEN';
    if (nopkg == 16)
        pkgtxt = 'SIXTEEN';
    if (nopkg == 17)
        pkgtxt = 'SEVENTEEN';
    if (nopkg == 18)
        pkgtxt = 'EIGHTEEN';
    if (nopkg == 19)
        pkgtxt = 'NINETEEN';
    if (nopkg >= 20) {
        nopkg1 = nopkg.substring(0, 1);
        if (nopkg1 == 2)
            pkgtxt = 'TWENTY';
        if (nopkg1 == 3)
            pkgtxt = 'THIRTY';
        if (nopkg1 == 4)
            pkgtxt = 'FORTY';
        if (nopkg1 == 5)
            pkgtxt = 'FIFTY';
        if (nopkg1 == 6)
            pkgtxt = 'SIXTY';
        if (nopkg1 == 7)
            pkgtxt = 'SEVENTY';
        if (nopkg1 == 8)
            pkgtxt = 'EIGHTY';
        if (nopkg1 == 9)
            pkgtxt = 'NINETY';
        if (OnePos(nopkg.substring(1)) == '') {
            pkgtxt = pkgtxt;
        }
        else {
            pkgtxt = pkgtxt + " " + OnePos(nopkg.substring(1));
        }
    }

    return pkgtxt;
}

function ThreePos(pkgitem) {
    pkgitem = pkgitem.substring(0, 1);
    OnePos(pkgitem);
    if (pkgitem != 0) {
        if (pkgtxt == '') {
            pkgtxt = onetxt + " HUNDRED";
        }
        else {
            pkgtxt = onetxt + " HUNDRED AND " + pkgtxt;
        }
    }
    return pkgtxt;
}

//Description    :: Convert floating number format to not format --> 0123456789
function noString(sNumber) {
    vaRegex = /[^0-9]/g;
    return sNumber.replace(vaRegex, '');
}

//Description    :: Convert floating number format to not format
function noFormat(sNumber) {
    vaRegex = /[^0-9.]/g;
    return sNumber.replace(vaRegex, '');
}

//Description    :: To Convert number in decimal format
// Parameter :	1) num = string number
//		2) decimal = number of dot decimal 
//              3) roundType : 1 = round up, 0 = round down
function roundNumber(num, decimal, roundType) {
    if (num.length != 0) {
        var txtdecimal = "";
        txt = num + "";
        splittxt = txt.split(".");
        // Case : round up
        if (roundType == 1) {
            returnnum = Math.round(num * Math.pow(10, decimal)) / Math.pow(10, decimal);
            // Case : round down
        }
        else {
            for (i = 0;i < decimal;i++) {
                txtdecimal += "0";
            }
            if (!splittxt[1]) {
                returnnum = splittxt[0] + "." + txtdecimal
            }
            else {
                returnnum = splittxt[0] + "." + splittxt[1].slice(0, decimal)
            }
        }
        return returnnum;
    }
    return 0;
}

// onblur decimal
jQuery.fn.decimal = function(number, decimals)
{
   var vnDecimal = !isFinite(+decimals) ? 0 : Math.abs(decimals);
   var vnMaxLength = number + (Math.ceil((number - vnDecimal) / 3));
   if (vnDecimal == 0)
   {
      vnMaxLength = vnMaxLength - 1;
   }


   var vaDecimal = '';
   while (vaDecimal.length < vnDecimal)
   {
      vaDecimal += '0';
   }
   return this.each(function()
   {
      $(this).attr("maxlength", vnMaxLength);
      $(this).on("blur", function()
      {
         var elementId = this.id;
         if (vaDecimal.length > 0)
         {
            $(this).val(cnvToFormat($(this).val(), "#,##0." + vaDecimal));
         }
         else
         {
            $(this).val(cnvToFormat($(this).val(), "#,##0"));
         }
         if ($(this).val().length > vnMaxLength)
         {
            if ($('#modalTmp').length == 0)
            {
               $('<div class="modal fade" data-backdrop="static" id="modalTmp">' +
                  '<div class="modal-dialog modal-sm modal-dialog-center">' +
                  '<div class="modal-content">' +
                  '<div class="modal-header">' +
                  '<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;<\/button>' +
                  '<h5 class="modal-title">&nbsp;<\/h5>' +
                  '<\/div>' +
                  '<div class="modal-body" style="text-align: center;">มีค่าเกินกว่ากำหนด<\/div>' +
                  '<div class="modal-footer" style="text-align: right;">' +
                  '<button type="button" class="btn btn-primary btn-xs" data-dismiss="modal" id="btnModalTmp"><b>&nbsp;&nbsp;ตกลง&nbsp;&nbsp;<\/b>' +
                  '<\/div>' +
                  '<\/div><\/div><\/div>').appendTo("body");
            }
            $("#modalTmp").off('shown.bs.modal');
            $("#modalTmp").on('shown.bs.modal', function()
            {
               $("#btnModalTmp").focus();
            })
            $("#btnModalTmp").off("keydown.tab");
            $("#btnModalTmp").on("keydown.tab", function(e)
            {
               if (e.keyCode == 9)
               {
                  e.preventDefault();
               }
            });
            $("#modalTmp").off("hide.bs.modal");
            $("#modalTmp").on("hide.bs.modal", function()
            {
               $("#" + elementId).val($("#" + elementId).val().replace(/,/g,""));
            });
            $("#modalTmp").off("hidden.bs.modal");
            $("#modalTmp").on("hidden.bs.modal", function()
            {
               $("#" + elementId).focus().select();
            });
            setModalCenter();
            //$(this).val("");
            //setTimeout(function() {
              $('#modalTmp').modal('show');
            //}, 200);
         }
      });

   });
}