// Description : Key 0123456789 Only and Auto "/" 
// Parameter : 1) objectID = string object id
//             2) dateType = string date format         
//                1 = mm/dd/yyyy
//                2 = yyyy/dd/mm  (Unable to do date check at this time)
//                3 = dd/mm/yyyy
//   example :
//   $("document").ready(function(){
//      setFormatDate("objectID","3");
//   }
function setFormatDate(objectID, dateType) {
    var vDateType = 3;

    if (dateType != undefined)
        vDateType = dateType;

    $("#" + objectID).on("keypress", function (event) {
        var key;
        var keychar;

        if (window.event) {
            key = event.keyCode;
        }
        else if (event) {
			if(event.ctrlKey){
                return true;
            }
            key = event.which;
        }
        else {
            return true;
        }

        keychar = String.fromCharCode(key);

        // control keys
        if ((key == null) || (key == 0) || (key == 8) || (key == 9) || (key == 27)) {
            return true;
        }
        // numbers 
        else if ((("0123456789").indexOf(keychar) >  - 1)) {

            if (vDateType == 3) {

                if ($("#" + objectID).val().length == 2 || $("#" + objectID).val().length == 5) {
                    $("#" + objectID).val($("#" + objectID).val() + "/");
                    return true;
                }
            }
            else if (vDateType == 2) {
                if ($("#" + objectID).val().length == 3 || $("#" + objectID).val().length == 6) {
                    $("#" + objectID).val($("#" + objectID).val() + "/");
                    return true;
                }
            }
            else if (vDateType == 1) {
                if ($("#" + objectID).val().length == 2 || $("#" + objectID).val().length == 5) {
                    $("#" + objectID).val($("#" + objectID).val() + "/");
                    return true;
                }
            }

            /*if ($("#" + objectID).val().length >= 10) {
                return false;
            }*/
            if ($("#" + objectID).val().length >= 10) {
                isTextSelected(document.getElementById(objectID));
                return true;
            }
        }
        else {
            return false;
        }

        return true;
    });
    
    $("#" + objectID).on("blur", function (event) {
    
         var dateStr = $(this).val();
         //var datePat =  /^(\d{2})-(\d{2})(-(\d{4}))?$/;
         var datePat = /^(\d{2})\/(\d{2})(\/(\d{4}))?$/;
         //var errMsg = '';
         var matchArray = null;
         var day = '';
         var month = '';
         var year = '';
         
         if(dateType == 1)
            datePat = /^(\d{2})\/(\d{2})(\/(\d{4}))?$/;
         else if(dateType == 2)
            datePat = /^(\d{4})\/(\d{2})(\/(\d{2}))?$/;
         else
            datePat = /^(\d{2})\/(\d{2})(\/(\d{4}))?$/;
         
         if(dateStr.length == 0)
         {
            return false;
         }
         if(dateStr != '99/99/9999' && dateStr != '9999/99/99')
         {
            matchArray = dateStr.match(datePat);
            //alert(dateStr.length)
            if (matchArray == null || dateStr.length < 10) 
            {
               calModal(objectID, 'กรุณาระบุรูปแบบ dd/mm/yyyy');
               return false;
            }
            day = matchArray[1];
            month = matchArray[2];
            year = matchArray[4];
            if(year < 2100)
            {
               calModal(objectID, 'กรุณาระบุเป็นปี พ.ศ.');
               return false;
            }
            if(month > 12 || month == 0)
            {
               calModal(objectID, 'กรุณาใส่ค่าเดือนระหว่าง 1-12');
               return false;
            }
            if(checkLeapYear(year, true) && month == 2 && day > 29)
            {
               calModal(objectID, 'กรุณาใส่ค่าวันที่ระหว่าง 1-29');
               return false;
            }
            if(!(checkLeapYear(year, true)) && month == 2 && day > 28)
            {
               calModal(objectID, 'กรุณาใส่ค่าวันที่ระหว่าง 1-28');
               return false;
            }
            if ((month == 4 || month == 6 || month == 9 || month == 11) && day > 30) 
            {
               calModal(objectID, 'กรุณาใส่ค่าวันที่ระหว่าง 1-30');
               return false;
            }
            if(day > 31 || day == 0)
            {
               calModal(objectID, 'กรุณาใส่ค่าวันที่ระหว่าง 1-31');
               return false;
            }
         }
         
            
    });

}


function isTextSelected(input)
{
   if (typeof input.selectionStart == "number")
   {
      return input.selectionStart == 0 && input.selectionEnd == input.value.length;
   }
   else if (typeof document.selection != "undefined")
   {
      input.focus();
      return document.selection.createRange().text == input.value;
   }
}

function calModal(objectID, errMsg)
{
   if ($('#modalDateTmp').length == 0)
   {
      $('<div class="modal fade" id="modalDateTmp">' +
         '<div class="modal-dialog modal-sm">' +
         '<div class="modal-content">' +
         '<div class="modal-header">' +
         '<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;<\/button>' +
         '<h5 class="modal-title">&nbsp;<\/h5>' +
         '<\/div>' +
         '<div class="modal-body" style="text-align: center;" id="modalDateTmpDesc"><\/div>' +
         '<div class="modal-footer" style="text-align: right;">' +
         '<button type="button" class="btn btn-primary btn-xs" data-dismiss="modal" id="btnModalTmp"><b>&nbsp;&nbsp;ตกลง&nbsp;&nbsp;<\/b>' +
         '<\/div>' +
         '<\/div><\/div><\/div>').appendTo("body");
   }
   $("#modalDateTmpDesc").html(errMsg);
   $("#modalDateTmp").off('shown.bs.modal');
   $("#modalDateTmp").on('shown.bs.modal', function()
   {
      $("#btnModalTmp").focus();
   })
   $("#btnModalTmp").off("keydown.tab");
   $("#btnModalTmp").on("keydown.tab", function(e)
   {
      if (e.keyCode == 9)
      {
         e.preventDefault();
      }
   });
   $("#modalDateTmp").off("hide.bs.modal");
   $("#modalDateTmp").on("hide.bs.modal", function()
   {
      //$("#" + objectID).focus();
      //alert($(this).focus());
      setTimeout("$('#" + objectID+"').focus();", 100);
      //alert(objectID);
      //$(this).focus();
      //alert(1);
   });
   $(this).val("");
   $('#modalDateTmp').modal('show');
}


// Description : Check leap year 
// Parameter : theyear = year, typeEra = true : Buddish Era and false : Cristian Era
// Return true = It is leap year, false = It is not leap year
function checkLeapYear(theyear, typeEra) {
// 1.Years divisible by four are leap years, unless...
// 2.Years also divisible by 100 are not leap years, except...
// 3.Years divisible by 400 are leap years.
     if(typeEra == undefined)
     {
             typeEra = true;
     }
     if(typeEra)
     {
             theyear = theyear - 543;
     }
     if ( ((theyear % 4 == 0) && (theyear % 100 != 0)) || (theyear % 400 == 0) ) {
             return true;
     } else {
             return false;
     }
}

// Description : Calculate two date and return value date2 - date1
// Parameter : date1 = first date format dd/mm/yyyy
//             date2 = second date format dd/mm/yyyy
//			   typeEra = true : Buddish Era and false : Cristian Era				
function calDateDif(date1, date2, typeEra) {
    var datePat = /^(\d{2})\/(\d{2})(\/(\d{4}))?$/;
    var matchArray1 = null;
    var matchArray2 = null;
    if (typeEra == undefined) {
        typeEra = true;
    }

    if (date1 != '' && date1 != null && date2 != '' && date2 != null) {
        matchArray1 = date1.match(datePat);
        matchArray2 = date2.match(datePat);
        if (matchArray1 == null || matchArray2 == null) {
            alert("ไม่สามารถเปรียบเทียบค่าได้ เพราะ รูปแบบไม่ถูกต้อง");
        }
        else {
            day1 = matchArray1[1];
            month1 = matchArray1[2];
            year1 = matchArray1[4];

            day2 = matchArray2[1];
            month2 = matchArray2[2];
            year2 = matchArray2[4];

            if (typeEra) {
                year1 = year1 - 543;
                year2 = year2 - 543;
            }

            var one_day = 1000 * 60 * 60 * 24

            return ((Date.parse(eval(month2) + "/" + day2 + "/" + year2) - Date.parse(eval(month1) + "/" + day1 + "/" + year1))) / (one_day);
        }
    }
}