	var $loading = $(
    '<div class="modal fade" data-backdrop="static" data-keyboard="false" id="modalLoading">' +
		'<div class="modal-dialog modal-sm modal-dialog-center" id="loadingSize">' +
			'<div class="modal-content" id="loadingContentLoading">' +
				'<div class="modal-body" align="center" style="font-size:20px">' +
					'<span class="glyphicon glyphicon-refresh spinning"></span>&nbsp;&nbsp;&nbsp;Loading...' +
				'</div>' +
			'</div>' +
			'<div class="modal-content" id="loadingContentMassage">' +
				'<div class="modal-header">' +
					'<h5 class="modal-title">&nbsp;</h5>' +
				'</div>' +
				'<div class="modal-body" style="text-align: center;" id="loadingMassage"></div>' +
				'<div class="modal-footer" style="text-align: right;" id="loadingButton"></div>' +
			'</div>' +
		'</div>' +
    '</div>');
	$loading.modal();
	$('#modalLoading').modal('hide');
                     
	function openLoading()
	{
		if((typeof($("#modalLoading").data('bs.modal')) === 'undefined') || ($("#modalLoading").data('bs.modal') || {}).isShown==false
		 ||(typeof($("#myModal").data('bs.modal')) === 'undefined') || ($("#myModal").data('bs.modal') || {}).isShown==false)
		{
			$('#loadingContentMassage').hide();
			$('#modalLoading').modal('show');
		}
	};
	function closeLoading()
	{
		$('#modalLoading').modal('hide');
	}
	function switchingContent()
	{
		$('#loadingSize').removeClass('');
		$('#loadingSize').addClass('modal-dialog modal-sm modal-dialog-center');
		$('#loadingContentLoading').show();
		$('#loadingContentMassage').hide();
	}
	//กรณี มี openLoading ต้องมี closeLoading เสมอ
	
	loadingSize = $('#loadingSize').attr("class");
	$('#modalLoading').on("hidden.bs.modal", function ()
    {
		$('#loadingContentLoading').show();
		$('#loadingContentMassage').hide();
		$('#loadingSize').removeClass('');
		$('#loadingSize').addClass('modal-dialog modal-sm modal-dialog-center');
    });