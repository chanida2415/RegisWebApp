/*----------------------------------------------------------------------
 Script Name : FuncTab.js
 Date : 19/12/2548
 Description    :: To set  auto tab*/

// Description : autoTab used in 2 case
// 1. autoTab(input,len,event) 
// 2. autoTab(input)
var isNN = (navigator.appName.indexOf("Netscape")!=-1);
function autoTab(input,len, e) {

//var keyCode = (isNN) ? e.which : e.keyCode; 
// add check event = undefined and no len : ex. autoTab(input) > send 1 parameter
var keyCode;
if(e==undefined)
{
   keyCode = 0;
}
else
{
   keyCode = (isNN) ? e.which : e.keyCode; 
}

var filter = (isNN) ? [0,8,9] : [0,8,9,16,17,18,37,38,39,40,46];
//if(input.value.length >= len && !containsElement(filter,keyCode)) {
// add check keyCode==0 (no event) and len = 0
if(input.value.length >= len && !containsElement(filter,keyCode) || keyCode==0) {
input.value = input.value.slice(0, len);

try
	{

		if(input.form[(getIndex(input)+1) % input.form.length].disabled == true)
		{
			autoTab(input.form[(getIndex(input)+1 ) % input.form.length]);
		}
		else if(input.form[(getIndex(input)+1) % input.form.length].type == "button")
		{
			input.form[(getIndex(input)+1) % input.form.length].focus();
		}
      	else if(input.form[(getIndex(input)+1) % input.form.length].type == "hidden")
		{
			autoTab(input.form[(getIndex(input)+1 ) % input.form.length]);
		}
		else
		{
		input.form[(getIndex(input)+1) % input.form.length].select();
		}
	}
catch(e)
	{
		input.form[(getIndex(input)+1) % input.form.length].focus();
	}
}

function containsElement(arr, ele) {
var found = false, index = 0;
while(!found && index < arr.length)
if(arr[index] == ele)
found = true;
else
index++;
return found;
}
function getIndex(input) {
var index = -1, i = 0, found = false;
while (i < input.form.length && index == -1)
if (input.form[i] == input)index = i;
else i++;
return index;
}
return true;
}

// Description : Next tab
function tab(obj,next)
{ 
    if(event.keyCode == 9 && event.shiftKey==false)
	{   
		
		document.execCommand('unselect');
		try
		{
			obj.form.elements[next].select();  
		}
		catch(e)
		{
			obj.form.elements[next].focus();  
		}
		 return false
	}
}

// Description : Previous tab
function shiftTab(obj,prev)
{
    if(event.shiftKey && event.keyCode == 9 )
	{ 
		document.execCommand('unselect');
		  obj.form.elements[prev].focus();    
		 return false;
	}
}

/*  example :
 *   $("document").ready(function(){
 *      setTab("CLR", "OPNSRH");
 *   }
 */
function setTab(objectId, nextObjectId)
{
   $('#'+objectId).on("keydown", function (e){
        if(e.keyCode == 9 && e.shiftKey==false)
        {
            if($("#"+nextObjectId).prop('tagName') == "SELECT")
            {
                $("#"+nextObjectId).select2("focus");
            }
            else
            {
                $("#"+nextObjectId).focus();
            }
            return false;
        }
   });
}

/*  example : 
 *   $("document").ready(function(){
 *      setShiftTab("OPNSRH", "CLR");
 *   }
 */
function setShiftTab(objectId, prevObjectId)
{
   $('#'+objectId).on("keydown", function (e){
        if(e.keyCode == 9 && e.shiftKey==true)
        {
            if($("#"+prevObjectId).prop('tagName') == "SELECT")
            {
                $("#"+prevObjectId).select2("focus");
            }
            else
            {
                $("#"+prevObjectId).focus();
            }
            return false;
        }
   });
}

/*  example :
 *   $("document").ready(function(){
 *      //แบบที่ 1 ไม่ระบุ length จะใช้ maxlength ของ input นั้นๆ
 *      setAutoTab("collectType", "collectTypeDesc");
 *      //แบบที่ 2 ระบุ length
 *      setAutoTab("collectType", "collectTypeDesc", 2);
 *   }
 */
function setAutoTab(objectId, nextObjectId, pnLength)
{

    $('#'+objectId).on("keyup", function (e){
    
        var vnLength = 0;
        if(pnLength != undefined && pnLength > 0)
        {
            vnLength = pnLength;
        }
        else
        {
            vnLength = $(this).attr("maxlength");
        }        
        
        if(vnLength != undefined && vnLength > 0 )
        { 

            if($(this).val().length >= vnLength && (e.keyCode != 9 && e.keyCode != 16/*no tab*/))
            {
                
                if($("#"+nextObjectId).prop('tagName') == "SELECT")
                {
                    $("#"+nextObjectId).select2("focus");
                }
                else
                {
                    $("#"+nextObjectId).focus();
                }
                return false;
            }
        }

   });
}
