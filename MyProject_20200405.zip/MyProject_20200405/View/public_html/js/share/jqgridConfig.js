$.jgrid.defaults.rowNum=20;
$.jgrid.defaults.rownumWidth=40;
$.jgrid.defaults.multiselectWidth=30;
$.jgrid.defaults.rowList=[20, 40, 100];
$.jgrid.defaults.loadtext="<span class=\"glyphicon glyphicon-refresh spinning\"><\/span> กำลังค้นหาข้อมูล... ";
$.jgrid.defaults.loadError=function(xhr,st,err) {jqgridError(xhr,st,err)}