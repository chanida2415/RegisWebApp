var EGAWSSmartCardInfo = {
  url: '',
  prefixCodeUrl: '',
  amphurUrl: '',
  tumbolUrl: '',
  citizenId: '',
  agentId: '',
  token: '',
  statusCode: 0,
  personInfo:
  {
    referenceId: '',
    imageSmartcard: '',
    imageNumber: '',
    addressId: '',
    citizenId: '',
    prefixNameEn: '',
    firstNameEn: '',
    middleName: '',
    surNameEn: '',
    prefixNameCode: '',
    prefixName: '',
    firstName: '',
    firstNameExact: '',
    middleNameEn: '',
    surName: '',
    addressNo: '',
    moo: '',
    road: '',
    addressSoi: '',
    addressAlley: '',
    addressAmphur: '',
    addressTumbol: '',
    addressProvince: '',
    sexId: '',
    sex: '',
    birthDate: '',
    age: '',
    personStatusId: '',
    personStatus: '',
    issueDate: '',
    expireDate: '',
    issuerId: '',
    issuerPlace: '',
    issuerAgency: '',
    nationality: '',
    nationalityOld: '',
    nationalityChangeDate: '',
    fatherCitizenID: '',
    fatherNationality: '',
    fatherNameTHFirstName: '',
    fatherNameTHFirstNameExact: '',
    fatherFirstName: '',
    motherCitizenID: '',
    motherNationality: '',
    motherNameTHFirstName: '',
    motherNameTHFirstNameExact: '',
    motherFirstName: '',
    domicileType: '',
    domicileStatus: '',
    domicileDate: '',
    registryOffice: '',
    houseType: '',
    permitDate: '',
    disposeDate: '',
    villageName: '',
    buildingName: '',
    location: '',
    postCode: '',
    houseAttribute: '',
    houseSize: '',
    houseVolumn: '',
    ownerFile: '',
    ownerFileId: '',
    landSize: '',
    tel01: '',
    tel02: '',
    tel03: '',
    tel04: '',
    tel05: '',
    tel06: '',
    tel07: '',
    tel08: '',
    tel09: '',
    tel10: '',
    approveId: '',
    communityName: '',
    status: '',
    reasonPhrase: ''
  },
  checkNationalID: function(id)
  {
    if (id.length != 13) return false;

    for (i = 0, sum = 0; i < 12; i++) sum += parseFloat(id.charAt(i)) * (13 - i);

    if ((11 - sum % 11) % 10 != parseFloat(id.charAt(12))) return false;

    return true;
  },
  getAct: function()
  {
    return $("#act").val();
  },
  setAct: function(act)
  {
    $("#act").val(act);
  },
  getScreenId: function()
  {
    return $("#screenId").val();
  },
  setScreenId: function(screenId)
  {
    $("#screenId").val(screenId);
  },
  setPersonInfo: function(data)
  {
    this.personInfo.referenceId = data.ReferenceID;
    this.personInfo.imageSmartcard=data.ImageSmartcard;
    this.personInfo.imageNumber=data.ImageNumber;
    this.personInfo.citizenId=data.CitizenID;
    this.personInfo.prefixNameEn=data.NameEN_Prefix;
    this.personInfo.firstNameEn=data.NameEN_FirstName;
    this.personInfo.middleName=data.NameTH_MiddleName;
    this.personInfo.surNameEn=data.NameEN_SurName;
    this.personInfo.prefixName=data.NameTH_Prefix;
    this.personInfo.firstName=data.NameTH_FirstName;
    this.personInfo.firstNameExact=data.NameTH_FirstName_Exact;
    this.personInfo.middleNameEn=data.NameEN_MiddleName;
    this.personInfo.surName=data.NameTH_SurName;
    this.personInfo.sexId=data.SexID;
    this.personInfo.sex=data.Sex;
    this.personInfo.birthDate=data.BirthDate;
    this.personInfo.age=data.Age;
    this.personInfo.personStatusId=data.PersonStatusID;
    this.personInfo.personStatus=data.PersonStatus;
    this.personInfo.addressId=data.AddressID;
    this.personInfo.addressNo=data.Address_No;
    this.personInfo.moo=data.Address_Moo;
    this.personInfo.addressAlley=data.Address_Alley;
    this.personInfo.addressSoi=data.Address_Alley+' '+data.Address_Soi;// ตรอก/ซอย
    this.personInfo.road=data.Address_Road;
    this.personInfo.addressTumbol=data.Address_Tumbol;
    this.personInfo.addressAmphur=data.Address_Amphur;
    this.personInfo.addressProvince=data.Address_Province;
    this.personInfo.issueDate=data.IssueDate;
    this.personInfo.expireDate=data.ExpireDate;
    this.personInfo.issuerId=data.IssuerID;
    this.personInfo.issuerPlace=data.IssuerPlace;
    this.personInfo.issuerAgency=data.IssuerAgency;
    this.personInfo.nationality=data.Nationality;
    this.personInfo.nationalityOld=data.Nationality_Old;
    this.personInfo.nationalityChangeDate=data.Nationality_ChangeDate;
    this.personInfo.fatherCitizenID=data.Father_CitizenID;
    this.personInfo.fatherNationality=data.Father_Nationality;
    this.personInfo.fatherNameTHFirstName=data.Father_NameTH_FirstName;
    this.personInfo.fatherNameTHFirstNameExact=data.Father_NameTH_FirstName_Exact;
    this.personInfo.fatherFirstName=data.Father_FirstName;
    this.personInfo.motherCitizenID=data.Mother_CitizenID;
    this.personInfo.motherNationality=data.Mother_Nationality;
    this.personInfo.motherNameTHFirstName=data.Mother_NameTH_FirstName;
    this.personInfo.motherNameTHFirstNameExact=data.Mother_NameTH_FirstName_Exact;
    this.personInfo.motherFirstName=data.Mother_FirstName;
    this.personInfo.domicileType=data.DomicileType;
    this.personInfo.domicileStatus=data.DomicileStatus;
    this.personInfo.domicileDate=data.DomicileDate;
    this.personInfo.registryOffice=data.RegistryOffice;
    this.personInfo.houseType=data.HouseType;
    this.personInfo.permitDate=data.PermitDate;
    this.personInfo.disposeDate=data.DisposeDate;
    this.personInfo.villageName=data.VillageName;
    this.personInfo.buildingName=data.BuildingName;
    this.personInfo.location=data.Location;
    this.personInfo.postCode=data.PostCode;
    this.personInfo.houseAttribute=data.HouseAttribute;
    this.personInfo.houseSize=data.HouseSize;
    this.personInfo.houseVolumn=data.HouseVolumn;
    this.personInfo.ownerFile=data.OwnerFile;
    this.personInfo.ownerFileID=data.OwnerFileID;
    this.personInfo.landSize=data.LandSize;
    this.personInfo.tel01=data.Tel01;
    this.personInfo.tel02=data.Tel02;
    this.personInfo.tel03=data.Tel03;
    this.personInfo.tel04=data.Tel04;
    this.personInfo.tel05=data.Tel05;
    this.personInfo.tel06=data.Tel06;
    this.personInfo.tel07=data.Tel07;
    this.personInfo.tel08=data.Tel08;
    this.personInfo.tel09=data.Tel09;
    this.personInfo.tel10=data.Tel10;
    this.personInfo.approveID=data.ApproveID;
    this.personInfo.communityName=data.CommunityName;
    this.personInfo.status=data.Status;
    this.personInfo.reasonPhrase=data.ReasonPhrase;
  },
  loadImageSmartcard: function(data)
  {
    try
    {
        this.personInfo.imageSmartcard = data;
    }
    catch (err)
    {this.AppletStatus = false;}
  },
  loadIssueDate: function(data)
  {
    try
    {
        this.personInfo.issueDate = (data*1)+5430000;
    }
    catch (err)
    {this.AppletStatus = false;}
  },
  loadExpireDate: function(data)
  {
    try
    {
        this.personInfo.expireDate = (data*1)+5430000;
    }
    catch (err)
    {this.AppletStatus = false;}
  },
  loadIssuerID: function(data)
  {
    try
    {
        this.personInfo.issuerId = data;
    }
    catch (err)
    {this.AppletStatus = false;}
  },
  getToken: function()
  {
    this.setAct("EGA_TOKEN");
    var ajaxToken = $.post("../rq/RequestCentralServlet",
    {
      act: this.getAct()
    }, "json");
    return ajaxToken;
  },
  getProfileNormal: function()
  {
    this.setAct("EGA_PROFILENORMAL");
    var ajaxProfile = $.post("../rq/RequestCentralServlet",
    {
      act: this.getAct,
      citizenId: this.citizenId
    }, "json");
    return ajaxProfile;
  },
  getProfileFull: function()
  {
    this.setAct("EGA_PROFILEFULL");
    var ajaxProfile = $.post("../rq/RequestCentralServlet",
    {
      act: this.getAct,
      citizenId: this.citizenId,
      screenId: this.getScreenId
    }, "json");
    return ajaxProfile;
  },
  getPrefix: function(prefixNameSRH, url)
  {
    this.setAct("EGA_PREFIX");
    var ajaxPrefixCode = $.post(url,
    {
      act: this.getAct,
      prefixName: prefixNameSRH
    }, "json");
    return ajaxPrefixCode;
  },
  getProvince: function(ProvinceNameSHR, url)
  {
    this.setAct("SRHPRVBRN");
    var ajaxProvince = $.post(url,
    {
      act: this.getAct,
      ProvinceName: ProvinceNameSHR
    }, "json");
    return ajaxProvince;
  },
  getAmphur: function(AmphurNameSHR, url)
  {
    this.setAct("SRHAMPSMC");
    var ajaxAmphur = $.post(url,
    {
      act: this.getAct,
      AmphurName: AmphurNameSHR
    }, "json");
    return ajaxAmphur;
  },
  getTumbol: function(districtNameSRH, url)
  {
    this.setAct("SRHDISSMC");
    var ajaxTumbol = $.post(url,
    {
      act: this.getAct,
      DistrictName: districtNameSRH
    }, "json");
    return ajaxTumbol;
  },
  getFullAddress: function(provinceNameSHR, amphurNameSHR, districtNameSRH, url)
  {
    this.setAct("SRHPRVAMPDIS");
    var ajaxFullAdd = $.post(url,
    {
      act: this.getAct,
      ProvinceName: provinceNameSHR,
      AmphurName: amphurNameSHR,
      DistrictName: districtNameSRH
    }, "json");
    return ajaxFullAdd;
  },
  setBeforeLoad: function(btnId)
  {
    $(btnId).addClass("m-progress");
    $(btnId).prop("disabled", true);
    waitingDialog.show('Loading',
    {
      dialogSize: 'sm'
    });
  },
  setAfterLoad: function(btnId, textId)
  {
    $(btnId).removeClass("m-progress");
    $(btnId).prop("disabled", false);
    waitingDialog.hide();
    //$(textId).focus();
    $(textId).blur();
    $(textId).focus();
  },
  smartCardProcess: function(person, linkType)
  {
    this.setAct("SMCPOC");
    var ajaxSmartCardProcess = $.post( "../rq/RequestCentralServlet",
    {
      act: this.getAct,
      person: JSON.stringify(person),
      inCard: JSON.stringify(AppletHandler.getInfo()),
      screenId: this.getScreenId, 
      linkType: linkType
    }, "json");
    return ajaxSmartCardProcess;
  }
}

var AppletHandler = {
    AppletStatus: false,
    validate: function()
    {
      try
      {
        if (document.myApplet.isActive())
        {
          this.AppletStatus = true;
        }
        else
        {
          this.AppletStatus = false;
        }
      }
      catch (err)
      {
        this.appletError("Browser ไม่รองรับการอ่านบัตร Smart Card");
        this.AppletStatus = false;
      }
    },
    clearCard: function()
    {
        try
        {
            document.myApplet.setAllEmpthy();
        }
        catch (err)
        {
            this.AppletStatus = false;
        }
    },
    getInfo: function()
    {
        var voPersonInfo = EGAWSSmartCardInfo.personInfo;
        try
        {
            document.myApplet.loadNewCard();
            voPersonInfo.prefixName = document.myApplet.getInfo('prefixNameTH');
            voPersonInfo.citizenId = document.myApplet.getInfo('citizenId');
            voPersonInfo.firstName = document.myApplet.getInfo('firstNameTH');
            voPersonInfo.surName = document.myApplet.getInfo('surNameTH');
            voPersonInfo.addressNo = document.myApplet.getInfo('addressNo');
            voPersonInfo.moo = document.myApplet.getInfo('addressMoo');
            voPersonInfo.road = document.myApplet.getInfo('addressRoad');
            voPersonInfo.addressSoi = document.myApplet.getInfo('addressSoi');
            voPersonInfo.addressAlley = document.myApplet.getInfo('addressAlley');
            voPersonInfo.addressAmphur = document.myApplet.getInfo('addressAmphur');
            voPersonInfo.addressTumbol = document.myApplet.getInfo('addressTumbol');
            voPersonInfo.addressProvince = document.myApplet.getInfo('addressProvince');
            voPersonInfo.imageSmartcard = document.myApplet.getInfo('imageSmartcard');
            voPersonInfo.imageNumber = document.myApplet.getInfo('imageNumber');
            voPersonInfo.issuerId = document.myApplet.getInfo('issuerID');
            voPersonInfo.issueDate = document.myApplet.getInfo('issueDate');
            voPersonInfo.expireDate = document.myApplet.getInfo('expireDate');
            
            voPersonInfo.age = document.myApplet.getInfo('age');
            voPersonInfo.birthDate = document.myApplet.getInfo('birthDate');
            voPersonInfo.cardNumber = document.myApplet.getInfo('cardNumber');
            voPersonInfo.cardType = document.myApplet.getInfo('cardType');
            voPersonInfo.issuerAgency = document.myApplet.getInfo('issuerAgency');
            voPersonInfo.issuerPlace = document.myApplet.getInfo('issuerPlace');
            voPersonInfo.prefixEN = document.myApplet.getInfo('prefixEN');
            voPersonInfo.firstNameEN = document.myApplet.getInfo('firstNameEN');
            voPersonInfo.middleNameEN = document.myApplet.getInfo('middleNameEN');
            voPersonInfo.surNameEN = document.myApplet.getInfo('surNameEN');
            voPersonInfo.middleNameTH = document.myApplet.getInfo('middleNameTH');
            voPersonInfo.requestNumber = document.myApplet.getInfo('requestNumber');
            voPersonInfo.sex = document.myApplet.getInfo('sex');
            voPersonInfo.version = document.myApplet.getInfo('version');
            
            return voPersonInfo;
        }
        catch (err)
        {
            //this.appletError("ไม่พบข้อมูลการอ่านบัตร Smart Card");
            this.AppletStatus = false;
        }
    },
    appletError: function(message)
    {
      //$("#myModalLabel").html("<h4>Smart Card not found<\/h4>");
      $("#modalConfirm").html(message);
      $("#modalButton").html("<button type='button' class='btn btn-warning btn-xs' data-dismiss='modal'><b>&nbsp;&nbsp;ตกลง&nbsp;&nbsp;<\/b><\/button>");
      $('#myModal').modal('show');
    }

  }
  // http://bootsnipp.com/snippets/featured/quotwaiting-forquot-modal-dialog   
  //https://github.com/ehpc/bootstrap-waitingfor

var waitingDialog = waitingDialog || (function($)
{
  'use strict';

  // Creating modal dialog's DOM
  var $dialog = $(
    '<div class="modal fade" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-hidden="true" style="overflow-y:visible;">' +
    '<div class="modal-dialog modal-m">' +
    '<div class="modal-content">' +
    '<div class="modal-header"><h3 style="margin:0;"></h3></div>' +
    '<div class="modal-body">' +
    '<div class="progress progress-striped active" style="margin-bottom:0;"><div class="progress-bar" style="width: 100%"></div></div>' +
    '</div>' +
    '</div></div></div>');

  return {
    /**
     * Opens our dialog
     * @param message Custom message
     * @param options Custom options:
     *           options.dialogSize - bootstrap postfix for dialog size, e.g. "sm", "m";
     *           options.progressType - bootstrap postfix for progress bar type, e.g. "success", "warning".
     */
    show: function(message, options)
    {
      // Assigning defaults
      if (typeof options === 'undefined')
      {
        options = {};
      }
      if (typeof message === 'undefined')
      {
        message = 'Loading';
      }
      var settings = $.extend(
      {
        dialogSize: 'm',
        progressType: '',
        onHide: null // This callback runs after the dialog was hidden
      }, options);

      // Configuring dialog
	  var d = $dialog.find('.modal-dialog'); //แก้ Bug Modal Dialog load ครั้งแรกไม่ Center
     // $dialog.find('.modal-dialog').attr('class', 'modal-dialog').addClass('modal-' + settings.dialogSize);
	  d.attr('class', 'modal-dialog').addClass('modal-' + settings.dialogSize);
	  var dh = d.height();
		//	alert(dh);
            //dh = d.height(),
          var  w = $(window).width();
          var  h = $(window).height();
			
        // if it is desktop & dialog is lower than viewport
        // (set your own values)
        //alert("h="+h+"     dh="+dh);
        if (w > 380 && (dh + 60) < h) {
            d.css('margin-top', Math.round(0.96 * (h - dh) / 2));
        } else {
            d.css('margin-top', '');
        }
      $dialog.find('.progress-bar').attr('class', 'progress-bar');
      if (settings.progressType)
      {
        $dialog.find('.progress-bar').addClass('progress-bar-' + settings.progressType);
      }
      $dialog.find('h3').text(message);
      // Adding callbacks
      if (typeof settings.onHide === 'function')
      {
        $dialog.off('hidden.bs.modal').on('hidden.bs.modal', function(e)
        {
          settings.onHide.call($dialog);
        });
      }
	  
      // Opening dialog
     // setModalCenter();
      $dialog.modal();
    },
    /**
     * Closes dialog
     */
    hide: function()
    {
      $dialog.modal('hide');
      $("body").removeClass("modal-open");
      $(".modal-backdrop").remove();
    }
  };

})(jQuery);