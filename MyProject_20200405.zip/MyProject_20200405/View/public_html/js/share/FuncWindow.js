/*----------------------------------------------------------------------
 Script Name : FuncWindow.js
 Date : 08/07/2558*/

// parameter
// url - Optional. Specifies the URL of the page to open. If no URL is specified, a new window with about:blank is opened
// height - The height of the window. Min. value is 100
// width - The width of the window. Min. value is 100
// target - Optional. Specifies the target attribute or the name of the window. The following values are supported
//       1 _blank - URL is loaded into a new window. This is default
//       2 _parent - URL is loaded into the parent frame
//       3 _self - URL replaces the current page
//       4 _top - URL replaces any framesets that may be loaded
//
// Example
//    winOpen("www.google.com");
//    winOpen("www.google.com", 800, 600);
//    winOpen("www.google.com", 800, 600, "_self");
//

function winOpen(url, width, height, target) 
{
   url = url.substring(0, url.indexOf('?')+1)+escapeAll(url.substring(url.indexOf('?')+1)).replace(/%26/g, '&').replace(/%3D/g, '=');
   
   wLeft = window.screenLeft ? window.screenLeft : window.screenX;
   wTop = window.screenTop ? window.screenTop : window.screenY;
   
   width = width == null ? window.screen.availWidth/1.5 : width ;
   height = height == null ? window.screen.availHeight/1.5 : height ;
   target = target == null ? "_blank" : target ;

   var left = wLeft + (window.innerWidth / 2) - (width / 2);
   var top = wTop + (window.innerHeight / 2) - (height / 2);
   
   //return window.open(url, target, 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=' + w + ', height=' + h + ', top=' + top + ', left=' + left);
   var win = window.open(url, target, 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=yes, copyhistory=no, width=' + width + ', height=' + height + ', top=' + top + ', left=' + left);

   return win;
}


function escapeAll(str) 
{
   var hexString = "";
   var h = '';
   for (var index in str) 
   {
      var charCode = str.charCodeAt(index);
      if(charCode >= 3585 && charCode <= 3675)
      {
         h = encodeURIComponent(str.substring(index, parseInt(index)+1));
      }
      else
      {
         h = charCode.toString(16).toUpperCase();
         if (h.length == 1) 
         {
            h = "0" + h;
         }
         // insert a % character into the string
         h = "%" + h;
      }
      hexString += h;
   }
   return hexString;
}
