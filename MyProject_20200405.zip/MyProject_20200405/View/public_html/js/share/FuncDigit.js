/*----------------------------------------------------------------------
 Script Name : FuncDigit.js
 Create Date  : 02/10/2549
 Modify Date  : 05/10/2549
 Description   : To Check Digit
---------------------------------------------------------------------*/

//Check Company Tax Number key 10 Integer to Function
// parameter		:		tax typeof String
// return					:		boolean
function checkCompanyTaxNoDigit(tax)
{
	var taxPat =  /^(\d{10})?$/;
	var matchArray = null;
	var taxArray = null;
	var numAll = 0;
	var numChk = 0;
	if(tax == undefined)
	{
		alert("Please input company tax number");
		return false;
	}
	else
	{
		tax += "";
		matchArray = tax.match(taxPat);
		if(matchArray == null)
		{
			alert("Please input format 9999999999");
			return false;
		}
		else
		{
			taxArray = tax.split("");
			for(i = 0; i < 10 ; i++)
			{
				if(i == 9)
				{
					continue;
				}
				else
				{
					if( (i % 2) == 1)
					{
						numAll += (taxArray[i] * 1);
					}
					else
					{
						numAll += (taxArray[i] * 3);
					}
				}
			}
			numChk = numAll % 10;
			numChk = numChk == 0 ? 10 : numChk;
			if((10 - numChk) == taxArray[9] )
			{
				return true;
			}
			else
			{
				return false;
			}
		}
	}
}

//Check Social Id key 13 Integer to Function
// parameter		:		socialID typeof String
// return					:		boolean
function checkDigitSocialID(socialID)
{
   if(socialID == '')
   {
      return true;
   }
    var i = 0;
  	var j = 14;
    var digit = 0;
    var sum = 0;
    var endDigit = 0;

    while(i < 12){
      i = i + 1;
      j = j - 1;
      digit = socialID.substring(i-1,i);
      sum = sum + (digit*j);

    }

    endDigit = 11 - (sum - Math.floor(sum/11)*11);

    var EndDigit = endDigit+"";

	if (EndDigit.length == 2)
	{
		
		if (endDigit == 10)
		{
			endDigit = 0;
		}
		else
		{
			endDigit = EndDigit.substring(1,2);
		}
    }

    if (endDigit != socialID.substring(12,13))
	{
		return false;
    }
    else
	{
		return true;
    }

}