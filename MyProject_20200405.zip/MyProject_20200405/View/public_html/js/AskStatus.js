var AskStatus = '';
$(document).ready(function ()
{    
  
  setFieldPattern("CompanyIDSrh", "0010000");

 $("#CompanyIDSrh").on("blur", function (e)
    {
        if (this.value != '' && this.value.length != 13)
        {
            $("#gobleModalFocus").val('CompanyIDSrh');
            $("#modalConfirm").html("กรุณาระบุเลขทะเบียนนิติบุคคล 13 หลัก");
            $("#modalButton").html("<button type=\"button\" class=\"btn btn-primary btn-sm raised\" data-dismiss=\"modal\"><b>&nbsp;&nbsp;ตกลง&nbsp;&nbsp;<\/b><\/button>");
            $('#myModal').modal('show');
        }
     });
    afterLoad();
    
});
//---------------1.กดปุ่ม---------------------
function verify(paAct)
{
  if (paAct == 'SRH')
  {
    searchData();
  }
    else if (paAct == 'CLR'||paAct == 'NEW')
  {
    newData();
  }
}
function newData()
{
  $("#act").val('NEW');
  $("#CompanyIDSrh").val('');
  $("#frmAskstatus").submit();
}

function callJuristic()
{

     
   if($("#CompanyIDSrh").val()=='')
   {
      $("#gobleModalFocus").val('CompanyIDSrh');
      $("#modalConfirm").html("กรุณาระบุ เลขทะเบียนนิติบุคคล");
      $("#modalButton").html("<button type=\"button\" class=\"btn btn-primary btn-sm raised\" data-dismiss=\"modal\"><b>&nbsp;&nbsp;ตกลง&nbsp;&nbsp;<\/b><\/button>");
      $('#myModal').modal('show');
   }
   else
   {       
      $.ajax(
      {
         cache : false
         , url : '../DBDJuristicServlet'
         , data :{ act : "DBD", JuristicID : $("#CompanyIDSrh").val()}
         , type : 'POST'
         , success : function (data)
         {
            //closeLoading();
            
            if(data != ''&& data != null)
            {
                //alert(JSON.stringify(data));
               $("#referenceIdDBD").val(data.referenceIdDBD);
               //alert(JSON.stringify(data.errMsg));
               if(data.errMsg!='' && data.errMsg.length!=0)
               {
                    alert(data.errMsg);
                  
                  $("#modalConfirm").html(data.errMsg);
                  $("#modalButton").html("<button type=\"button\" class=\"btn btn-primary btn-xs raised\" data-dismiss=\"modal\"><b>&nbsp;&nbsp;ตกลง&nbsp;&nbsp;<\/b><\/button>");
                  $('#myModal').modal('show');
               }
               else
               {
              // alert(JSON.stringify(data.returnStatus));
                  if(data.returnStatus!=200)
                  {
                      
                  $("#modalConfirm").html("ไม่พบข้อมูลที่ต้องการค้นหา");
                  $("#modalButton").html("<button type=\"button\" class=\"btn btn-primary btn-xs raised\" data-dismiss=\"modal\"><b>&nbsp;&nbsp;ตกลง&nbsp;&nbsp;<\/b><\/button>");
                  $('#myModal').modal('show');
                  }
                  else
                    {       
                    //alert(JSON.stringify(data.returnData));
                       var object = JSON.parse(data.returnData);
                       displayJuristic501(object);
                  }
               }
            }
            else
            {
              
               $("#modalConfirm").html("ไม่พบข้อมูลที่ต้องการค้นหา");
               $("#modalButton").html("<button type=\"button\" class=\"btn btn-primary btn-xs raised\" data-dismiss=\"modal\"><b>&nbsp;&nbsp;ตกลง&nbsp;&nbsp;<\/b><\/button>");
               $('#myModal').modal('show');
            }
         }
         , error : function (xhr, status, error)
         {
           
           alert("An AJAX error occured: " + status + "\nError: " + error + "\nError detail: " + xhr.responseText);
         } 
       
      });
     
   }
}
function displayJuristic501(jsonObject)
{
//alert(jsonObject.data.JuristicName_TH)
  $("#juristicName_TH").val(jsonObject.data.JuristicName_TH);
  $("#juristicName_EN").val(jsonObject.data.JuristicName_EN);
  $("#juristicID").val(jsonObject.data.JuristicID);
  $("#oldJuristicID").val(jsonObject.data.OldJuristicID);
  $("#registerCapital").val(jsonObject.data.RegisterCapital);
  $("#juristicStatus").val(jsonObject.data.JuristicStatus);
      
   //AddressInformations
   
   //End AddressInformations
}

