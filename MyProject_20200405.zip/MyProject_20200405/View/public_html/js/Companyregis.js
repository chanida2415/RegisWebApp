var jqGridCompany = '';
$(document).ready(function ()
{    
  setFormatNumber("RegCap", "#,##0.00");
   $("#RegCap").decimal(20, 2);
  
  setFormatNumber("RegCapSrh", "#,##0.00");
  $("#RegCapSrh").decimal(20, 2);
  
  setFieldPattern("CompanyID", "0010000");
  setFieldPattern("CompanyTH", "0111100");
  setFieldPattern("CompanyEN", "1011100");
  setFormatTel("Phone", 3);
  
    if ($("#CompanyIDSRH").val() == '' && $("#act").val() != 'NEW'
    && $("#act").val() != 'ADD' && $("#act").val() != 'ADDRTN' && $("#act").val() != 'ADDERR' 
    && $("#act").val() != 'UPD' && $("#act").val() != 'ADDRTN' && $("#act").val() != 'UPDERR'
    && $("#act").val() != 'DEL' && $("#act").val() != 'DELRTN' && $("#act").val() != 'DELERR')
    {
        $("#barSearch").show();
        $("#gridSearch").show();
        $("#form1").hide();
        $("#form2").hide();
        createGrid();
        $("#CompanyIDSrh").focus();
    }
  else 
  {
    $("#barSearch").hide();
    $("#gridSearch").hide();
    $("#form1").show();
    $("#form2").show();
    $("#CompanyID").focus();
 
    if ($("#act").val() == '' || $("#act").val() == 'NEW' || $("#act").val() == 'ADDERR')
    {
        $("#DEL").hide();
        $("#UPD").hide();
    }
    else if ($("#act").val() == 'ADDRTN' || $("#act").val() == 'UPDRTN')
    {
            $("#ADD").hide();
    }
    else 
    {           
           $("#ADD").hide();
    }
  }
  //---------------email---------------------
  $('#Mail').on("keyup", function (e)
  {
    //alert(this.value);
    if (checkEmail(this.value))
    {
      $("#Mail").removeClass("is-invalid");
    }
    else 
    {
      $("#Mail").addClass("is-invalid");
    }
  });
  
  $('#Mail').on("blur", function (e)//เมื่อมีกดแจ้งเตือน on blur ต้องเพิ่มส่วน modal ในหน้า jsp
  {
    if (checkEmail(this.value))
    {
      $("#Mail").removeClass("is-invalid");
    }
    else 
    {
      $("#gobleModalFocus").val('Mail');
      $("#modalConfirm").html("กรุณาระบุ E-mail ให้ถูกต้อง");
      $("#modalButton").html("<button type=\"button\" class=\"btn btn-primary btn-sm raised\" data-dismiss=\"modal\"><b>&nbsp;&nbsp;ตกลง&nbsp;&nbsp;<\/b><\/button>");
      $('#myModal').modal('show');
    }
    
  });
  
   setFormatDate("DayCap", 3);
    $('#calendarDate').click(function () {
            $('#DayCap').datepicker('show');
    }); 
    setFormatDate("DayCapSrh", 3);
    $('#calendarDateSrh').click(function () {
            $('#DayCapSrh').datepicker('show');
    }); 
    
    $("#CompanyID").on("blur", function (e)
    {
        if (this.value != '' && this.value.length != 13)
        {
            $("#gobleModalFocus").val('CompanyID');
            $("#modalConfirm").html("กรุณาระบุเลขทะเบียนนิติบุคคล 13 หลัก");
            $("#modalButton").html("<button type=\"button\" class=\"btn btn-primary btn-sm raised\" data-dismiss=\"modal\"><b>&nbsp;&nbsp;ตกลง&nbsp;&nbsp;<\/b><\/button>");
            $('#myModal').modal('show');
        }
     });
    setDDList();
    afterLoad();
});


//---------------1.กดปุ่ม---------------------
function verify(paAct)
{
  if (paAct == 'SRH')
  {
    searchData();
  }
  if (paAct == 'OPNSRH')
  {
    openBarSearch();
  }
  else if (paAct == 'ADD')
  {
    addData();
  }
  else if (paAct == 'CLR'||paAct == 'NEW')
  {
    newData();
  }
  else if (paAct == 'UPD')
  {
    editData();
  }
  else if (paAct == 'DEL')
 {
    confirmDelete();
 }
}
//---------------2. if(paAct == 'ADD') addData();---------------------
function addData()
{
  if (validateData())
  {
    $("#act").val('ADD');
    $("#frmCMPREG").submit();
  }
}
function openBarSearch()
{
  $("#barSearch").show();
  $("#gridSearch").show();
  $("#CompanyIDSrh").focus();
  $("#form1").hide();
  $("#form2").hide();
  if (jqGridCompany == '')
  {
    createGrid();
  }
}

function newData()
{
  $("#act").val('NEW');
  $("#CompanyID").val('');
  $("#frmCMPREG").submit();
}

function editData()
{
  if (validateData())
  {
    $("#act").val('UPD');
    $("#frmCMPREG").submit();
  }
}
function confirmDelete()
{
   $("#modalConfirm").html("คุณต้องการลบข้อมูลนี้หรือไม่");
   $("#modalButton").html("<button type=\"button\" class=\"btn btn-primary btn-sm raised\" data-dismiss=\"modal\"><b>&nbsp;&nbsp;ยกเลิก&nbsp;&nbsp;<\/b><\/button><button type=\"button\" class=\"btn btn-primary btn-sm raised\" data-dismiss=\"modal\" onclick=\"deleteData();\"><b>&nbsp;&nbsp;ตกลง&nbsp;&nbsp;<\/b><\/button>");
   $('#myModal').modal('show');
}
function deleteData()
{
    $("#act").val('DEL');
    $("#frmCMPREG").submit();
}

function getData(id)
{
  rowData = jqGridCompany.getRowData(id);
  $("#CompanyID").val(rowData.companyId);
  
  $("#act").val('INQ');
  $("#frmCMPREG").submit();
}
function searchData()
{
  jqGridCompany.setGridParam(
  {
    url : "../reg/CompanyRegisServlet?" + $("#frmCMPREG").serialize(), page : 1
  });
  jqGridCompany.trigger("reloadGrid")
}


//---------------3. if(validateData())---------------------
function validateData()
{
  var vbRsl = false;
  var vaErrMsg = "กรุณาระบุ";
  var vaFocus = "";
  $("#CompanyID").removeClass("is-invalid");
  $("#CompanyTH").removeClass("is-invalid");
  $("#CompanyTYP").removeClass("is-invalid");
  $("#RegCap").removeClass("is-invalid");
  $("#provinceIdDtl").removeClass("is-invalid");
  $("#amphurDtl").removeClass("is-invalid");
  $("#districtDtl").removeClass("is-invalid");
  $("#zipcode").removeClass("is-invalid");
 // $("#hireDateDIV").removeClass("is-invalid");

  if ($("#CompanyID").val() == '')
  {
    if (vaErrMsg != "กรุณาระบุ"){ vaErrMsg = vaErrMsg + " , ";}
    vaErrMsg = vaErrMsg + " เลขทะเบียนนิติบุคคล ";
    if (vaFocus == "")
    {
      vaFocus = "CompanyID";
    }
    $("#CompanyID").addClass("is-invalid");
  }
  
  if ($("#CompanyTYP").val() == '')
  {
    if (vaErrMsg != "กรุณาระบุ") vaErrMsg = vaErrMsg + ",";
    vaErrMsg = vaErrMsg + " ประเภทธุรกิจ";
    if (vaFocus == "")
    {
      vaFocus = "CompanyTYP";
    }
    $("#CompanyTYP").addClass("is-invalid");
  }
  if ($("#CompanyTH").val() == '')
  {
    if (vaErrMsg != "กรุณาระบุ") vaErrMsg = vaErrMsg + ",";
    vaErrMsg = vaErrMsg + " ชื่อสถานประกอบการ(ภาษาไทย) ";
    if (vaFocus == "")
    {
      vaFocus = "CompanyTH";
    }
    $("#CompanyTH").addClass("is-invalid");
  }
  



  if ($("#RegCap").val() == '')
  {
    if (vaErrMsg != "กรุณาระบุ") vaErrMsg = vaErrMsg + ",";
    vaErrMsg = vaErrMsg + " ทุนจดทะเบียน ";
    if (vaFocus == "")
    {
      vaFocus = "RegCap";
    }
    $("#RegCap").addClass("is-invalid");
  }
  if ($("#provinceIdDtl").val() == '')
        {
            if (vaErrMsg != "กรุณาระบุ") vaErrMsg = vaErrMsg + ",";
            vaErrMsg = vaErrMsg + " จังหวัด  ";
            if (vaFocus == "")
            {
                vaFocus = "provinceIdDtl";
            }
           $("#provinceIdDtl").addClass("is-invalid");
        }
        if ($("#amphurNameDtl").val() == '')
        {
            if (vaErrMsg != "กรุณาระบุ") vaErrMsg = vaErrMsg + ",";
            vaErrMsg = vaErrMsg + " เขต/อำเภอ  ";
            if (vaFocus == "")
            {
                vaFocus = "amphurDtl";
            }
         $("#amphurDtl").addClass("is-invalid");

        }
        if ($("#districtNameDtl").val() == '')
        {
            if (vaErrMsg != "กรุณาระบุ") vaErrMsg = vaErrMsg + ",";
            vaErrMsg = vaErrMsg + " แขวง/ตำบล  ";
            if (vaFocus == "")
            {
                vaFocus = "districtDtl";
            }
          $("#districtDtl").addClass("is-invalid");
        }
          if ($("#zipcode").val() == '')
        {
            if (vaErrMsg != "กรุณาระบุ") vaErrMsg = vaErrMsg + ",";
            vaErrMsg = vaErrMsg + " รหัสไปรษณีย์  ";
            if (vaFocus == "")
            {
                vaFocus = "zipcode";
            }
         $("#zipcode").addClass("is-invalid");

        }

  if (vaErrMsg != 'กรุณาระบุ')
  {
    $("#reloading").html("<div class=\"alert alert-warning\" style=\"text-align:center;margin-bottom: 5px;\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">&times;<\/button>" + vaErrMsg + "<\/div>");
    $("#" + vaFocus).focus();
    $('html, body').animate({scrollTop : 0},0);
    return false;
    //ต้องเพิ่ม <div id="reloading"> ในหน้า jsp
  }
  else 
  {
    vbRsl = true;
  }
  return vbRsl;

}
//---------------createGrid---------------------
function createGrid()
{
jqGridCompany = jQuery("#masterGrid");
 $('#act').val('SRH');
jqGridCompany.jqGrid({ url : "../reg/CompanyRegisServlet?act=SRH"//+$("#frmRQ01080E").serialize()->คือการส่งข้อมูลแบบยกฟอร์มคือการsubmitจอ
, datatype : "json", mtype : 'POST'
, colNames : ['', 'เลขทะเบียนนิติบุคคล', 'ชื่อนิติบุคคล', 'ประเภทธุรกิจ', 'ทุนจดทะเบียน(บาท)', 'วันที่จดทะเบียน(บาท)']//
, colModel : [
    {
      name : 'act', index : 'act', width : '5%', align : 'center', sortable : false, formatter : function (cellval, options, rowObject)
      {
return "<span class=\"glyphicon glyphicon-pencil\" style=\"cursor:pointer;\" onclick=\"getData('" + options.rowId + "');\"><\/span>";
      }
    }
    //ดินสอ
, /*nameคือชื่อที่อยู่ในjpaที่เราreturn ในรูปของString(ต้องมีmethod tostring ใน Employee.java ) ก็คือชื่อที่อยู่ในEntity(Employee.java)*///index คือตัวที่เราจะส่งไปsort หรือ order by//index : 'aoEmployees.employeeId' ถ้าเป็นDAOเป็น sql จะใช้aoEmployees.employee_Idตามชื่อcloumnในตาราง
    {
      name : 'companyId', index : 'aoCmpinfo.companyId', align : 'center', width : '12%'
    },
    {
      name : 'companyTh', index : 'aoCmpinfo.companyTh', align : 'left', width : '30%'
    },
    {
      name : 'companyType', index : 'aoCmpinfo.companyType', align : 'left', width : '10%'
    },
    {
      name : 'regCapital', index : 'aoCmpinfo.regCapital', align : 'right', width : '10%'
    },
    {
      name : 'regDate', index : 'aoCmpinfo.regDate', align : 'center', width : '10%'
    }]
    , height : 300, width : 700, rowNum : 20, rowList : [20, 40, 100], sortable : true//ให้เรียงลำดับได้
    //, sortname: 'system_code'
, multiSort : true//ให้เรียงลำดับได้> 1
    //, sortorder: 'desc'
    //, loadonce : true // loading all data in one time
, autoencode : true, pager : "#masterGridPager", viewrecords : true// display the number of total records from the query in the pager bar  เลขด้านล่าง
, multiselect : false//กดติ๊กได้มากกว่า
, rownumbers : true//เลขด้านหน้าตาราง
, loadComplete : function (data)//โหลดเเล้วจะคืนดาต้ามาตัวนึง
    {
     
      if (jqGridCompany.getGridParam("reccount") == 0)//ถ้าgridเราไม่มีค่า
      {
        if ($("#reloading").html() != "")
        {
          $("#reloading").delay(3000).fadeOut();
          $("#reloading").stop();
          $("#reloading").fadeIn(0);
        }
        $("#reloading").html("<div class='alert alert-warning alert-dismissable' style='text-align: center; margin-bottom: 5px;'>" + "<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button><b>ไม่พบข้อมูลที่ต้องการค้นหา<\/b></div>");
      }
      else if (jqGridCompany.getGridParam("reccount") != 0)//ถ้าgridเรามีrecord
      {
        if ($("#delMulti").val() != 0)
        {
          //#delMulti คือ id ของ div ลบข้อมูลเรียบร้อยแล้ว
          $("#reloading").html("");
        }
        else if ($("#delMulti").val() == 0)
        {
          $("#delMulti").val(1);
        }
      }
      $("#CompanyIDSrhDiv").focus();//ให้ไปโฟกัสที่ฟิล 

    }
    
  });
setTimeout(function ()//หน่วงเวลา
  {
    $("#masterGrid").setGridWidth(parseInt($("#form_body").width()) - 20);//setขนาดของbody-20 หน่วงเวลาเพื่อให้ปรับขนาดgrid
  },
330);

  $(window).bind('resize', function ()
  {
    $("#masterGrid").setGridWidth($("#form_body").width() - 20);//เมื่อมีการresize window ให้resize grid ให้เราด้วย
  }).trigger('resize');
};


function setDDList()
{
    
            $("#provinceIdDtl").select2({
		ajax: {
			url: "../CentralServlet?act=SRHPRV",
			dataType: 'json',
			//term คือค่าที่ Key เข้ามาใน dropDownList
			data: function(term, page) {
				return {
					ProvinceName : term
					
				};
			},
			results: function(data, page ) {
				//alert("2"+data[0].text);
				//var test = [{text:data.objectName, children:[{id:data.objectCode, text:data.objectName}]}];
				return { results: data }
			}
		}
		//, width:'300px'
		//, formatResult: formatList
		, allowClear: true
		, placeholder: "กรุณาเลือก"
		, initSelection: function (element, callback) {
            return $.getJSON("../CentralServlet?act=SRHPRV", function(data) {
            
               provinceId = '';
               provinceName = '';
               if(typeof(data) !== 'undefined' && data.length > 0)
               {
               
                  for(i=0; i<data.length; i++)
                  {
                     provinceArray = data[i].id.split(":");
                     if(provinceArray[0] == element.val()) {provinceId = provinceArray[0]; provinceName = provinceArray[1]; break;}
                  }
               }
            
               return callback({ id: provinceId, text: provinceName });
            });
		}
	}).on('change', function(){
		$("#amphurDtl").select2("val", "");
		$("#districtDtl").select2("val", "");
		if($(this).select2("val").trim() == '')
		{
			$("#amphurDtl").select2("readonly", true);
			$("#amphurCodeDtl").val('');
			$("#amphurNameDtl").val('');
			
			$("#districtDtl").select2("readonly", true);
			$("#districtCodeDtl").val('');
			$("#districtNameDtl").val('');
                        $("#zipcodeDtl").val('');
		}
		else
		{
		    $("#amphurDtl").select2("readonly", false);
                    $("#amphurCodeDtl").val('');
                    $("#amphurNameDtl").val('');
                    
                    $("#districtDtl").select2("readonly", true);
                    $("#districtCodeDtl").val('');
                    $("#districtNameDtl").val('');
                    $("#zipcodeDtl").val('');
                    
                    $("#amphurDtl").select2('focus');
                        
		    var provinceArray = $(this).select2("val").split(":");
		    
		    $("#provinceCodeDtl").val(provinceArray[0]);
		    $("#provinceNameDtl").val(provinceArray[1]);
                    
                    $("#amphurDtl").select2('focus');
		}
		
	});
            
            
	//----- อำเภอ
	$("#amphurDtl").select2({
		ajax: {
			url: "../CentralServlet?act=SRHAMPHUR",
			dataType: 'json',
			//term คือค่าที่ Key เข้ามาใน dropDownList
			data: function(term, page) {
				return {
					AmphurName : term
					, ProvinceCode : $("#provinceCodeDtl").val()
				};
			},
			results: function(data, page ) {
				//alert(data[0].text);
				//var test = [{text:data.objectName, children:[{id:data.objectCode, text:data.objectName}]}];
				return { results: data }
			}
		}
		//, width:'300px'
		//, formatResult: formatList
		, allowClear: true
		, placeholder: "กรุณาเลือก"
		, initSelection: function (element, callback) {
            return $.getJSON("../CentralServlet?act=SRHAMPHUR", {ProvinceCode : $("#provinceCodeDtl").val()}, function(data) {
               amphurId = '';
               amphurName = '';
               if(typeof(data) !== 'undefined' && data.length > 0)
               {
                  for(i=0; i<data.length; i++)
                  {
                     amphurArray = data[i].id.split(":");
                     if(amphurArray[0] == element.val()) {amphurId = amphurArray[0]; amphurName = amphurArray[1]; break;}
                  }
               }
            
               return callback({ id: amphurId, text: amphurName });
            });
		}
	}).on('change', function(){
		$("#districtDtl").select2("val", "");
		if($(this).select2("val").trim() == '')
		{
		    $("#amphurCodeDtl").val('');
		    $("#amphurNameDtl").val('');
    
		    $("#districtDtl").select2("readonly", true);
		    $("#districtCodeDtl").val('');
		    $("#districtNameDtl").val('');
	
		    $("#zipcodeDtl").val('');
		}
		else
		{
		    $("#districtDtl").select2("readonly", false);
		    $("#districtCodeDtl").val('');
		    $("#districtNameDtl").val('');
            
		    $("#zipcodeDtl").val('');
		    
		    var amphurArray = $(this).select2("val").split(":");
		    
		    $("#amphurCodeDtl").val(amphurArray[0]);
		    $("#amphurNameDtl").val(amphurArray[1]);
			$("#districtDtl").select2('focus');
		}
		
	});
	
	//----- ตำบล
	$("#districtDtl").select2({
		ajax: {
			url: "../CentralServlet?act=SRHDISTRICT",
			dataType: 'json',
			//term คือค่าที่ Key เข้ามาใน dropDownList
			data: function(term, page) {
				return {
					DistrictName : term
					, ProvinceCode :  $("#provinceCodeDtl").val()
					, AmphurCode : $("#amphurCodeDtl").val()
				};
			},
			results: function(data, page ) {
				//alert(data[0].text);
				//var test = [{text:data.objectName, children:[{id:data.objectCode, text:data.objectName}]}];
				return { results: data }
			}
		}
		//, width:'300px'
		//, formatResult: formatList
		, allowClear: true
		, placeholder: "กรุณาเลือก"
		, initSelection: function (element, callback) {
			return $.getJSON("../CentralServlet?act=SRHDISTRICT", {ProvinceCode : $("#provinceCodeDtl").val(), AmphurCode : $("#amphurCodeDtl").val()}, function(data) {
               districtId = '';
               districtName = '';
               if(typeof(data) !== 'undefined' && data.length > 0)
               {
                  for(i=0; i<data.length; i++)
                  {
                     districtArray = data[i].id.split(":");
                     if(districtArray[0] == element.val()) {districtId = districtArray[0]; districtName = districtArray[1]; $("#zipcode").val(districtArray[2]); break;}
                  }
               }
            
               return callback({ id: districtId, text: districtName });
            });
		}
	}).on('change', function(){
		if($(this).select2("val").trim() == '')
		{
		   $("#districtCodeDtl").val('');
                $("#districtNameDtl").val('');
    
                $("#zipcode").val('');
		}
		else
		{
		   var districtArray = $(this).select2("val").split(":");
                
                $("#districtCodeDtl").val(districtArray[0]);
                $("#districtNameDtl").val(districtArray[1]);
                $("#zipcode").val(districtArray[2]);
                $("#zipcode").focus();
		}
		 
	});
    
   if($("#provinceIdDtl").val()=='')
    {
		$("#amphurDtl").select2("readonly", true);
    }
    if($("#amphurCodeDtl").val()=='')
    {
		$("#districtDtl").select2("readonly", true);
    }
	
    //----- set ค่าตอน Inquiry มาแสดงที่จอภาพ
   if($("#provinceCodeDtl").val() != '')
    {
        $('#provinceIdDtl').select2('data', {id:$("#provinceCodeDtl").val(), text:$("#provinceCodeDtl").val()+' - '+$("#provinceNameDtl").val()});
    }
    if($("#amphurCodeDtl").val() != '')
    {
        $('#amphurDtl').select2('data', {id:$("#amphurCodeDtl").val(), text:$("#amphurCodeDtl").val()+' - '+$("#amphurNameDtl").val()});
    }
    if($("#districtCodeDtl").val() != '')
    {
        $('#districtDtl').select2('data', {id:$("#districtCodeDtl").val(), text:$("#districtCodeDtl").val()+' - '+$("#districtNameDtl").val()});
    }
}
//--กรมพัฒนาธุรกิจการค้า--
function openModalDBD()
{
  $("#JuristicL").modal('show');
}
function callJuristic()
{
    JuristicL.formName = 'frmCMPREG';
    JuristicL.returnCompanyId = 'CompanyID';
    JuristicL.returnCompanyNameTh = 'CompanyTH';
    JuristicL.returnCompanyNameEn = 'CompanyEN';
    JuristicL.returnCompanytype = 'CompanyTYP';
    JuristicL.returnRegCap = 'RegCap';
    JuristicL.returnDayReg = 'DayCap';
    JuristicL.returnTimeReg = 'TimeReg';
    JuristicL.returnRoomNo = 'RoomNo';
    JuristicL.returnMoo = 'Moo';
    JuristicL.returnVillageName = 'VillageName';
    JuristicL.returnBuilding = 'Building';
    JuristicL.returnSoi = 'Soi';
    JuristicL.returnRoad = 'Road';
    JuristicL.returnProvinceCode = 'provinceCodeDtl';
    JuristicL.returnProvinceName = 'provinceNameDtl';
    JuristicL.returnAmphurCode = 'amphurCodeDtl';
    JuristicL.returnAmphurName = 'amphurNameDtl';
    JuristicL.returnDistrictCode = 'districtCodeDtl';
    JuristicL.returnDistrictName = 'districtNameDtl';
    JuristicL.returnZipCode = 'zipcode';
     
   if($("#CompanyID").val()=='')
   {
      $("#gobleModalFocus").val('CompanyID');
      $("#modalConfirm").html("กรุณาระบุ เลขทะเบียนนิติบุคคล");
      $("#modalButton").html("<button type=\"button\" class=\"btn btn-primary btn-sm raised\" data-dismiss=\"modal\"><b>&nbsp;&nbsp;ตกลง&nbsp;&nbsp;<\/b><\/button>");
      $('#myModal').modal('show');
   }
   else
   {       
      $.ajax(
      {
         cache : false
         , url : '../DBDJuristicServlet'
         , data :{ act : "DBD", JuristicID : $("#CompanyID").val()}
         , type : 'POST'
         , success : function (data)
         {
            //closeLoading();
            
            if(data != ''&& data != null)
            {
                //alert(JSON.stringify(data));
               $("#referenceIdDBD").val(data.referenceIdDBD);
               //alert(JSON.stringify(data.errMsg));
               if(data.errMsg!='' && data.errMsg.length!=0)
               {
                    $("#JuristicL").modal('show');
                  $("#JuristicReloadingDialog").html("<div class=\"alert alert-warning\" style=\"text-align:center;margin-bottom: 5px;\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">&times;<\/button>"+data.errMsg+"<\/div>");
               }
               else
               {
              // alert(JSON.stringify(data.returnStatus));
                  if(data.returnStatus!=200)
                  {
                    $("#JuristicL").modal('show');
                    $("#JuristicReloadingDialog").html("<div class=\"alert alert-warning\" style=\"text-align:center;margin-bottom: 5px;\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">&times;<\/button>"+"ไม่พบข้อมูลที่ต้องการค้นหา"+"<\/div>");
                  }
                  else
                    {       
                    //alert(JSON.stringify(data.returnData));
                        var object = JSON.parse(data.returnData);
                        //alert("obj "+JSON.stringify(object.data));
                        displayJuristicDialog(object.data);
                        $("#JuristicL").modal('show');
                  }
               }
            }
            else
            {
              $("#JuristicL").modal('show');
               $("#JuristicReloadingDialog").html("<div class=\"alert alert-warning\" style=\"text-align:center;margin-bottom: 5px;\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">&times;<\/button><b>ไม่พบข้อมูลที่ต้องการค้นหา</b><\/div>");
            }
         }
         , error : function (xhr, status, error)
         {
           
           alert("An AJAX error occured: " + status + "\nError: " + error + "\nError detail: " + xhr.responseText);
         } 
       
      });
     
   }
}
function CDVFormatDate(paDate, dateType) 
{
     var vaDate = paDate;
    var vDateType = 3;
    var year = vaDate.substring(0, 4);
    var Month = vaDate.substring(5, 7);
    var Day = vaDate.substring(8, 10);
    
    if (dateType != undefined)
    {
        vDateType = dateType;
    }

    if (vDateType == 3) {
    
        if (vaDate.length == 2 || vaDate.length == 16) 
        {
            vaDate = Day +"/"+ Month +"/"+ (parseInt(year)+543);
        }
           
        
        return vaDate;
    }
}
function CDVFormatTime(paDate) 
{
   var vaTime = paDate;
    var vaRtn = vaTime.substring(11);
    if(vaRtn == null)
    {
       vaTime ="";
    }
    else
    {
      if(vaRtn.length == 8)
        {
            alert("if"+vaRtn);
            vaTime = vaRtn;
        }
        else if(vaRtn.length ==5 )
        {
           vaTime = vaRtn + ":"+"00";
        }
    }
    return vaTime;
}
function displayJuristicDialog(jsonObject)
{

  $("#CompanyIDL").val(jsonObject.JuristicID);
  //alert("dasplay "+JSON.stringify(jsonObject.JuristicID));
   $("#CompanyTHL").val(jsonObject.JuristicName_TH);
   $("#CompanyENL").val(jsonObject.JuristicName_EN);
   $("#CompanyTYPL").val(jsonObject.JuristicType);
   $("#RegCapL").val(cnvToFormat(jsonObject.RegisterCapital,"#,###,##0.00"));
   $("#DayCapL").val(CDVFormatDate(jsonObject.RegisterDate, "3"));
    $("#TimeL").val(CDVFormatTime(jsonObject.RegisterDate));
   
   //AddressInformations
   jsonAddressLst = jsonObject.AddressInformations;
   if(jsonAddressLst!=null && Array.isArray(jsonAddressLst))
   {
      jsonAddress = jsonAddressLst[0];
      if(jsonAddress!=null && typeof jsonAddress == 'object')
      {
         $("#RoomNoL").val(jsonAddress.AddressNo);
         $("#mooL").val(jsonAddress.Moo);
         $("#VillageNameL").val(jsonAddress.VillageName);
         $("#BuildingL").val(jsonAddress.Building);
         $("#SoiL").val(jsonAddress.Soi);
         $("#RoadL").val(jsonAddress.Road);

         
         
         var province = jsonAddress.Province;
         if(province!=null && province!='')
       {
        
            setDBDProvinceL(province);
            if($("#provinceCodeDtlL").val()!='')
            {
                setDBDAmpurL(jsonAddress.Ampur);
                if($("#amphurCodeDtlL").val()!='')
                {
                    setDBDTumbolL(jsonAddress.Tumbol);
                }
            }
        }
         
      }
   }
}
function setDBDProvinceL(name)
{
   if(name!='')
   {
      name = name.split("จังหวัด").join("");

      $.ajax(
      {
         cache : false
         , async : false
         , url : '../CentralServlet'
         , data :{
                     act : "SRHPRV"
                     , ProvinceName : name
                  }
         , type : 'POST'
         , success : function (data)
         {
            if(typeof(data) !== 'undefined' && data.length > 0)
            {
               tmpArray = data[0].id.split(":");
         
               $("#provinceCodeDtlL").val(tmpArray[0]);
               $("#provinceNameDtlL").val(tmpArray[1]);
            }
            else
            {
               $("#provinceCodeDtlL").val('');
               $("#provinceNameDtlL").val('');
            }
         }
      });
   }
}
function setDBDAmpurL(name)
{
   if(name!='')
   {
   
      name = name.split("เขต").join("").split("อำเภอ").join("");
      
      $.ajax(
      {
         cache : false
         , async : false
         , url : '../CentralServlet'
         , data :{
                     act : "SRHAMPHUR"
                     , ProvinceCode : $("#provinceCodeDtlL").val()
                     , AmphurName : name
                  }
         , type : 'POST'
         , success : function (data)
         {
            if(typeof(data) !== 'undefined' && data.length > 0)
            {
               tmpArray = data[0].id.split(":");
                
               $("#amphurCodeDtlL").val(tmpArray[0]);
               $("#amphurNameDtlL").val(tmpArray[1]);
              
            }
            else
            {
                $("#amphurCodeDtlL").val('');
               $("#amphurNameDtlL").val('');
            }
         }
      });
   }
}
function setDBDTumbolL(name)
{
   if(name!='')
   {
      name = name.split("แขวง").join("").split("ตำบล").join("");
       
      $.ajax(
      {
         cache : false
         , async : false
         , url : '../CentralServlet'
         , data :{
                     act : "SRHDISTRICT"
                     , ProvinceCode : $("#provinceCodeDtlL").val()
                     , AmphurCode : $("#amphurCodeDtlL").val()
                     , DistrictName : name
                  }
         , type : 'POST'
         , success : function (data)
         {
            if(typeof(data) !== 'undefined' && data.length > 0)
            {
               tmpArray = data[0].id.split(":");
               
               $("#districtCodeDtlL").val(tmpArray[0]);
               $("#districtNameDtlL").val(tmpArray[1]);
               $("#zipcodeL").val(tmpArray[2]);
            }
            else
            {
             $("#districtCodeDtlL").val('');
               $("#districtNameDtlL").val('');
               $("#zipcodeL").val('');
              
            }
         }
      });
   }
}
function displayJuristic501(jsonObject)
{
   $("#companyName").val(jsonObject.JuristicName_TH);
   //AddressInformations
   jsonAddressLst = jsonObject.AddressInformations;
   if(jsonAddressLst!=null && Array.isArray(jsonAddressLst))
   {
      jsonAddress = jsonAddressLst[0];
      if(jsonAddress!=null && typeof jsonAddress == 'object')
      {
         $("#RoomNo").val(jsonAddress.AddressNo);
         $("#moo").val(jsonAddress.Moo);
         $("#VillageName").val(jsonAddress.VillageName);
         $("#Building").val(jsonAddress.Building);
         $("#Soi").val(jsonAddress.Soi);
         $("#Road").val(jsonAddress.Road);
         
         var province = jsonAddress.Province;
         if(province!=null && province!='')
         {
            setDBDProvince(province);
            if($("#provinceCodeDtl").val()!='')
            {
            setDBDAmpur(jsonAddress.Ampur);
               if($("#amphurCodeDtl").val()!='')
               {
            setDBDTumbol(jsonAddress.Tumbol);
               
            
         }
      }
   }
      }
   }
   //End AddressInformations
}
function setDBDProvince(name)
{
   if(name!='')
   {
      name = name.split("จังหวัด").join("");
      alert(name);
      $.ajax(
      {
         cache : false
         , async : false
         , url : '../CentralServlet'
         , data :{
                     act : "SRHPRV"
                     , ProvinceName : name
                  }
         , type : 'POST'
         , success : function (data)
         {
            if(typeof(data) !== 'undefined' && data.length > 0)
            {
            
               tmpArray = data[0].id.split(":");
               $("#provinceCodeDtl").val(tmpArray[0]);
               $("#provinceNameDtl").val(tmpArray[1]);
               $('#provinceIdDtl').select2('data', {id : tmpArray[0], text : tmpArray[0]+' - '+tmpArray[1]});
            
               $("#amphurDtl").select2("readonly", false);
               $("#amphurCodeDtl").val('');
               $("#amphurNameDtl").val('');
               $("#districtDtl").select2("readonly", true);
               $("#districtCodeDtl").val('');
               $("#districtNameDtl").val('');
            }
            else
            {
               clearSmartCardCompany('');
               $("#gobleModalFocus").val('CompanyID');
               $("#modalConfirm").html("จังหวัด ไม่อยู่ในพื้นที่ให้บริการของสาขา");
               $("#modalButton").html("<button type=\"button\" class=\"btn btn-primary btn-sm raised\" data-dismiss=\"modal\"><b>&nbsp;&nbsp;ตกลง&nbsp;&nbsp;<\/b><\/button>");
               $('#myModal').modal('show');
            }
         }
      });
   }
}
function setDBDAmpur(name)
{
   if(name!='')
   {
      name = name.split("เขต").join("").split("อำเภอ").join("");
      $.ajax(
      {
         cache : false
         , async : false
         , url : '../CentralServlet'
         , data :{
                     act : "SRHAMP"
                     
                     , ProvinceCode : $("#provinceCodeDtl").val()
                     , AmphurName : name
                  }
         , type : 'POST'
         , success : function (data)
         {
            if(typeof(data) !== 'undefined' && data.length > 0)
            {
               tmpArray = data[0].id.split(":");
               $("#amphurCodeDtl").val(tmpArray[0]);
               $("#amphurNameDtl").val(tmpArray[1]);
               $('#amphurDtl').select2('data', {id : tmpArray[0], text : tmpArray[0]+' - '+tmpArray[1]});
               
               $("#districtDtl").select2("readonly", false);
               $("#districtCodeDtl").val('');
               $("#districtNameDtl").val('');
            }
            else
            {
               clearSmartCardCompany('');
               $("#gobleModalFocus").val('CompanyID');
               $("#modalConfirm").html("เขต/อำเภอ ไม่อยู่ในพื้นที่ให้บริการของสาขา");
               $("#modalButton").html("<button type=\"button\" class=\"btn btn-primary btn-sm raised\" data-dismiss=\"modal\"><b>&nbsp;&nbsp;ตกลง&nbsp;&nbsp;<\/b><\/button>");
               $('#myModal').modal('show');
            }
         }
      });
   }
}
function setDBDTumbol(name)
{
   if(name!='')
   {
      name = name.split("แขวง").join("").split("ตำบล").join("");
      $.ajax(
      {
         cache : false
         , async : false
         , url : '../CentralServlet'
         , data :{
                     act : "SRHDIS"
                   
                     , ProvinceCode : $("#provinceCodeDtl").val()
                     , AmphurCode : $("#amphurCodeDtl").val()
                     , DistrictName : name
                  }
         , type : 'POST'
         , success : function (data)
         {
            if(typeof(data) !== 'undefined' && data.length > 0)
            {
               tmpArray = data[0].id.split(":");
               $("#districtCodeDtl").val(tmpArray[0]);
               $("#districtNameDtl").val(tmpArray[1]);
               $('#districtDtl').select2('data', {id : tmpArray[0], text : tmpArray[0]+' - '+tmpArray[1]});
               $("#zipcode").val(tmpArray[2]);
            }
            else
            {
               clearSmartCardCompany('');
               $("#gobleModalFocus").val('CompanyID');
               $("#modalConfirm").html("แขวง/ตำบล ไม่อยู่ในพื้นที่ให้บริการของสาขา");
               $("#modalButton").html("<button type=\"button\" class=\"btn btn-primary btn-sm raised\" data-dismiss=\"modal\"><b>&nbsp;&nbsp;ตกลง&nbsp;&nbsp;<\/b><\/button>");
               $('#myModal').modal('show');
            }
         }
      });
   }
}
//--END กรมพัฒนาธุรกิจการค้า--

    
	
