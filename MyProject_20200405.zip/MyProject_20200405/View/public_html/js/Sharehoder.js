var jqGridShareHoder = '';
$(document).ready(function ()
{    
  setFieldPattern("CompanyID", "0010000");
  setFieldPattern("CitizenId", "0010000"); 
    setFieldPattern("LastName", "1111100");
    setFieldPattern("prefixNameDtl", "1111100");
    setFieldPattern("FirstName", "1111100");
    
    setFormatNumber("ParValue", "#,##0.00");
   $("#ParValue").decimal(20, 2);
  
  setFormatTel("Phone", 3);
  
    if ($("#CompanyIDSRH").val() == '' && $("#act").val() != 'NEW'
    && $("#act").val() != 'ADD' && $("#act").val() != 'ADDRTN' && $("#act").val() != 'ADDERR' 
    && $("#act").val() != 'UPD' && $("#act").val() != 'ADDRTN' && $("#act").val() != 'UPDERR'
    && $("#act").val() != 'DEL' && $("#act").val() != 'DELRTN' && $("#act").val() != 'DELERR')
    {
    
        $("#barSearch").show();
        $("#gridSearch").show();
        $("#form1").hide();
        $("#form2").hide();
        createGrid();
        $("#CompanyIDSrh").focus();
    }
  else 
  {
    $("#barSearch").hide();
    $("#gridSearch").hide();
    $("#form1").show();
    $("#form2").show();
    $("#CompanyID").focus();
 
    if ($("#act").val() == '' || $("#act").val() == 'NEW' || $("#act").val() == 'ADDERR')
    {
        $("#DEL").hide();
        $("#UPD").hide();
    }
    else if ($("#act").val() == 'ADDRTN' || $("#act").val() == 'UPDRTN')
    {
            $("#ADD").hide();
    }
    else 
    {   
           $("#ADD").hide();
    }
  }
  //---------------email---------------------
  $('#Mail').on("keyup", function (e)
  {
    //alert(this.value);
    if (checkEmail(this.value))
    {
      $("#Mail").removeClass("is-invalid");
    }
    else 
    {
      $("#Mail").addClass("is-invalid");
    }
  });
  
  $('#Mail').on("blur", function (e)//เมื่อมีกดแจ้งเตือน on blur ต้องเพิ่มส่วน modal ในหน้า jsp
  {
    //alert(this.value);
    if (checkEmail(this.value))
    {
      $("#Mail").removeClass("is-invalid");
    }
    else 
    {
      $("#gobleModalFocus").val('Mail');
      $("#modalConfirm").html("กรุณาระบุ E-mail ให้ถูกต้อง");
      $("#modalButton").html("<button type=\"button\" class=\"btn btn-primary btn-sm raised\" data-dismiss=\"modal\"><b>&nbsp;&nbsp;ตกลง&nbsp;&nbsp;<\/b><\/button>");
      $('#myModal').modal('show');
    }
    
  });
  //-----------start dialog prefix name----------
    PrefixNameL.formName = 'frmSHD';
    
    $('#buttprefixNameDtl').on("click", function ()
    {
        $("#prefixCodeSrhL").val("");
        $("#prefixNameSrhL").val("");
	
        $("#prefixNameLReturn").val("FirstName");
        searchDataPrefixNameL();
        
        PrefixNameL.returnPrefixCode = 'prefixCodeDtl';
        PrefixNameL.returnPrefixName = 'prefixNameDtl';
    });
    $('#PrefixNameL').on("hidden.bs.modal", function ()
    {
        if($('#'+PrefixNameL.returnPrefixCode).val()=='99')
        {
            $("#"+PrefixNameL.returnPrefixName).val('');
            $("#"+PrefixNameL.returnPrefixName).prop("readonly",false);
            $("#"+PrefixNameL.returnPrefixName).focus();
        }
        else
        {
            $("#"+PrefixNameL.returnPrefixName).prop("readonly",true);
            $("#"+$("#prefixNameLReturn").val()).focus();
        }
    });
    //--------end dialog prefix name----------
    setDDList()
    afterLoad();
});

//---------------1.กดปุ่ม---------------------
function verify(paAct)
{
  if (paAct == 'SRH')
  {
    searchData();
  }
  if (paAct == 'OPNSRH')
  {
    openBarSearch();
  }
  else if (paAct == 'ADD')
  {
    addData();
  }
  else if (paAct == 'CLR'||paAct == 'NEW')
  {
    newData();
  }
  else if (paAct == 'UPD')
  {
    editData();
  }
  else if (paAct == 'DEL')
 {
    confirmDelete();
 }
}
//---------------2. if(paAct == 'ADD') addData();---------------------
function addData()
{
  if (validateData())
  {
    $("#act").val('ADD');
    $("#frmSHD").submit();
  }
}
function openBarSearch()
{
  $("#barSearch").show();
  $("#gridSearch").show();
  $("#CompanyIDSrh").focus();
  $("#form1").hide();
  $("#form2").hide();
  if (jqGridShareHoder == '')
  {
    createGrid();
  }
}

function newData()
{
  $("#act").val('NEW');
  $("#CompanyID").val('');
  $("#frmSHD").submit();
}

function editData()
{
  if (validateData())
  {
    $("#act").val('UPD');
    $("#frmSHD").submit();
  }
}
function confirmDelete()
{
   $("#modalConfirm").html("คุณต้องการลบข้อมูลนี้หรือไม่");
   $("#modalButton").html("<button type=\"button\" class=\"btn btn-primary btn-sm raised\" data-dismiss=\"modal\"><b>&nbsp;&nbsp;ยกเลิก&nbsp;&nbsp;<\/b><\/button><button type=\"button\" class=\"btn btn-primary btn-sm raised\" data-dismiss=\"modal\" onclick=\"deleteData();\"><b>&nbsp;&nbsp;ตกลง&nbsp;&nbsp;<\/b><\/button>");
   $('#myModal').modal('show');
}
function deleteData()
{
    $("#act").val('DEL');
    $("#frmSHD").submit();
}

function getData(id)
{
  rowData = jqGridShareHoder.getRowData(id);
  $("#CitizenId").val(rowData.citizenId);
  
  $("#act").val('INQ');
  $("#frmSHD").submit();
}
function searchData()
{
  $("#act").val('SRH');
  jqGridShareHoder.setGridParam(
  {
    url : "../reg/ShareHoderServlet?" + $("#frmSHD").serialize(), page : 1
  });
  jqGridShareHoder.trigger("reloadGrid")
}



//---------------3. if(validateData())---------------------
function validateData()
{
    var vbRsl = false;
    var vaErrMsg = "กรุณาระบุ";
    var vaFocus = "";
    $("#CompanyID").removeClass("is-invalid");
    $("#FirstName").removeClass("is-invalid");
    $("#LastName").removeClass("is-invalid");
    $("#CitizenId").removeClass("is-invalid");
    $("#provinceIdDtl").removeClass("is-invalid");
    $("#amphurDtl").removeClass("is-invalid");
    $("#districtDtl").removeClass("is-invalid");
    $("#zipcode").removeClass("is-invalid");


  if ($("#CompanyID").val() == '')
  {
    if (vaErrMsg != "กรุณาระบุ"){ vaErrMsg = vaErrMsg + " , ";}
    vaErrMsg = vaErrMsg + " เลขทะเบียนนิติบุคคล ";
    if (vaFocus == "")
    {
      vaFocus = "CompanyID";
    }
    $("#CompanyID").addClass("is-invalid");
  }
  
  
  if ($("#FirstName").val() == '')
  {
    if (vaErrMsg != "กรุณาระบุ") vaErrMsg = vaErrMsg + ",";
    vaErrMsg = vaErrMsg + " ชื่อผู้ถือหุ้น ";
    if (vaFocus == "")
    {
      vaFocus = "FirstName";
    }
    $("#FirstName").addClass("is-invalid");
  }
  
   if ($("#LastName").val() == '')
  {
    if (vaErrMsg != "กรุณาระบุ") vaErrMsg = vaErrMsg + ",";
    vaErrMsg = vaErrMsg + " นามสกุลผู้ถือหุ้น ";
    if (vaFocus == "")
    {
      vaFocus = "LastName";
    }
    $("#LastName").addClass("is-invalid");
  }
  
    if ($("#CitizenId").val() == '')
    {
        if (vaErrMsg != "กรุณาระบุ") vaErrMsg = vaErrMsg + ",";
        vaErrMsg = vaErrMsg + " เลขประจำตัวประชาชน ";
        if (vaFocus == "")
        {
          vaFocus = "CitizenId";
        }
        $("#CitizenId").addClass("is-invalid");
    }

  if ($("#provinceIdDtl").val() == '')
        {
            if (vaErrMsg != "กรุณาระบุ") vaErrMsg = vaErrMsg + ",";
            vaErrMsg = vaErrMsg + " จังหวัด  ";
            if (vaFocus == "")
            {
                vaFocus = "provinceIdDtl";
            }
           $("#provinceIdDtl").addClass("is-invalid");
        }
        if ($("#amphurNameDtl").val() == '')
        {
            if (vaErrMsg != "กรุณาระบุ") vaErrMsg = vaErrMsg + ",";
            vaErrMsg = vaErrMsg + " เขต/อำเภอ  ";
            if (vaFocus == "")
            {
                vaFocus = "amphurDtl";
            }
         $("#amphurDtl").addClass("is-invalid");

        }
        if ($("#districtNameDtl").val() == '')
        {
            if (vaErrMsg != "กรุณาระบุ") vaErrMsg = vaErrMsg + ",";
            vaErrMsg = vaErrMsg + " แขวง/ตำบล  ";
            if (vaFocus == "")
            {
                vaFocus = "districtDtl";
            }
          $("#districtDtl").addClass("is-invalid");
           
        }
          if ($("#zipcode").val() == '')
    {
        if (vaErrMsg != "กรุณาระบุ") vaErrMsg = vaErrMsg + ",";
        vaErrMsg = vaErrMsg + " รหัสไปรษณีย์  ";
        if (vaFocus == "")
        {
            vaFocus = "zipcode";
        }
        $("#zipcode").addClass("is-invalid");
    
    }

  if (vaErrMsg != 'กรุณาระบุ')
  {
    $("#reloading").html("<div class=\"alert alert-warning\" style=\"text-align:center;margin-bottom: 5px;\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">&times;<\/button>" + vaErrMsg + "<\/div>");
    $("#" + vaFocus).focus();
    $('html, body').animate({scrollTop : 0},0);
    return false;
  }
  else 
  {
    vbRsl = true;
  }
  return vbRsl;
}
//---------------createGrid---------------------
function createGrid()
{
jqGridShareHoder = jQuery("#masterGrid");
 $('#act').val('SRH');
jqGridShareHoder.jqGrid({ url : "../reg/ShareHoderServlet?act=SRH"//+$("#frmRQ01080E").serialize()->คือการส่งข้อมูลแบบยกฟอร์มคือการsubmitจอ
, datatype : "json", mtype : 'POST'
, colNames : ['', 'เลขทะเบียนนิติบุคคล', 'ชื่อผู้ถือหุ้น', 'เลขประจำตัวประชาชน', 'อาชีพ']//
, colModel : [
    {
      name : 'act', index : 'act', width : '5%', align : 'center', sortable : false, formatter : function (cellval, options, rowObject)
      {
        return "<span class=\"glyphicon glyphicon-pencil\" style=\"cursor:pointer;\" onclick=\"getData('" + options.rowId + "');\"><\/span>";
      }
    }, 
    {
      name : 'companyId', index : 'aoShareHoderInfo.companyId', align : 'center', width : '12%'
    },
    {
      name : 'firstname', index : 'aoShareHoderInfo.firstname', align : 'left', width : '20%'
    },
    {
      name : 'citizenId', index : 'aoShareHoderInfo.citizenId', align : 'left', width : '10%'
    },
    {
      name : 'career', index : 'aoShareHoderInfo.career', align : 'right', width : '10%'
    }]
    , height : 300, width : 700, rowNum : 20, rowList : [20, 40, 100], sortable : true//ให้เรียงลำดับได้
    //, sortname: 'system_code'
, multiSort : true//ให้เรียงลำดับได้> 1
    //, sortorder: 'desc'
    //, loadonce : true // loading all data in one time
, autoencode : true, pager : "#masterGridPager", viewrecords : true// display the number of total records from the query in the pager bar  เลขด้านล่าง
, multiselect : false//กดติ๊กได้มากกว่า
, rownumbers : true//เลขด้านหน้าตาราง
, loadComplete : function (data)//โหลดเเล้วจะคืนดาต้ามาตัวนึง
    {
      
      if (jqGridShareHoder.getGridParam("reccount") == 0)
      {
        if ($("#reloading").html() != "")
        {
          $("#reloading").delay(3000).fadeOut();
          $("#reloading").stop();
          $("#reloading").fadeIn(0);
        }
        $("#reloading").html("<div class='alert alert-warning alert-dismissable' style='text-align: center; margin-bottom: 5px;'>" + "<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button><b>ไม่พบข้อมูลที่ต้องการค้นหา<\/b></div>");
      }
      else if (jqGridShareHoder.getGridParam("reccount") != 0)//ถ้าgridเรามีrecord
      {
        if ($("#delMulti").val() != 0)
        {
          //#delMulti คือ id ของ div ลบข้อมูลเรียบร้อยแล้ว
          $("#reloading").html("");
        }
        else if ($("#delMulti").val() == 0)
        {
          $("#delMulti").val(1);
        }
      }
      $("#CompanyIDSrhDiv").focus();//ให้ไปโฟกัสที่ฟิล 

    }
    
  });
setTimeout(function ()//หน่วงเวลา
  {
    $("#masterGrid").setGridWidth(parseInt($("#form_body").width()) - 20);//setขนาดของbody-20 หน่วงเวลาเพื่อให้ปรับขนาดgrid
  },
330);

  $(window).bind('resize', function ()
  {
    $("#masterGrid").setGridWidth($("#form_body").width() - 20);//เมื่อมีการresize window ให้resize grid ให้เราด้วย
  }).trigger('resize');
};


function setDDList()
{
    
    $("#provinceIdDtl").select2({
        ajax: 
        {
            url: "../CentralServlet?act=SRHPRV",
            dataType: 'json',
            data: function(term, page) {
                return {
                    ProvinceName : term
                        
                };
            },
            results: function(data, page ) {
                return { results: data }
            }
        }
        //, width:'300px'
        //, formatResult: formatList
        , allowClear: true
        , placeholder: "กรุณาเลือก"
        , initSelection: function (element, callback) {
        return $.getJSON("../CentralServlet?act=SRHPRV", function(data) {
            provinceId = '';
            provinceName = '';
            if(typeof(data) !== 'undefined' && data.length > 0)
            {
                for(i=0; i<data.length; i++)
                {
                    provinceArray = data[i].id.split(":");
                    if(provinceArray[0] == element.val()) 
                    {provinceId = provinceArray[0]; provinceName = provinceArray[1]; break;}
                }
            }
            return callback({ id: provinceId, text: provinceName });
        });
     }
    }).on('change', function(){
        $("#amphurDtl").select2("val", "");
        $("#districtDtl").select2("val", "");
        if($(this).select2("val").trim() == '')
        {
            $("#amphurDtl").select2("readonly", true);
            $("#amphurCodeDtl").val('');
            $("#amphurNameDtl").val('');
            
            $("#districtDtl").select2("readonly", true);
            $("#districtCodeDtl").val('');
            $("#districtNameDtl").val('');
            $("#zipcodeDtl").val('');
        }
        else
        {
            $("#amphurDtl").select2("readonly", false);
            $("#amphurCodeDtl").val('');
            $("#amphurNameDtl").val('');
            
            $("#districtDtl").select2("readonly", true);
            $("#districtCodeDtl").val('');
            $("#districtNameDtl").val('');
            $("#zipcodeDtl").val('');
            
            $("#amphurDtl").select2('focus');
                
            var provinceArray = $(this).select2("val").split(":");
            
            $("#provinceCodeDtl").val(provinceArray[0]);
            $("#provinceNameDtl").val(provinceArray[1]);
            
            $("#amphurDtl").select2('focus');
        }
        
    });    
	//----- อำเภอ
    $("#amphurDtl").select2({
        ajax: 
        {
            url: "../CentralServlet?act=SRHAMPHUR",
            dataType: 'json',
            data: function(term, page) {
                return {
                        AmphurName : term
                        , ProvinceCode : $("#provinceCodeDtl").val()
                };
            },
            results: function(data, page ) {
                return { results: data }
            }
        }
        //, width:'300px'
        //, formatResult: formatList
        , allowClear: true
        , placeholder: "กรุณาเลือก"
        , initSelection: function (element, callback) {
    return $.getJSON("../CentralServlet?act=SRHAMPHUR", {ProvinceCode : $("#provinceCodeDtl").val()}, function(data) {
       amphurId = '';
       amphurName = '';
       if(typeof(data) !== 'undefined' && data.length > 0)
       {
          for(i=0; i<data.length; i++)
          {
             amphurArray = data[i].id.split(":");
             if(amphurArray[0] == element.val()) {amphurId = amphurArray[0]; amphurName = amphurArray[1]; break;}
          }
       }
       return callback({ id: amphurId, text: amphurName });
    });
    }
    }).on('change', function(){
        $("#districtDtl").select2("val", "");
        if($(this).select2("val").trim() == '')
        {
            $("#amphurCodeDtl").val('');
            $("#amphurNameDtl").val('');

            $("#districtDtl").select2("readonly", true);
            $("#districtCodeDtl").val('');
            $("#districtNameDtl").val('');

            $("#zipcodeDtl").val('');
        }
        else
        {
            $("#districtDtl").select2("readonly", false);
            $("#districtCodeDtl").val('');
            $("#districtNameDtl").val('');
    
            $("#zipcodeDtl").val('');
            
            var amphurArray = $(this).select2("val").split(":");
            
            $("#amphurCodeDtl").val(amphurArray[0]);
            $("#amphurNameDtl").val(amphurArray[1]);
                $("#districtDtl").select2('focus');
        }  
    });
	//----- ตำบล
    $("#districtDtl").select2({
        ajax: {
                url: "../CentralServlet?act=SRHDISTRICT",
                dataType: 'json',
                //term คือค่าที่ Key เข้ามาใน dropDownList
                data: function(term, page) {
                        return {
                                DistrictName : term
                                , ProvinceCode :  $("#provinceCodeDtl").val()
                                , AmphurCode : $("#amphurCodeDtl").val()
                        };
                },
                results: function(data, page ) {
                        //alert(data[0].text);
                        //var test = [{text:data.objectName, children:[{id:data.objectCode, text:data.objectName}]}];
                        return { results: data }
                }
        }
        //, width:'300px'
        //, formatResult: formatList
        , allowClear: true
        , placeholder: "กรุณาเลือก"
        , initSelection: function (element, callback) {
            return $.getJSON("../CentralServlet?act=SRHDISTRICT", 
            {ProvinceCode : $("#provinceCodeDtl").val(), AmphurCode : $("#amphurCodeDtl").val()}, function(data) {
               districtId = '';
               districtName = '';
               if(typeof(data) !== 'undefined' && data.length > 0)
               {
                  for(i=0; i<data.length; i++)
                  {
                     districtArray = data[i].id.split(":");
                     if(districtArray[0] == element.val()) {districtId = districtArray[0]; districtName = districtArray[1]; $("#zipcode").val(districtArray[2]); break;}
                  }
               }
               return callback({ id: districtId, text: districtName });
    });
    }
    }).on('change', function(){
        if($(this).select2("val").trim() == '')
        {
        $("#districtCodeDtl").val('');
        $("#districtNameDtl").val('');
        $("#zipcode").val('');
        }
        else
        {
          var districtArray = $(this).select2("val").split(":");
          $("#districtCodeDtl").val(districtArray[0]);
          $("#districtNameDtl").val(districtArray[1]);
          $("#zipcode").val(districtArray[2]);
          $("#zipcode").focus();
        }
             
    });
    
    if($("#provinceIdDtl").val()=='')
    {
		$("#amphurDtl").select2("readonly", true);
    }
    if($("#amphurCodeDtl").val()=='')
    {
		$("#districtDtl").select2("readonly", true);
    }
	
    //----- set ค่าตอน Inquiry มาแสดงที่จอภาพ
   if($("#provinceCodeDtl").val() != '')
    {
        $('#provinceIdDtl').select2('data', {id:$("#provinceCodeDtl").val(), text:$("#provinceCodeDtl").val()+' - '+$("#provinceNameDtl").val()});
    }
    if($("#amphurCodeDtl").val() != '')
    {
        $('#amphurDtl').select2('data', {id:$("#amphurCodeDtl").val(), text:$("#amphurCodeDtl").val()+' - '+$("#amphurNameDtl").val()});
    }
    if($("#districtCodeDtl").val() != '')
    {
        $('#districtDtl').select2('data', {id:$("#districtCodeDtl").val(), text:$("#districtCodeDtl").val()+' - '+$("#districtNameDtl").val()});
    }
}

function callJuristic()
{
  

   if($("#CompanyID").val()=='')
   {
      $("#gobleModalFocus").val('CompanyID');
      $("#modalConfirm").html("กรุณาระบุ เลขทะเบียนนิติบุคคล");
      $("#modalButton").html("<button type=\"button\" class=\"btn btn-primary btn-sm raised\" data-dismiss=\"modal\"><b>&nbsp;&nbsp;ตกลง&nbsp;&nbsp;<\/b><\/button>");
      $('#myModal').modal('show');
   }
   else
   {       
      $.ajax(
      {
         cache : false
         , url : '../DBDJuristicServlet'
         , data :{ act : "DBDSHD", JuristicID : $("#CompanyID").val()}
         , type : 'POST'
         , success : function (data)
         {
            //closeLoading();
            
            if(data != ''&& data != null)
            {
                //alert(JSON.stringify(data));
               $("#referenceIdDBD").val(data.referenceIdDBD);
               //alert(JSON.stringify(data.errMsg));
               if(data.errMsg!='' && data.errMsg.length!=0)
               {
                 $("#gobleModalFocus").val('CompanyID');
                  $("#modalConfirm").html(data.errMsg);
                  $("#modalButton").html("<button type=\"button\" class=\"btn btn-primary btn-sm raised\" data-dismiss=\"modal\"><b>&nbsp;&nbsp;ตกลง&nbsp;&nbsp;<\/b><\/button>");
                  $('#myModal').modal('show');
               }
               else
               {
              // alert(JSON.stringify(data.returnStatus));
                  if(data.returnStatus!=200)
                  {
                     $("#gobleModalFocus").val('CompanyID');
                     $("#modalConfirm").html(data.returnStatusDesc);
                     $("#modalButton").html("<button type=\"button\" class=\"btn btn-primary btn-sm raised\" data-dismiss=\"modal\"><b>&nbsp;&nbsp;ตกลง&nbsp;&nbsp;<\/b><\/button>");
                     $('#myModal').modal('show');
                  }
                  else
                    {       
                    //alert(JSON.stringify(data.returnData));
                        var object = JSON.parse(data.returnData);
                        //alert("obj "+JSON.stringify(object.data));
                        displayJuristicDialog(object.data);
                       
                  }
               }
            }
            else
            {
                $("#gobleModalFocus").val('CompanyID');
               $("#modalConfirm").html("ไม่พบข้อมูลที่ต้องการค้นหา");
               $("#modalButton").html("<button type=\"button\" class=\"btn btn-primary btn-sm raised\" data-dismiss=\"modal\"><b>&nbsp;&nbsp;ตกลง&nbsp;&nbsp;<\/b><\/button>");
               $('#myModal').modal('show');
            }
         }
         , error : function (xhr, status, error)
         {
           
           alert("An AJAX error occured: " + status + "\nError: " + error + "\nError detail: " + xhr.responseText);
         } 
       
      });
     
   }
}
function displayJuristicDialog(jsonObject)
{

  $("#CompanyID").val(jsonObject.JuristicID);
  //alert("dasplay "+JSON.stringify(jsonObject.JuristicID));
   $("#CompanyName").val(jsonObject.JuristicName);
   $("#ParValue").val(jsonObject.ParValue);
   $("#SumOfHolder").val(jsonObject.SumOfHolder);

}