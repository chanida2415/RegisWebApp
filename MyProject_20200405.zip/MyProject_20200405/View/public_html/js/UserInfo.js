$(document).ready(function () {
    $('#RegisterUserL').on('hidden.bs.modal', function () 
    {
        $("#RegisterUserReloadingDialog").html("");
    }); 
    
    $('#email').on("keyup", function (e)
    {
        //alert(this.value);
        if (checkEmail(this.value))
        {
            $("#email").removeClass("is-invalid");
        }
        else 
        {
            $("#email").addClass("is-invalid");
        }
    });
  
  $('#email').on("blur", function (e)//เมื่อมีกดแจ้งเตือน on blur ต้องเพิ่มส่วน modal ในหน้า jsp
  {
    //alert(this.value);
    if (checkEmail(this.value))
    {
      $("#email").removeClass("is-invalid");
    }
    else 
    {
      $("#gobleModalFocus").val('email');
      $("#modalConfirm").html("กรุณาระบุ E-mail ให้ถูกต้อง");
      $("#modalButton").html("<button type=\"button\" class=\"btn btn-primary btn-sm raised\" data-dismiss=\"modal\"><b>&nbsp;&nbsp;ตกลง&nbsp;&nbsp;<\/b><\/button>");
      $('#myModal').modal('show');
    }
    
  });
  
});
function CreateUser()
{
    var vaErrMsg = "กรุณาระบุ";
    var vaFocus = "";
    
    $("#userName").removeClass("is-invalid");
    if($("#userName").val()=='')
    {
       vaErrMsg = vaErrMsg+" ชื่อผู้ใช้, ";
       if(vaFocus == "")
       {
          vaFocus = "userName";
       }
       $("#userName").addClass("is-invalid");
    }
    
    $("#password").removeClass("is-invalid");
    if($("#password").val()=='')
    {
       vaErrMsg = vaErrMsg+" รหัสผ่าน, ";
       if(vaFocus == "")
       {
          vaFocus = "password";
       }
       $("#password").addClass("is-invalid");
    }
    
    $("#firstName").removeClass("is-invalid");
    if($("#firstName").val()=='')
    {
       vaErrMsg = vaErrMsg+" ชื่อ, ";
       if(vaFocus == "")
       {
          vaFocus = "firstName";
       }
       $("#firstName").addClass("is-invalid");
    }
    $("#lastName").removeClass("is-invalid");
    if($("#lastName").val()=='')
    {
       vaErrMsg = vaErrMsg+" นามสกุล, ";
       if(vaFocus == "")
       {
          vaFocus = "lastName";
       }
       $("#lastName").addClass("is-invalid");
    }
    
    $("#agentId").removeClass("is-invalid");
    if($("#agentId").val()=='')
    {
       vaErrMsg = vaErrMsg+" เลขบัตรประจำตัวประชาชน, ";
       if(vaFocus == "")
       {
          vaFocus = "agentId";
       }
       $("#agentId").addClass("is-invalid");
    }
    if(vaErrMsg != 'กรุณาระบุ')
    {
       vaErrMsg = vaErrMsg.substring(0, vaErrMsg.length-2)
       //$("#reloading").html("<div class=\"alert alert-warning\" style=\"text-align:center;margin-bottom: 5px;\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">&times;<\/button><label class=\"control-label\">"+vaErrMsg+"<\/label><\/div>");
       $("#RegisterUserReloadingDialog").html("<div class=\"alert alert-warning\" style=\"text-align:center;margin-bottom: 5px;\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">&times;<\/button>"+vaErrMsg+"<\/div>");
       $("#"+vaFocus).focus();
    
    }
    else
    {
      $.ajax(
    {
    cache : false
    , url : '../UserInfoServlet'
    , data :{ act : "REG"}
    , type : 'POST'
    , success : function (data)
    {
    //closeLoading();
    if(data != ''&& data != null)
    {
       $("#referenceIdDBD").val(data.referenceIdDBD);
       if(data.errMsg!='' && data.errMsg.length!=0)
       {
    
          $("#modalConfirm").html(data.errMsg);
          $("#modalButton").html("<button type=\"button\" class=\"btn btn-primary btn-sm raised\" data-dismiss=\"modal\"><b>&nbsp;&nbsp;ตกลง&nbsp;&nbsp;<\/b><\/button>");
          $('#myModal').modal('show');
       }
       else
       {
          if(data.returnStatus!=200)
          {
             $("#gobleModalFocus").val('CompanyID');
             $("#modalConfirm").html(data.returnStatusDesc);
             $("#modalButton").html("<button type=\"button\" class=\"btn btn-primary btn-sm raised\" data-dismiss=\"modal\"><b>&nbsp;&nbsp;ตกลง&nbsp;&nbsp;<\/b><\/button>");
             $('#myModal').modal('show');
          }
          else
          {      
            setSendData();
             var object = JSON.parse(data.returnData);
             
             displayJuristicDialog(object);
             $("#JuristicL").modal('show');
          }
       }
    }
    else
    {
       $("#gobleModalFocus").val('CompanyIDL');
       $("#modalConfirm").html("ไม่พบข้อมูลที่ต้องการค้นหา");
       $("#modalButton").html("<button type=\"button\" class=\"btn btn-primary btn-sm raised\" data-dismiss=\"modal\"><b>&nbsp;&nbsp;ตกลง&nbsp;&nbsp;<\/b><\/button>");
       $('#myModal').modal('show');
    }
    }
    , error : function (xhr, status, error)
    {
    
    alert("error");
    //closeLoading();
    } 

});
    
     
            }
         }
