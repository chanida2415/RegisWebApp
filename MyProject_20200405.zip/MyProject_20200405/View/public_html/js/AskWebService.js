var jqAskWebService = '';
$(document).ready(function ()
{    
  
  setFieldPattern("CompanyID", "0010000");

   setFormatDate("StartDateSrh", 3);
    $('#calendarStartDate').click(function () {
            $('#StartDateSrh').datepicker('show');
    }); 
    setFormatDate("EndDateSrh", 3);
    $('#calendarEndDate').click(function () {
            $('#EndDateSrh').datepicker('show');
    }); 
     $("#barSearch").show();
        $("#gridSearch").show();
    createGrid();
    afterLoad();
    
});

//---------------1.กดปุ่ม---------------------
function verify(paAct)
{
  if (paAct == 'SRH')
  {
    searchData();
  }
   else if (paAct == 'CLR'||paAct == 'NEW')
  {
    newData();
  }

}

function newData()
{
  $("#act").val('NEW');
  $("#CompanyIDSrh").val('');
  $("#frmAWS").submit();
}

function searchData()
{
if ($("#CompanyIDSrh").val() == '' && $("#AgentIdSrh").val() == '')
  {
    $("#reloading").html("<div class=\"alert alert-warning\" style=\"text-align:center;margin-bottom: 5px;\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">&times;<\/button><b>กรุณาระบุเงื่อนไขการค้นหาอย่างน้อย 1 เงื่อนไข<\/b><\/div>");
    $("#CompanyIDSrh").focus();
    $('html, body').animate({ scrollTop: 0 }, 0);

  }
  else
    {
  jqAskWebService.setGridParam(
  {
    url : "../reg/ASKWebServiceServlet?" + $("#frmAWS").serialize(), page : 1
  });
  jqAskWebService.trigger("reloadGrid")
    }
}

function createGrid()
{
jqAskWebService = jQuery("#masterGrid");
 $('#act').val('SRH');
jqAskWebService.jqGrid({ url : "../reg/ASKWebServiceServlet?act=SRH"//+$("#frmRQ01080E").serialize()->คือการส่งข้อมูลแบบยกฟอร์มคือการsubmitจอ
, datatype : "json", mtype : 'POST'
, colNames : [ 'เลขทะเบียนนิติบุคคล','เลขประจำตัวประชาชน','วันที่ร้องขอข้อมูล','ชื่อผู้ร้องขอข้อมูล']//
, colModel : [
    
    {
      name : 'companyId', index : 'aoWebserviceLog.companyId', align : 'center', width : '12%'
    }
    ,{
      name : 'agentId', index : 'aoWebserviceLog.agentId', align : 'center', width : '12%'
    }
    ,{
      name : 'createdDate', index : 'aoWebserviceLog.createdDate', align : 'center', width : '12%'
    }
    ,{
      name : 'createdBy', index : 'aoWebserviceLog.createdBy', align : 'center', width : '12%'
    }]
    , height : 300, width : 700, rowNum : 20, rowList : [20, 40, 100], sortable : true//ให้เรียงลำดับได้
    //, sortname: 'system_code'
, multiSort : true//ให้เรียงลำดับได้> 1
    //, sortorder: 'desc'
    //, loadonce : true // loading all data in one time
, autoencode : true, pager : "#masterGridPager", viewrecords : true// display the number of total records from the query in the pager bar  เลขด้านล่าง
, multiselect : false//กดติ๊กได้มากกว่า
, rownumbers : true//เลขด้านหน้าตาราง
, loadComplete : function (data)//โหลดเเล้วจะคืนดาต้ามาตัวนึง
    {
      
      if (jqAskWebService.getGridParam("reccount") == 0)//ถ้าgridเราไม่มีค่า
      {
        if ($("#reloading").html() != "")
        {
          $("#reloading").delay(3000).fadeOut();
          $("#reloading").stop();
          $("#reloading").fadeIn(0);
        }
        $("#reloading").html("<div class='alert alert-warning alert-dismissable' style='text-align: center; margin-bottom: 5px;'>" + "<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button><b>ไม่พบข้อมูลที่ต้องการค้นหา<\/b></div>");
      }
      else if (jqAskWebService.getGridParam("reccount") != 0)//ถ้าgridเรามีrecord
      {
        if ($("#delMulti").val() != 0)
        {
          //#delMulti คือ id ของ div ลบข้อมูลเรียบร้อยแล้ว
          $("#reloading").html("");
        }
        else if ($("#delMulti").val() == 0)
        {
          $("#delMulti").val(1);
        }
      }
      

    }
    
  });
setTimeout(function ()//หน่วงเวลา
  {
    $("#masterGrid").setGridWidth(parseInt($("#form_body").width()) - 20);//setขนาดของbody-20 หน่วงเวลาเพื่อให้ปรับขนาดgrid
  },
330);

  $(window).bind('resize', function ()
  {
    $("#masterGrid").setGridWidth($("#form_body").width() - 20);//เมื่อมีการresize window ให้resize grid ให้เราด้วย
  }).trigger('resize');
};



