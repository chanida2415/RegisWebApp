var jqGridPrefixName = '';
$(document).ready(function () {
    /* $("#reasonTypeSrhL").select2({
        width: "100%",
        placeholder: "กรุณาเลือก",
        allowClear: true
    });
    */
    
    createGridPrefixNameL();
    $("#PrefixNameL").on('hide.bs.modal', function() { 
              jqGridPrefixName.jqGrid('clearGridData');
            }); 

});

function createGridPrefixNameL()
{  
   jqGridPrefixName = jQuery("#prefixNameDialogGrid");
   //$(function () {
   // Setup grid
   jqGridPrefixName.jqGrid(
   {
      //url : "../sec/UserServlet?act=SRH&userId="+$("#userIdSrh").val()+"&userName="+$("#userNameSrh").val()
      //url:"../ref/PrefixNameListServlet?act=SRH"
      url:"../reg/PrefixNameListServlet"
      //url : "../sec/UserServlet"
      , datatype : "json"
      , mtype : 'POST'
      , colNames : [ 'รหัส', 'คำนำหน้า'
                   ]
      , colModel : [{name : 'prefixCode', index : 'prefixName.prefixCode',width:'20%' , align : 'center'}
                   ,{name : 'prefixName', index : 'prefixName.prefixName',width:'80%' , align : 'left'}
                   ]
      , height : 300
      , width : 500
      //, rowNum : 20
      //, rowList : [20, 40, 100]
      , sortable : true
      //, sortname: 'system_code'
      , multiSort:true
      , onSelectRow: function(ids) 
                     { 
                        var rowData = jqGridPrefixName.getRowData(ids);
                        if(PrefixNameL.returnPrefixCode != '')
                        {
                           $("#"+PrefixNameL.returnPrefixCode).val(rowData.prefixCode);
                        }
                        if(PrefixNameL.returnPrefixName != '')
                        {
                           $("#"+PrefixNameL.returnPrefixName).val(rowData.prefixName);
                        }
                       
                        setTimeout(function () {
                        self.$("#PrefixNameL").trigger("click");
                        }, 230);
                     }
      //, sortorder: 'desc'
      //, loadonce : true // loading all data in one time
      , autoencode : true
      , pager : "#prefixNameDialogPager"
      , viewrecords : true  // display the number of total records from the query in the pager bar
      //, multiselect : true
      , rownumbers : true
      /*, jsonReader : { 
              root: "rows", 
              page: "page", 
              total: "total", 
              records: "records", 
              cell: "cell", 
              id: "id",
              userdata: "userdata"
              } */
      , loadComplete: function (){
                   if (jqGridPrefixName.getGridParam("reccount") == 0)
                     {
                        // count data in grid
                        //var htmlString = $("#prefixNameReloadingDialog").html();
                        if ($("#prefixNameReloadingDialog").html() != "")
                        {
                           $("#prefixNameReloadingDialog").delay(3000).fadeOut();
                           $("#prefixNameReloadingDialog").stop();
                           $("#prefixNameReloadingDialog").fadeIn(0);
                        }
                        $("#prefixNameReloadingDialog").html("<div class='alert alert-warning alert-dismissable' style='height: 37px; text-align: center; " + "vertical-align:middle; line-height: 30px; padding-top: 3px; margin-bottom: 5px;'>" + "<button type='button' class='close' data-dismiss='alert' aria-hidden='true' style='padding-top: 7px;'>&times;<\/button>" + "ไม่พบข้อมูลที่ต้องการค้นหา <\/div>");
                        //$("body").scrollTop(0);
                     }
                     else if (jqGridPrefixName.getGridParam("reccount") != 0)
                     {
                    
                        $("#prefixNameReloadingDialog").html("");
                        
                        /*var ids = jqGridPrefixName.jqGrid('getDataIDs');
                        for(var i=0;i < ids.length;i++)
                        {
                          var cl = ids[i];
                          be = "<input style='height:22px;width:20px;' type='button' value='E' onclick=\"getData('"+cl+"');\"/>"; 
                          jqGridPrefixName.jqGrid('setRowData',ids[i],{act:be});
                        }	*/
                     }
               }
   });

   setTimeout(function() {
   
     $("#prefixNameDialogGrid").setGridWidth( parseInt($("#dialogPrefixName").width()) - 90);
   }, 330);
     
   $(window).bind('resize', function() {
     $("#prefixNameDialogGrid").setGridWidth($("#dialogPrefixName").width() - 90);
   }).trigger('resize');
}

function searchDataPrefixNameL()
{
        createGridPrefixNameL();
	$("#act").val('SRH');
	//jqGridPrefixName.setGridParam({url:"../ref/PrefixNameListServlet?"+$("#"+PrefixName.formName).serialize(), page:1});
	jqGridPrefixName.setGridParam(
	{
		url:"../reg/PrefixNameListServlet"
                , postData: {   
                    act : 'SRH'
                    , prefixCodeSrhL : $("#prefixCodeSrhL").val()
                    , prefixNameSrhL : $("#prefixNameSrhL").val()
                    , rows:$("#rows").val(),page:$("#page").val(),sidx:$("#sidx").val()
                }
		, page:1
	});
	jqGridPrefixName.trigger("reloadGrid");
}


