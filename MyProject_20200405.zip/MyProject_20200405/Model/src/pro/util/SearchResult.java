package pro.util;
import java.util.Collection;
import java.util.List;

public class SearchResult<T> implements java.io.Serializable
{
  private int totalRecords ;
  private int totalPages ;
  private int currentPage ;
  
  private List<T> resultList ;

  public SearchResult()
  {
  }
  
  public int getTotalRecords()
  {
    return totalRecords ;
  }
  public void setTotalRecords(int pnTotalRecords)
  {
    totalRecords = pnTotalRecords ;
  } 
  
  public int getTotalPages()
  {
    return totalPages ;
  }
  public void setTotalPages(int pnTotalPages)
  {
    totalPages = pnTotalPages ;
  }
  
  public int getCurrentPage()
  {
    return currentPage ;
  }
  public void setCurrentPage(int pnCurrentPage)
  {
    currentPage = pnCurrentPage ;
  }


   public void setResultList(List<T> resultList)
   {
      this.resultList = resultList;
   }

   public List<T> getResultList()
   {
      return resultList;
   }
}
