package pro.util;

import java.sql.Timestamp;

import java.text.SimpleDateFormat;

import java.util.Calendar;
import java.util.Date;
import java.util.Locale;


public class DateConvert 
{
  public static final int THAI_YEAR_CONVERT = 543 ;

  public DateConvert()
  {
  }
  
  public static String displayDate2StoreDate(String paDate)
  { // receive dd/mm/yyyy eg. 01/08/2548 --> 20050801
    if(paDate == null)
    {
      return "" ;
    }
    if(paDate.length() > 0)
    {
      if(paDate.equals("99/99/9999"))
      {
         return "99999999";
      }
      else
      {
         /*StringBuffer vaTmpDte = new StringBuffer(Integer.toString(Integer.parseInt(paDate.substring(6,10))-THAI_YEAR_CONVERT)) ;
         vaTmpDte.append(paDate.substring(3,5)).append(paDate.substring(0,2)) ;*/
         StringBuffer vaTmpDte = new StringBuffer(Integer.toString(Integer.parseInt(paDate.substring(6,10)))) ;
                  vaTmpDte.append(paDate.substring(3,5)).append(paDate.substring(0,2)) ;
         
         return  vaTmpDte.toString() ;
      }
    }
    else
    {
      return "" ;
    }
  }
  
  public static String displayDate2StoreDateMY(String paDate)
  { // receive mm/yyyy eg. 08/2548 --> 20050801
    if(paDate == null)
    {
      return "" ;
    }
    if(paDate.length() > 0)
    {
      if(paDate.equals("99/9999"))
      {
         return "999999";
      }
      else
      {
         /*StringBuffer vaTmpDte = new StringBuffer(Integer.toString(Integer.parseInt(paDate.substring(3,7))-THAI_YEAR_CONVERT)) ;
         vaTmpDte.append(paDate.substring(0,2)) ;*/
         StringBuffer vaTmpDte = new StringBuffer(Integer.toString(Integer.parseInt(paDate.substring(3,7)))) ;
                  vaTmpDte.append(paDate.substring(0,2)) ;

         return  vaTmpDte.toString() ;
      }
    }
    else
    {
      return "" ;
    }
  }
  
  public static String storeDate2DisplayDate(String paDate)
  { // receive yyyymmdd eg. 20050801--> 01/08/2548
    if(paDate == null)
    {
      return "" ;
    }
    else
    {
      if(Integer.parseInt(paDate) == 0)
      {
         return "" ;
      }
    }
    if(paDate.length() > 0)
    {
      if(paDate.equals("99999999"))
      {
         return "99/99/9999";
      }
      else
      {
         /*StringBuffer vaTmpDte = new StringBuffer(paDate.substring(6,8)).append("/").append(paDate.substring(4,6)) ;
         vaTmpDte.append("/").append(Integer.toString(Integer.parseInt(paDate.substring(0,4))+THAI_YEAR_CONVERT)) ;*/
         StringBuffer vaTmpDte = new StringBuffer(paDate.substring(6,8)).append("/").append(paDate.substring(4,6)) ;
                  vaTmpDte.append("/").append(Integer.toString(Integer.parseInt(paDate.substring(0,4)))) ;
         
         return  vaTmpDte.toString()  ;    
      }
    }
    else
    {
      return "" ;
    }
  }
  
  public static String storeDate2DisplayDateMY(String paDate)
  { // receive yyyymmdd eg. 20050801--> 08-2548
    if(paDate == null)
    {
      return "" ;
    }
    else
    {
      if(Integer.parseInt(paDate) == 0)
      {
         return "" ;
      }
    }
    if(paDate.length() > 0)
    {
      if(paDate.equals("999999"))
      {
         return "99/9999";
      }
      else
      {
         /*StringBuffer vaTmpDte = new StringBuffer(paDate.substring(4,6)).append("/") ;
         vaTmpDte.append(Integer.toString(Integer.parseInt(paDate.substring(0,4))+THAI_YEAR_CONVERT)) ;*/
         StringBuffer vaTmpDte = new StringBuffer(paDate.substring(4,6)).append("/") ;
                  vaTmpDte.append(Integer.toString(Integer.parseInt(paDate.substring(0,4)))) ;
         
         return  vaTmpDte.toString()  ;    
      }
    }
    else
    {
      return "" ;
    }
  }
  
  public static String storeDateTime2DisplayDateTime(String paDateTime)
  { // receive yyyymmddhh24miss : eg. 20050808150518 --> 01/08/2548 15:05:18
    if(paDateTime == null)
    {
      return "" ;
    }
    else
    {
      if(Long.parseLong(paDateTime) == 0)
      {
         return "" ;
      }
    }
    if(paDateTime.length() > 0)
    {
      if(paDateTime.substring(0,8).equals("99999999"))
      {
         StringBuffer vaTmpDteTme = new StringBuffer(paDateTime.substring(6,8)).append("/") ;
         vaTmpDteTme.append(paDateTime.substring(4,6)).append("/") ;
         vaTmpDteTme.append(paDateTime.substring(0,4)) ;
         vaTmpDteTme.append(" ").append(paDateTime.substring(8,10)).append(":").append(paDateTime.substring(10,12)) ;
         vaTmpDteTme.append(":").append(paDateTime.substring(12,14)) ;
              
         return  vaTmpDteTme.toString()  ;
      }
      else
      {
         StringBuffer vaTmpDteTme = new StringBuffer(paDateTime.substring(6,8)).append("/") ;
         vaTmpDteTme.append(paDateTime.substring(4,6)).append("/") ;
         //vaTmpDteTme.append(Integer.toString(Integer.parseInt(paDateTime.substring(0,4))+THAI_YEAR_CONVERT)) ;
         vaTmpDteTme.append(Integer.toString(Integer.parseInt(paDateTime.substring(0,4)))) ;
         vaTmpDteTme.append(" ").append(paDateTime.substring(8,10)).append(":").append(paDateTime.substring(10,12)) ;
         vaTmpDteTme.append(":").append(paDateTime.substring(12,14)) ;
              
         return  vaTmpDteTme.toString()  ;
      }
    }
    else
    {
      return "";
    }
  }
  
  public static String displayDateTime2StoreDateTime(String paDateTime)
  { // receive dd/mm/yyyy hh24:mi:ss eg. 01/08/2548 15:05:18 --> 20050801150518
    if(paDateTime == null)
    {
      return "" ;
    }
    if(paDateTime.length() > 0)
    {
      if(paDateTime.substring(0,10).equals("99/99/9999"))
      {
         StringBuffer vaTmpDteTme = new StringBuffer(paDateTime.substring(6,10)) ;   
         vaTmpDteTme.append(paDateTime.substring(3,5)).append(paDateTime.substring(0,2)) ;    
         vaTmpDteTme.append(paDateTime.substring(11,13)).append(paDateTime.substring(14,16)) ;
         vaTmpDteTme.append(paDateTime.substring(17,19)) ;
       
         return vaTmpDteTme.toString() ;
      }
      else
      {
         //StringBuffer vaTmpDteTme = new StringBuffer(Integer.toString(Integer.parseInt(paDateTime.substring(6,10))-THAI_YEAR_CONVERT)) ;   
         StringBuffer vaTmpDteTme = new StringBuffer(Integer.toString(Integer.parseInt(paDateTime.substring(6,10)))) ;   
         vaTmpDteTme.append(paDateTime.substring(3,5)).append(paDateTime.substring(0,2)) ;    
         vaTmpDteTme.append(paDateTime.substring(11,13)).append(paDateTime.substring(14,16)) ;
         vaTmpDteTme.append(paDateTime.substring(17,19)) ;
       
         return vaTmpDteTme.toString() ;
      }
    }
    else
    {
      return "";
    }
  }

  public static String displayTime2StoreTime(String paTime)
  {// receive hh24:mi:ss eg. 15:05:18 --> 15051800
    if(paTime == null)
    {
      return "" ;
    }
    if(paTime.length() > 0)
    { // cut ":" off string
      StringBuffer vaTmp = new StringBuffer(paTime.substring(0,2)).append(paTime.substring(3,5)) ;
      vaTmp.append(paTime.substring(6,8)).append("00") ;
      
      return vaTmp.toString() ;
    }
    else
    {
      return "" ;
    }
  }

  public static String storeTime2DisplayTime(String paTime)
  {// receive hh24missff eg. 15051800 --> 15:05:18
    if(paTime == null)
    {
      return "" ;
    }
    if(paTime.length() > 0)
    { // cut ":" off string
      StringBuffer vaTmp = new StringBuffer(paTime.substring(0,2)).append(":").append(paTime.substring(2,4)) ;
      vaTmp.append(":").append(paTime.substring(4,6)) ;
      
      return vaTmp.toString() ;
    }
    else
    {
      return "" ;
    }
  }  

  public static String displayTime2StoreTime8(String paTime)
  {// receive hh24:mi:ss eg. 15:05:18 --> 15051800
    if(paTime == null)
    {
      return "" ;
    }
    if(paTime.length() > 0)
    { // cut ":" off string
      StringBuffer vaTmp = new StringBuffer(paTime.substring(0,2)).append(paTime.substring(3,5)) ;
      vaTmp.append(paTime.substring(6,8)).append(paTime.substring(9,11)) ;
      
      return vaTmp.toString() ;
    }
    else
    {
      return "" ;
    }
  }
  

  public static String storeTime2DisplayTime8(String paTime)
  {// receive hh24:mi:ss:ff eg. 15051898 --> 15:05:18:98
    if(paTime == null)
    {
      return "" ;
    }
    if(paTime.length() > 0)
    { // cut ":" off string
      StringBuffer vaTmp = new StringBuffer(paTime.substring(0,2)).append(":").append(paTime.substring(2,4)) ;
      vaTmp.append(":").append(paTime.substring(4,6)).append(":").append(paTime.substring(6,8)) ;
      
      return vaTmp.toString() ;
    }
    else
    {
      return "" ;
    }
  }  
  
  public static String getCurrentDate()
  {// return current date
      SimpleDateFormat formatDate = new SimpleDateFormat ("dd/MM/");
      SimpleDateFormat formatYear = new SimpleDateFormat ("yyyy",Locale.US);
      Date voDate = new Date();
      StringBuffer vaTmp = new StringBuffer( formatDate.format(voDate)
                                                   +(Integer.parseInt(formatYear.format(voDate))+543) );
       
      return vaTmp.toString();
  }  
  
  public static String getCurrentDateTime()
  {// return current date
      SimpleDateFormat formatDate = new SimpleDateFormat ("dd/MM/");
      SimpleDateFormat formatYear = new SimpleDateFormat ("yyyy",Locale.US);
      SimpleDateFormat formatTime = new SimpleDateFormat (" HH:mm:ss");
      Date voDate = new Date();
      StringBuffer vaTmp = new StringBuffer( formatDate.format(voDate)
                                                   +(Integer.parseInt(formatYear.format(voDate))+543)
                                                   +formatTime.format(voDate));
       
      return vaTmp.toString();
  }  
  public static Timestamp getCurrentTimestamp()
  {// return current date
      Date voDate = new Date();
       
      return new Timestamp(voDate.getTime());
  }  
  
  public static Calendar convStrToCal(String strDate)
    {
      Calendar calendar = Calendar.getInstance(Locale.US);
        try
        {
          if(strDate.indexOf("/") > 0)
          {
            strDate = strDate.replaceAll("/","");
          }
          int dd = Integer.parseInt(strDate.substring(0,2));
          int MM = Integer.parseInt(strDate.substring(2,4)) - 1;
          int yyyy = (Integer.parseInt(strDate.substring(4,8)) - 543);
          calendar.set(yyyy,MM,dd);
        }
        catch(Exception e)
        {
          calendar = null;
          e.printStackTrace();
        }
        return calendar;
    }
  
    public static String conCalToStr(Calendar objCalendar)
    {
      SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy",Locale.US);
      String retVal = null;
      int year = 0;
      try
      {
        retVal = dateFormat.format(objCalendar.getTime());   
        year = objCalendar.get(Calendar.YEAR);
        retVal = retVal.replaceAll(String.valueOf(year),String.valueOf(year + 543));
      }
      catch(Exception e)
      {
        retVal = null;
        e.printStackTrace();
      }
      return retVal;
    }
  
  public static String getCurrentDateTime8()
  {// return current date
     SimpleDateFormat formatDate = new SimpleDateFormat ("dd/MM/");
     SimpleDateFormat formatYear = new SimpleDateFormat ("yyyy",Locale.US);
     SimpleDateFormat formatTime = new SimpleDateFormat (" HH:mm:ss:SS",Locale.US);
     Date voDate = new Date();
     StringBuffer vaTmp = new StringBuffer( formatDate.format(voDate)
                                                  +(Integer.parseInt(formatYear.format(voDate))+543)
                                                  +formatTime.format(voDate));
      
     return vaTmp.toString();
  }
  
   public static String convTimestamp2String(Timestamp poTimestamp)
   {// return current date
      StringBuffer vaTmp = new StringBuffer();
      if(poTimestamp != null)
      {
         SimpleDateFormat formatDate = new SimpleDateFormat ("dd/MM/");
         SimpleDateFormat formatYear = new SimpleDateFormat ("yyyy",Locale.US);
         SimpleDateFormat formatTime = new SimpleDateFormat (" HH:mm:ss",Locale.US);
         
         //StringBuffer vaTmp = new StringBuffer( formatDate.format(poTimestamp));
         vaTmp.append(formatDate.format(poTimestamp));
         vaTmp.append((Integer.parseInt(formatYear.format(poTimestamp))+543));
         vaTmp.append(formatTime.format(poTimestamp));
      }
      return vaTmp.toString();
   }
   
   public static Timestamp convString2DateTimestamp(String paDateTime)
   {
     
      // receive dd-mm-yyyy eg. 01-08-2548 --> 01-08-2548 00:00:00 (true) or 01-08-2548 23:59:59 (false)
      SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.US);
      Timestamp voTimeStamp = null;
      Date date = null;
   
      if(paDateTime == null)
      {
         System.err.println("err"+paDateTime);
         voTimeStamp = null;
      }
      else
      {
        
         try
         {
           System.err.println("er"+paDateTime);
            if(paDateTime.length() == 19)
            {
               if(paDateTime.equals("99/99/9999 23:59:59"))
               {
                  date = sdf.parse("99/99/9999 23:59:59");
               }
               else
               {
                  StringBuffer vaTmpDte = new StringBuffer(paDateTime.substring(0,2)) ;
                  vaTmpDte.append("/" + paDateTime.substring(3,5)).append("/" + Integer.toString(Integer.parseInt(paDateTime.substring(6,10))-THAI_YEAR_CONVERT)) ;
                  vaTmpDte.append(paDateTime.substring(10)) ;
                  date = sdf.parse(vaTmpDte.toString());
               }
            
               voTimeStamp = new Timestamp(date.getTime());
            }
         }
         catch(Exception e)
         {
           System.err.println("errr"+paDateTime);
            voTimeStamp = null;
         }
      }
   
      return voTimeStamp;
   }
   
   public static String storeDate2DisplayDateBE(String paDate)
   { // receive yyyymmdd eg. 25480801--> 01/08/2548
      if(paDate == null)
      {
         return "" ;
      }
      else
      {
         if(Integer.parseInt(paDate) == 0)
         {
            return "" ;
         }
      }
      if(paDate.length() > 0)
      {
         StringBuffer vaTmpDte = new StringBuffer(paDate.substring(6,8)).append("/").append(paDate.substring(4,6)) ;
         vaTmpDte.append("/").append(Integer.toString(Integer.parseInt(paDate.substring(0,4)))) ;
         
         return  vaTmpDte.toString()  ; 
      }
      else
      {
         return "" ;
      }
   }
   
   public static String displayDate2StoreDateBE(String paDate)
   { // receive dd/mm/yyyy eg. 01/08/2548 --> 25480801
      if(paDate == null)
      {
         return "" ;
      }
      if(paDate.length() > 0)
      {
         StringBuffer vaTmpDte = new StringBuffer(Integer.toString(Integer.parseInt(paDate.substring(6,10)))) ;
         vaTmpDte.append(paDate.substring(3,5)).append(paDate.substring(0,2)) ;
         
         return  vaTmpDte.toString() ;
      }
      else
      {
         return "" ;
      }
   }
   
   public static String getCurrentYear()
   {
      SimpleDateFormat formatYear = new SimpleDateFormat ("yyyy",Locale.US);
      Date voDate = new Date();
      String vaYear = String.valueOf(Integer.parseInt(formatYear.format(voDate))+543);
      
      return vaYear;
   }
  
  
  
}