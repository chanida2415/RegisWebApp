package pro.address.data;

import java.io.Serializable;

public class DistrictInfoPK
  implements Serializable
{
  private String amphurCode;
  private String districtCode;
  private String provinceCode;

  public DistrictInfoPK()
  {
  }

  public DistrictInfoPK(String amphurCode, String districtCode,
                        String provinceCode)
  {
    this.amphurCode = amphurCode;
    this.districtCode = districtCode;
    this.provinceCode = provinceCode;
  }

  public boolean equals(Object other)
  {
    if (other instanceof DistrictInfoPK)
    {
      final DistrictInfoPK otherDistrictInfoPK = (DistrictInfoPK) other;
      final boolean areEqual =
        (otherDistrictInfoPK.amphurCode.equals(amphurCode) && otherDistrictInfoPK.districtCode.equals(districtCode) && otherDistrictInfoPK.provinceCode.equals(provinceCode));
      return areEqual;
    }
    return false;
  }

  public int hashCode()
  {
    return super.hashCode();
  }

  String getAmphurCode()
  {
    return amphurCode;
  }

  void setAmphurCode(String amphurCode)
  {
    this.amphurCode = amphurCode;
  }

  String getDistrictCode()
  {
    return districtCode;
  }

  void setDistrictCode(String districtCode)
  {
    this.districtCode = districtCode;
  }

  String getProvinceCode()
  {
    return provinceCode;
  }

  void setProvinceCode(String provinceCode)
  {
    this.provinceCode = provinceCode;
  }
}
