package pro.address.data;

import java.io.Serializable;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import pro.util.DateConvert;

@Entity
@NamedQueries({
  @NamedQuery(name = "ProvinceInfo.findAll", query = "select o from ProvinceInfo o")
})
@Table(name = "REF_PROVINCE_INFO")
public class ProvinceInfo
  implements Serializable
{
  @Column(name="CREATED_BY", nullable = false, length = 10)
  private String createdBy;
  @Column(name="CREATED_DATE", nullable = false)
  private Timestamp createdDate;
  @Id
  @Column(name="PROVINCE_CODE", nullable = false, length = 2)
  private String provinceCode;
  @Column(name="PROVINCE_NAME", length = 50)
  private String provinceName;
  @Column(name="UPDATED_BY", nullable = false, length = 10)
  private String updatedBy;
  @Column(name="UPDATED_DATE", nullable = false)
  private Timestamp updatedDate;

  public ProvinceInfo()
  {
  }

  public ProvinceInfo(String createdBy, Timestamp createdDate,
                      String provinceCode, String provinceName,
                      String updatedBy, Timestamp updatedDate)
  {
    this.createdBy = createdBy;
    this.createdDate = createdDate;
    this.provinceCode = provinceCode;
    this.provinceName = provinceName;
    this.updatedBy = updatedBy;
    this.updatedDate = updatedDate;
  }

  public String getCreatedBy()
  {
    return createdBy;
  }

  public void setCreatedBy(String createdBy)
  {
    this.createdBy = createdBy;
  }

  public Timestamp getCreatedDate()
  {
    return createdDate;
  }

  public void setCreatedDate(Timestamp createdDate)
  {
    this.createdDate = createdDate;
  }
    public String getCreatedDateDisplay()
    {
            String vaRtn = "";
            if (this.createdDate != null)
            {
                    vaRtn = DateConvert.convTimestamp2String(this.createdDate);
            }
            return vaRtn;
    }
  public String getProvinceCode()
  {
    return provinceCode;
  }

  public void setProvinceCode(String provinceCode)
  {
    this.provinceCode = provinceCode;
  }

  public String getProvinceName()
  {
    return provinceName;
  }

  public void setProvinceName(String provinceName)
  {
    this.provinceName = provinceName;
  }

  public String getUpdatedBy()
  {
    return updatedBy;
  }

  public void setUpdatedBy(String updatedBy)
  {
    this.updatedBy = updatedBy;
  }

  public Timestamp getUpdatedDate()
  {
    return updatedDate;
  }

  public void setUpdatedDate(Timestamp updatedDate)
  {
    this.updatedDate = updatedDate;
  }
    public String getUpdatedDateDisplay()
    {
            String vaRtn = "";
            if (this.updatedDate != null)
            {
                    vaRtn = DateConvert.convTimestamp2String(this.updatedDate);
            }
            return vaRtn;
    }
    public String toString()
    {
            return "{\"provinceCode\":\"" + provinceCode 
                            + "\", \"provinceName\":\"" + (provinceName == null ? "" : provinceName) 
                            + "\", \"createdBy\":\"" + (createdBy == null ? "" : createdBy) 
                            + "\", \"createdDate\":\"" + (createdDate == null ? "" : createdDate) 
                            + "\", \"updatedBy\":\"" + (updatedBy == null ? "" : updatedBy) 
                            + "\", \"updatedDate\":\"" + (updatedDate == null ? "" : updatedDate) 
                            + "\"}";
    }
}
