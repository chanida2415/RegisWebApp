package pro.address.data;

import java.io.Serializable;

public class AmphurInfoPK
  implements Serializable
{
  private String amphurCode;
  private String provinceCode;

  public AmphurInfoPK()
  {
  }

  public AmphurInfoPK(String amphurCode, String provinceCode)
  {
    this.amphurCode = amphurCode;
    this.provinceCode = provinceCode;
  }

  public boolean equals(Object other)
  {
    if (other instanceof AmphurInfoPK)
    {
      final AmphurInfoPK otherAmphurInfoPK = (AmphurInfoPK) other;
      final boolean areEqual =
        (otherAmphurInfoPK.amphurCode.equals(amphurCode) && otherAmphurInfoPK.provinceCode.equals(provinceCode));
      return areEqual;
    }
    return false;
  }

  public int hashCode()
  {
    return super.hashCode();
  }

  String getAmphurCode()
  {
    return amphurCode;
  }

  void setAmphurCode(String amphurCode)
  {
    this.amphurCode = amphurCode;
  }

  String getProvinceCode()
  {
    return provinceCode;
  }

  void setProvinceCode(String provinceCode)
  {
    this.provinceCode = provinceCode;
  }
}
