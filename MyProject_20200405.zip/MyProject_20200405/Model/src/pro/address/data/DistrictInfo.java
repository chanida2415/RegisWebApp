package pro.address.data;

import java.io.Serializable;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@NamedQueries({
  @NamedQuery(name = "DistrictInfo.findAll", query = "select o from DistrictInfo o")
})
@Table(name = "REF_DISTRICT_INFO")
@IdClass(DistrictInfoPK.class)
public class DistrictInfo
  implements Serializable
{
  @Id
  @Column(name="AMPHUR_CODE", nullable = false, length = 2)
  private String amphurCode;
  @Column(name="CREATED_BY", nullable = false, length = 10)
  private String createdBy;
  @Column(name="CREATED_DATE", nullable = false)
  private Timestamp createdDate;
  @Id
  @Column(name="DISTRICT_CODE", nullable = false, length = 2)
  private String districtCode;
  @Column(name="DISTRICT_NAME", length = 50)
  private String districtName;
  @Column(name="POST_CODE", length = 5)
  private String postCode;
  @Id
  @Column(name="PROVINCE_CODE", nullable = false, length = 2)
  private String provinceCode;
  @Column(name="UPDATED_BY", nullable = false, length = 10)
  private String updatedBy;
  @Column(name="UPDATED_DATE", nullable = false)
  private Timestamp updatedDate;
  
    @ManyToOne()
    @JoinColumns
    ({ 
        @JoinColumn(name = "PROVINCE_CODE", referencedColumnName = "PROVINCE_CODE", insertable = false, updatable = false, nullable = false),
        @JoinColumn(name = "AMPHUR_CODE", referencedColumnName = "AMPHUR_CODE", insertable = false, updatable = false, nullable = false) 
    })
    private AmphurInfo amphurInfo;
    
  public DistrictInfo()
  {
  }

  public DistrictInfo(String amphurCode, String createdBy,
                      Timestamp createdDate, String districtCode,
                      String districtName, String postCode,
                      String provinceCode, String updatedBy,
                      Timestamp updatedDate)
  {
    this.amphurCode = amphurCode;
    this.createdBy = createdBy;
    this.createdDate = createdDate;
    this.districtCode = districtCode;
    this.districtName = districtName;
    this.postCode = postCode;
    this.provinceCode = provinceCode;
    this.updatedBy = updatedBy;
    this.updatedDate = updatedDate;
  }

  public String getAmphurCode()
  {
    return amphurCode;
  }

  public void setAmphurCode(String amphurCode)
  {
    this.amphurCode = amphurCode;
  }

  public String getCreatedBy()
  {
    return createdBy;
  }

  public void setCreatedBy(String createdBy)
  {
    this.createdBy = createdBy;
  }

  public Timestamp getCreatedDate()
  {
    return createdDate;
  }

  public void setCreatedDate(Timestamp createdDate)
  {
    this.createdDate = createdDate;
  }

  public String getDistrictCode()
  {
    return districtCode;
  }

  public void setDistrictCode(String districtCode)
  {
    this.districtCode = districtCode;
  }

  public String getDistrictName()
  {
    return districtName;
  }

  public void setDistrictName(String districtName)
  {
    this.districtName = districtName;
  }

  public String getPostCode()
  {
    return postCode;
  }

  public void setPostCode(String postCode)
  {
    this.postCode = postCode;
  }

  public String getProvinceCode()
  {
    return provinceCode;
  }

  public void setProvinceCode(String provinceCode)
  {
    this.provinceCode = provinceCode;
  }

  public String getUpdatedBy()
  {
    return updatedBy;
  }

  public void setUpdatedBy(String updatedBy)
  {
    this.updatedBy = updatedBy;
  }

  public Timestamp getUpdatedDate()
  {
    return updatedDate;
  }

  public void setUpdatedDate(Timestamp updatedDate)
  {
    this.updatedDate = updatedDate;
  }
    public String toString()
    {
          return "{\"districtCode\":\"" + districtCode 
            + "\", \"provinceCode\":\"" + (provinceCode == null ? "" : provinceCode) 
            + "\", \"amphurCode\":\"" + (amphurCode == null ? "" : amphurCode) 
            + "\", \"districtName\":\"" + (districtName == null ? "" : districtName)
            + "\", \"postCode\":\"" + (postCode == null ? "" : postCode)
            + "\", \"createdBy\":\"" + (createdBy == null ? "" : createdBy) 
            + "\", \"createdDate\":\"" + (createdDate == null ? "" : createdDate) 
            + "\", \"updatedBy\":\"" + (updatedBy == null ? "" : updatedBy) 
            + "\", \"updatedDate\":\"" + (updatedDate == null ? "" : updatedDate) 
            + "\"}";
    }

    public void setAmphurInfo(AmphurInfo amphurInfo)
    {
        this.amphurInfo = amphurInfo;
    }

    public AmphurInfo getAmphurInfo()
    {
        return amphurInfo;
    }
}
