package pro.address.data;

import java.io.Serializable;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import pro.util.DateConvert;

@Entity
@NamedQueries({
  @NamedQuery(name = "AmphurInfo.findAll", query = "select o from AmphurInfo o")
})
@Table(name = "REF_AMPHUR_INFO")
@IdClass(AmphurInfoPK.class)
public class AmphurInfo
  implements Serializable
{
  @Id
  @Column(name="AMPHUR_CODE", nullable = false, length = 2)
  private String amphurCode;
  @Column(name="AMPHUR_NAME", length = 150)
  private String amphurName;
  @Column(name="CREATED_BY", nullable = false, length = 10)
  private String createdBy;
  @Column(name="CREATED_DATE", nullable = false)
  private Timestamp createdDate;
  @Id
  @Column(name="PROVINCE_CODE", nullable = false, length = 2)
  private String provinceCode;
  @Column(name="UPDATED_BY", nullable = false, length = 10)
  private String updatedBy;
  @Column(name="UPDATED_DATE", nullable = false)
  private Timestamp updatedDate;
  
    @ManyToOne()
    @JoinColumn(name = "PROVINCE_CODE", referencedColumnName = "PROVINCE_CODE", insertable = false, updatable = false, nullable = false)
    private ProvinceInfo provinceInfo;

  public AmphurInfo()
  {
  }

  public AmphurInfo(String amphurCode, String amphurName, String createdBy,
                    Timestamp createdDate, String provinceCode,
                    String updatedBy, Timestamp updatedDate)
  {
    this.amphurCode = amphurCode;
    this.amphurName = amphurName;
    this.createdBy = createdBy;
    this.createdDate = createdDate;
    this.provinceCode = provinceCode;
    this.updatedBy = updatedBy;
    this.updatedDate = updatedDate;
  }

    public String getAmphurCode()
    {
        return amphurCode;
    }
    
    public void setAmphurCode(String amphurCode)
    {
        this.amphurCode = amphurCode;
    }
    
    public String getAmphurName()
    {
        return amphurName;
    }
    
    public void setAmphurName(String amphurName)
    {
        this.amphurName = amphurName;
    }
    
    public String getCreatedBy()
    {
    return createdBy;
    }
    
    public void setCreatedBy(String createdBy)
    {
        this.createdBy = createdBy;
    }
    
    public String getCreatedDateDisplay()
    {
        String vaRtn = "";
        if (this.createdDate != null)
        {
            vaRtn = DateConvert.convTimestamp2String(this.createdDate);
        }
        return vaRtn;
    }
    public Timestamp getCreatedDate()
    {
        return createdDate;
    }
    
    public void setCreatedDate(Timestamp createdDate)
    {
        this.createdDate = createdDate;
    }
    
    public String getProvinceCode()
    {
        return provinceCode;
    }
    
    public void setProvinceCode(String provinceCode)
    {
        this.provinceCode = provinceCode;
    }
    
    public String getUpdatedBy()
    {
        return updatedBy;
    }
    
    public void setUpdatedBy(String updatedBy)
    {
        this.updatedBy = updatedBy;
    }
    public String getUpdatedDateDisplay()
    {
        String vaRtn = "";
        if (this.updatedDate != null)
        {
            vaRtn = DateConvert.convTimestamp2String(this.updatedDate);
        }
        return vaRtn;
    }

    public Timestamp getUpdatedDate()
    {
        return updatedDate;
    }
    
    public void setUpdatedDate(Timestamp updatedDate)
    {
        this.updatedDate = updatedDate;
    }   
    public void setProvinceInfo(ProvinceInfo provinceInfo)
    {
        this.provinceInfo = provinceInfo;
    }
    
    public ProvinceInfo getProvinceInfo()
    {
        return provinceInfo;
    }
    public String toString()
    {
      return "{\"provinceCode\":\"" + provinceCode 
        + "\", \"amphurCode\":\"" + (amphurCode == null ? "" : amphurCode) 
        + "\", \"amphurName\":\"" + (amphurName == null ? "" : amphurName) 
        + "\", \"createdBy\":\"" + (createdBy == null ? "" : createdBy) 
        + "\", \"createdDate\":\"" + (createdDate == null ? "" : createdDate) 
        + "\", \"updatedBy\":\"" + (updatedBy == null ? "" : updatedBy) 
        + "\", \"updatedDate\":\"" + (updatedDate == null ? "" : updatedDate) 

        + "\"}";
    }

 
}
