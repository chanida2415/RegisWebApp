package pro.address.service;

import java.util.List;

import pro.address.data.ProvinceInfo;
import javax.persistence.EntityManager;
import javax.persistence.Query;

public class ProvinceDAO
{
  public ProvinceDAO()
  {
    super();
  }
  public List<ProvinceInfo> getListofProvince(EntityManager em,String paProvinceName) throws  Exception 
  {
    try
    {
            StringBuffer jpqlStmt = new StringBuffer();
            jpqlStmt.append(" SELECT provinceInfo ");
            jpqlStmt.append(" FROM ProvinceInfo provinceInfo   ");
            jpqlStmt.append(" WHERE 1=1 ");
           
        if (paProvinceName != null && paProvinceName.length() != 0)
        {
                jpqlStmt.append(" AND provinceInfo.provinceName LIKE CONCAT(CONCAT('%', ?2), '%') ");
        } 
        else{
        jpqlStmt.append("ORDER BY provinceInfo.provinceCode");
        }
          Query voQuery = em.createQuery(jpqlStmt.toString());
        if (paProvinceName != null && paProvinceName.length() != 0)
        {
                voQuery.setParameter(2, paProvinceName);
        }

          return voQuery.getResultList();
    }
    catch (Exception e)
    {
      throw new Exception(new StringBuffer("CompanyInfoDAO.validateCompanyForUpdate : ").append(e.getMessage()).toString());
    }
  }
}
