package pro.address.service;

import java.util.List;

import javax.ejb.Local;

import pro.address.data.ProvinceInfo;

@Local
public interface ProvinceEJBServLocal
{
    List<ProvinceInfo> getListOfProvinceInfo(String paProvinceName) throws Exception;
}
