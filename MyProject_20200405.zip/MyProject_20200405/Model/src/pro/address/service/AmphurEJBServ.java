package pro.address.service;

import java.util.List;

import javax.ejb.Remote;

import pro.address.data.AmphurInfo;

@Remote
public interface AmphurEJBServ
{
    List<AmphurInfo> getListOfAmphurInfoActive(String paProvinceCode,String paAmphurName)
         throws Exception;
}
