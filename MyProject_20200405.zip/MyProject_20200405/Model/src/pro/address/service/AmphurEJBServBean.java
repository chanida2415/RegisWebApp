package pro.address.service;

import java.util.List;

import javax.annotation.Resource;

import javax.ejb.EJBContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import pro.address.data.AmphurInfo;

@Stateless(name = "AmphurEJBServ", mappedName = "AmphurEJBServ")
@TransactionManagement(TransactionManagementType.BEAN)
public class AmphurEJBServBean
  implements AmphurEJBServ, AmphurEJBServLocal
{
  @PersistenceContext(unitName = "reg")
  private EntityManager em;
  @Resource
  private EJBContext context;
  public AmphurEJBServBean()
  {
  }
  public List<AmphurInfo> getListOfAmphurInfoActive(String paProvinceCode,String paAmphurName)
     throws Exception
  {
     List<AmphurInfo> voAmphurInfoList = null;
     AmphurDAO voAmphurDAO = new AmphurDAO();
     try
     {
        voAmphurInfoList = voAmphurDAO.getListOfAmphurInfoActive(em, paProvinceCode,paAmphurName);
     }
     catch (Exception e)
     {
        throw new Exception(new StringBuffer("AmphurEJBServBean.getListOfAmphurInfoActive : ").append(e.getMessage()).toString());
     }

     return voAmphurInfoList;
  }
}
