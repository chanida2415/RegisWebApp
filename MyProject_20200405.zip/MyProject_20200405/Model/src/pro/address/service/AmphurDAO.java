package pro.address.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import pro.address.data.AmphurInfo;
import pro.address.data.ProvinceInfo;

public class AmphurDAO
{
  public AmphurDAO()
  {
    super();
  }
  public List<AmphurInfo> getListOfAmphurInfoActive(EntityManager em, String paProvinceCode,String paAmphurName)
     throws Exception
  {
     StringBuffer jpqlStmt = new StringBuffer();
     jpqlStmt.append(" SELECT  amphurInfo ");
     jpqlStmt.append(" FROM AmphurInfo amphurInfo ");
     jpqlStmt.append(" WHERE 1=1 ");
     if (paProvinceCode != null && paProvinceCode.length() != 0)
     {
        jpqlStmt.append(" AND amphurInfo.provinceCode = ?1 ");
     }
      if (paAmphurName != null && paAmphurName.length() != 0)
      {
         jpqlStmt.append(" AND amphurInfo.amphurName LIKE CONCAT(CONCAT('%', ?2), '%') ");
      }
   
      jpqlStmt.append(" ORDER BY amphurInfo.amphurCode");

      Query voQuery = em.createQuery(jpqlStmt.toString());
         if (paProvinceCode != null && paProvinceCode.length() != 0)
         {
            voQuery.setParameter(1, paProvinceCode);
         }
         if (paAmphurName != null && paAmphurName.length() != 0)
         {
            voQuery.setParameter(2, paAmphurName);
         }

     return voQuery.getResultList();
  }
       
}
