package pro.address.service;

import java.util.List;

import javax.ejb.Local;

import pro.address.data.AmphurInfo;

@Local
public interface AmphurEJBServLocal
{
    List<AmphurInfo> getListOfAmphurInfoActive(String paProvinceCode,String paAmphurName)
         throws Exception;
}
