package pro.address.service;

import java.util.List;

import javax.annotation.Resource;

import javax.ejb.EJBContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import pro.address.data.DistrictInfo;

@Stateless(name = "DistrictEJBServ", mappedName = "DistrictEJBServ")
@TransactionManagement(TransactionManagementType.BEAN)
public class DistrictEJBServBean
  implements DistrictEJBServ, DistrictEJBServLocal
{
  @PersistenceContext(unitName = "reg")
  private EntityManager em;
  @Resource
  private EJBContext context;
  public DistrictEJBServBean()
  {
  }
  public List<DistrictInfo> getListOfDistrictInfoActive(String paProvinceCode, String paAmphurCode, String paDistrictName) throws Exception
  {
      List<DistrictInfo> voDistrictInfoList = null;
      DistrictDAO voDistrictInfoDAO = new DistrictDAO();
      try
      {
          voDistrictInfoList = voDistrictInfoDAO.getListOfDistrictInfoActive(em, paProvinceCode, paAmphurCode, paDistrictName);
      }
      catch (Exception e)
      {
          throw new Exception(new StringBuffer("DistrictInfoEJBServBean.getListOfDistrictInfoActive : ").append(e.getMessage()).toString());
      }

      return voDistrictInfoList;
  }

}
