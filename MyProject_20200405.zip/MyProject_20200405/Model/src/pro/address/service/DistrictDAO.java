package pro.address.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import pro.address.data.DistrictInfo;

public class DistrictDAO
{
  public DistrictDAO()
  {
    super();
  }
  public List<DistrictInfo> getListOfDistrictInfoActive(EntityManager em, String paProvinceCode, String paAmphurCode, String paDistrictName) throws Exception
  {
      StringBuffer jpqlStmt = new StringBuffer();
      jpqlStmt.append(" SELECT districtInfo ");
      jpqlStmt.append(" FROM DistrictInfo districtInfo ");
      jpqlStmt.append(" WHERE 1=1 ");
      if (paProvinceCode != null && paProvinceCode.length() != 0)
      {
          jpqlStmt.append(" AND districtInfo.provinceCode = ?1 ");
      }
      if (paAmphurCode != null && paAmphurCode.length() != 0)
      {
          jpqlStmt.append(" AND districtInfo.amphurCode = ?2 ");
      }
      if (paDistrictName != null && paDistrictName.length() != 0)
      {
          jpqlStmt.append(" AND  districtInfo.districtName LIKE CONCAT(CONCAT('%', ?3), '%') ");
      }
      jpqlStmt.append(" ORDER BY districtInfo.districtCode");

      Query voQuery = em.createQuery(jpqlStmt.toString());
      if (paProvinceCode != null && paProvinceCode.length() != 0)
      {
          voQuery.setParameter(1, paProvinceCode);
      }
      if (paAmphurCode != null && paAmphurCode.length() != 0)
      {
          voQuery.setParameter(2, paAmphurCode);
      }
      if (paDistrictName != null && paDistrictName.length() != 0)
      {
          voQuery.setParameter(3, paDistrictName);
      }
      return voQuery.getResultList();
  }
}
