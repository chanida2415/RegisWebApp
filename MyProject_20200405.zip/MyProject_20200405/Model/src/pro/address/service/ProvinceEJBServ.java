package pro.address.service;

import java.util.List;

import javax.ejb.Remote;

import pro.address.data.ProvinceInfo;

@Remote
public interface ProvinceEJBServ
{
    List<ProvinceInfo> getListOfProvinceInfo(String paProvinceName) throws Exception;
}
