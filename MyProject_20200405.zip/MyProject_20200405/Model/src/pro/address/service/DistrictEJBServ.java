package pro.address.service;

import java.util.List;

import javax.ejb.Remote;

import pro.address.data.DistrictInfo;

@Remote
public interface DistrictEJBServ
{
  List<DistrictInfo> getListOfDistrictInfoActive(String paProvinceCode, String paAmphurCode, String paDistrictName) throws Exception;
}
