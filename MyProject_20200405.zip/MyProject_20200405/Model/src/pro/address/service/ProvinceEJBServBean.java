package pro.address.service;

import java.util.List;

import javax.annotation.Resource;

import javax.ejb.EJBContext;
import javax.ejb.Stateless;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import pro.address.data.ProvinceInfo;

@Stateless(name = "ProvinceEJBServ", mappedName = "ProvinceEJBServ")
public class ProvinceEJBServBean
  implements ProvinceEJBServ, ProvinceEJBServLocal
{
  @PersistenceContext(unitName = "reg")
  private EntityManager em;
  @Resource
  private EJBContext context;
  public ProvinceEJBServBean()
  {
  }
  public List<ProvinceInfo> getListOfProvinceInfo(String paProvinceName) throws Exception
  {
          List<ProvinceInfo> voProvinceInfoList = null;
          ProvinceDAO voProvinceDAO = new ProvinceDAO();
          try
          {
                 

                  voProvinceInfoList = voProvinceDAO.getListofProvince(em,paProvinceName);

          }
          catch (Exception e)
          {
                  throw new Exception(new StringBuffer("ProvinceEJBServBean.getListOfProvinceInfo : ").append(e.getMessage()).toString());
          }

          return voProvinceInfoList;
  }
}
