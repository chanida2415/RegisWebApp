package pro.address.service;

import java.util.List;

import javax.ejb.Local;

import pro.address.data.DistrictInfo;

@Local
public interface DistrictEJBServLocal
{
  List<DistrictInfo> getListOfDistrictInfoActive(String paProvinceCode, String paAmphurCode, String paDistrictName) throws Exception;
}
