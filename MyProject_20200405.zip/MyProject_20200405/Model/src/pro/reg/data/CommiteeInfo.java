package pro.reg.data;

import java.io.Serializable;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import pro.address.data.AmphurInfo;
import pro.address.data.DistrictInfo;
import pro.address.data.ProvinceInfo;

import pro.util.DateConvert;

@Entity
@NamedQueries({
  @NamedQuery(name = "CommiteeInfo.findAll", query = "select o from CommiteeInfo o")
})
@Table(name = "COMMITEE_INFO")
public class CommiteeInfo implements Serializable
{
    @Column(length = 150)
    private String amphur;
  @Column(name="AMPHUR_CODE", length = 20)
  private String amphurCode;
    @Column(length = 150)
    private String build;
    @Column(length = 100)
    private String cardtype;
    @Id
    @Column(name="CITIZEN_ID", nullable = false, length = 15)
    private String citizenId;
    @Column(name="COMPANY_ID", nullable = false, length = 15)
    private String companyId;
    @Column(name="CREATED_BY", length = 10)
    private String createdBy;
    @Column(name="CREATED_DATE")
    private Timestamp createdDate;
    @Column(length = 150)
    private String district;
  @Column(name="DISTRICT_CODE", length = 20)
  private String districtCode;
    @Column(length = 50)
    private String email;
    @Column(name="END_DATE")
    private Timestamp endDate;
    @Column(length = 300)
    private String fristname;
    @Column(name="HOUSE_NUM", length = 150)
    private String houseNum;
    @Column(length = 50)
    private String ipaddress;
    @Column(length = 300)
    private String lastname;
    @Column(length = 50)
    private String moo;
    @Column(length = 100)
    private String mooname;
    @Column(length = 20)
    private String phone;
    @Column(length = 150)
    private String province;
  @Column(name="PROVINCE_CODE", length = 20)
  private String provinceCode;
    @Column(name="REC_STATUS")
    private Long recStatus;
    @Column(length = 150)
    private String road;
    @Column(length = 150)
    private String soi;
    @Column(name="START_DATE")
    private Timestamp startDate;
    @Column(name="UPDATED_BY", length = 10)
    private String updatedBy;
    @Column(name="UPDATED_DATE")
    private Timestamp updatedDate;
    @Column(length = 10)
    private String zipcode;
  @Column(name="PREFIX_CODE", length = 3)
  private String prefixCode;
  @Column(name = "PREFIX_OTHER", length = 30)
  private String prefixOther;

  
    @ManyToOne()
    @JoinColumn(name = "PROVINCE_CODE", referencedColumnName = "PROVINCE_CODE", insertable = false, updatable = false, nullable = false)
    private ProvinceInfo provinceInfo;

      @ManyToOne()
      @JoinColumns( { @JoinColumn(name = "PROVINCE_CODE", referencedColumnName = "PROVINCE_CODE", insertable = false, updatable = false, nullable = false),
                      @JoinColumn(name = "AMPHUR_CODE", referencedColumnName = "AMPHUR_CODE", insertable = false, updatable = false, nullable = false) })
      private AmphurInfo amphurInfo;
     
      @ManyToOne()
      @JoinColumns( { @JoinColumn(name = "PROVINCE_CODE", referencedColumnName = "PROVINCE_CODE", insertable = false, updatable = false, nullable = false),
                      @JoinColumn(name = "AMPHUR_CODE", referencedColumnName = "AMPHUR_CODE", insertable = false, updatable = false, nullable = false),
                      @JoinColumn(name = "DISTRICT_CODE", referencedColumnName = "DISTRICT_CODE", insertable = false, updatable = false, nullable = false) })
      private DistrictInfo districtInfo;
      
      @ManyToOne()
      @JoinColumn(name = "CREATED_BY", referencedColumnName = "USER_ID", insertable = false, updatable = false, nullable = false)
      private SecUserInfo userCreatedInfo;
      
      @ManyToOne()
      @JoinColumn(name = "UPDATED_BY", referencedColumnName = "USER_ID", insertable = false, updatable = false, nullable = false)
      private SecUserInfo userUpdateInfo;
      
  @ManyToOne()
  @JoinColumn(name = "PREFIX_CODE", referencedColumnName = "PREFIX_CODE", insertable = false, updatable = false, nullable = false)
  private PrefixName prefixName;
  
    public CommiteeInfo()
    {
    }

    public CommiteeInfo(String amphur, String build, String cardtype,String amphurCode,
                        String citizenId, String companyId,String prefixCode,String prefixOther,
                        String createdBy, Timestamp createdDate,
                        String district, String email, Timestamp endDate,   String districtCode,
                        String fristname, String houseNum, String provinceCode,
                        String ipaddress, String lastname, String moo,
                        String mooname, String phone, String province,
                        Long recStatus, String road, String soi,
                        Timestamp startDate, String updatedBy,
                        Timestamp updatedDate, String zipcode)
    {
        this.amphur = amphur;
      this.amphurCode = amphurCode;
      this.districtCode = districtCode;
      this.provinceCode = provinceCode;
      this.prefixCode = prefixCode;
      this.prefixOther = prefixOther;
        this.build = build;
        this.cardtype = cardtype;
        this.citizenId = citizenId;
        this.companyId = companyId;
        this.createdBy = createdBy;
        this.createdDate = createdDate;
        this.district = district;
        this.email = email;
        this.endDate = endDate;
        this.fristname = fristname;
        this.houseNum = houseNum;
        this.ipaddress = ipaddress;
        this.lastname = lastname;
        this.moo = moo;
        this.mooname = mooname;
        this.phone = phone;
        this.province = province;
        this.recStatus = recStatus;
        this.road = road;
        this.soi = soi;
        this.startDate = startDate;
        this.updatedBy = updatedBy;
        this.updatedDate = updatedDate;
        this.zipcode = zipcode;
    }

    public String getAmphur()
    {
        return amphur;
    }

    public void setAmphur(String amphur)
    {
        this.amphur = amphur;
    }

    public String getBuild()
    {
        return build;
    }

    public void setBuild(String build)
    {
        this.build = build;
    }

    public String getCardtype()
    {
        return cardtype;
    }

    public void setCardtype(String cardtype)
    {
        this.cardtype = cardtype;
    }

    public String getCitizenId()
    {
        return citizenId;
    }

    public void setCitizenId(String citizenId)
    {
        this.citizenId = citizenId;
    }

    public String getCompanyId()
    {
        return companyId;
    }

    public void setCompanyId(String companyId)
    {
        this.companyId = companyId;
    }

    public String getCreatedBy()
    {
        return createdBy;
    }

    public void setCreatedBy(String createdBy)
    {
        this.createdBy = createdBy;
    }

    public Timestamp getCreatedDate()
    {
        return createdDate;
    }

    public void setCreatedDate(Timestamp createdDate)
    {
        this.createdDate = createdDate;
    }

    public String getDistrict()
    {
        return district;
    }

    public void setDistrict(String district)
    {
        this.district = district;
    }

    public String getEmail()
    {
        return email;
    }

    public void setEmail(String email)
    {
        this.email = email;
    }

    public Timestamp getEndDate()
    {
        return endDate;
    }

    public void setEndDate(Timestamp endDate)
    {
        this.endDate = endDate;
    }

    public String getFristname()
    {
        return fristname;
    }

    public void setFristname(String fristname)
    {
        this.fristname = fristname;
    }

    public String getHouseNum()
    {
        return houseNum;
    }

    public void setHouseNum(String houseNum)
    {
        this.houseNum = houseNum;
    }

    public String getIpaddress()
    {
        return ipaddress;
    }

    public void setIpaddress(String ipaddress)
    {
        this.ipaddress = ipaddress;
    }

    public String getLastname()
    {
        return lastname;
    }

    public void setLastname(String lastname)
    {
        this.lastname = lastname;
    }

    public String getMoo()
    {
        return moo;
    }

    public void setMoo(String moo)
    {
        this.moo = moo;
    }

    public String getMooname()
    {
        return mooname;
    }

    public void setMooname(String mooname)
    {
        this.mooname = mooname;
    }

    public String getPhone()
    {
        return phone;
    }

    public void setPhone(String phone)
    {
        this.phone = phone;
    }

    public String getProvince()
    {
        return province;
    }

    public void setProvince(String province)
    {
        this.province = province;
    }

    public Long getRecStatus()
    {
        return recStatus;
    }

    public void setRecStatus(Long recStatus)
    {
        this.recStatus = recStatus;
    }

    public String getRoad()
    {
        return road;
    }

    public void setRoad(String road)
    {
        this.road = road;
    }

    public String getSoi()
    {
        return soi;
    }

    public void setSoi(String soi)
    {
        this.soi = soi;
    }

    public Timestamp getStartDate()
    {
        return startDate;
    }

    public void setStartDate(Timestamp startDate)
    {
        this.startDate = startDate;
    }

    public String getUpdatedBy()
    {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy)
    {
        this.updatedBy = updatedBy;
    }

    public Timestamp getUpdatedDate()
    {
        return updatedDate;
    }

    public void setUpdatedDate(Timestamp updatedDate)
    {
        this.updatedDate = updatedDate;
    }

    public String getZipcode()
    {
        return zipcode;
    }

    public void setZipcode(String zipcode)
    {
        this.zipcode = zipcode;
    }

  public void setProvinceCode(String provinceCode)
  {
      this.provinceCode = provinceCode;
  }


    public void setProvinceInfo(ProvinceInfo provinceInfo)
    {
        this.provinceInfo = provinceInfo;
    }

    public ProvinceInfo getProvinceInfo()
    {
        return provinceInfo;
    }

    public void setAmphurInfo(AmphurInfo amphurInfo)
    {
        this.amphurInfo = amphurInfo;
    }

    public AmphurInfo getAmphurInfo()
    {
        return amphurInfo;
    }

    public void setDistrictInfo(DistrictInfo districtInfo)
    {
        this.districtInfo = districtInfo;
    }

    public DistrictInfo getDistrictInfo()
    {
        return districtInfo;
    }
    public void setUserInfo(SecUserInfo userCreatedInfo)
        {
            this.userCreatedInfo = userCreatedInfo;
        }

        public SecUserInfo getUserInfo()
        {
            return userCreatedInfo;
        }

        public void setUserUpdateInfo(SecUserInfo userUpdateInfo)
        {
            this.userUpdateInfo = userUpdateInfo;
        }

        public SecUserInfo getUserUpdateInfo()
        {
            return userUpdateInfo;
        }
        public String getUpdatedByDisplay()
        {
            String vaRtn = this.updatedBy;
            SecUserInfo voUserUpdateInfo = this.userUpdateInfo;
            if (voUserUpdateInfo != null)
            {
                vaRtn = vaRtn + " - " + voUserUpdateInfo.getFirstName() + " " + voUserUpdateInfo.getLastName();
            }
            return vaRtn;
        }
        
        public String getUpdatedByName()
        {
            String vaRtn = "";
                    SecUserInfo voUserUpdateInfo = this.userUpdateInfo;
            if (voUserUpdateInfo != null)
            {
                vaRtn = voUserUpdateInfo.getFirstName() + " " + voUserUpdateInfo.getLastName();
            }
            return vaRtn;
        }
        public String getUpdatedDateDisplay()
        {
            String vaRtn = "";
            if (this.updatedDate != null)
            {
                vaRtn = DateConvert.convTimestamp2String(this.updatedDate);
            }
            return vaRtn;
        }

        public String getPhoneDisplay()
        {
            String vaRtn = "";
            if (this.phone != null && this.phone.length() == 10)
            {
                vaRtn = this.phone.substring(0, 3) + "-" + this.phone.substring(3, 6) + "-" + this.phone.substring(6);
            }
            else if (this.phone != null && this.phone.length() != 10)
            {
                vaRtn = this.phone;
            }
            return vaRtn;
        }
        
        public String getCreatedName()
        {
            String vaRtn = "";
            SecUserInfo voUserCreatedInfo = this.userCreatedInfo;
            if (voUserCreatedInfo != null)
            {
                vaRtn = voUserCreatedInfo.getFirstName() + " " + voUserCreatedInfo.getLastName();
            }
            return vaRtn;
        }
       
        public String getCreatedDateDisplay()
        {
            String vaRtn = "";
            if (this.createdDate != null)
            {
                vaRtn = DateConvert.convTimestamp2String(this.createdDate);
            }
            return vaRtn;
        }
        public String getCreatedByDisplay()
        {
            String vaRtn = this.createdBy;
            SecUserInfo voUserCreatedInfo = this.userCreatedInfo;
            if (voUserCreatedInfo != null)
            {
                vaRtn = vaRtn + " - " + voUserCreatedInfo.getFirstName() + " " + voUserCreatedInfo.getLastName();
            }
            
            return vaRtn;
        }
  public String getFirstnameDisplay()
  {
      String vaRtn = "";
      if (this.fristname != null && this.fristname.length() != 0)
      {
          vaRtn = this.fristname.replaceAll("'", "\\\'").replaceAll("\"", "&quot;");
      }
      return vaRtn;
  }

  public String getLastnameDisplay()
  {
      String vaRtn = "";
      if (this.lastname != null && this.lastname.length() != 0)
      {
          vaRtn = this.lastname.replaceAll("'", "\\\'").replaceAll("\"", "&quot;");
      }
      return vaRtn;
  }
  public PrefixName getPrefixName()
  {
      if (prefixCode != null && prefixCode.equals("99"))
      {
          PrefixName voPrefixName = new PrefixName();
          voPrefixName.setPrefixCode(prefixCode);
          voPrefixName.setPrefixName(prefixOther);
          return voPrefixName;
      }
      else
      {
          return prefixName;
      }
  }

    public String toString()
    {
       
      return "{\"companyId\":\"" + this.companyId 
      + "\",\"fristname\":\"" +(this.fristname == null? "": this.fristname) 
      +"\",\"lastname\":\""    +(this.lastname == null? "": this.lastname) 
        +"\",\"citizenId\":\""    +(this.citizenId == null? "": this.citizenId) 
      + "\", \"houseNum\":\"" + (houseNum == null ? "" : houseNum.replaceAll("'","\\\'").replaceAll("\"","\\\\\"").replaceAll("\r\n", " ")) 
      + "\", \"moo\":\"" + (moo == null ? "" : moo.replaceAll("'","\\\'").replaceAll("\"","\\\\\"").replaceAll("\r\n", " ")) 
      + "\", \"mooname\":\"" + (mooname == null ? "" : mooname.replaceAll("'","\\\'").replaceAll("\"","\\\\\"").replaceAll("\r\n", " "))
      + "\", \"build\":\"" + (build == null ? "" : build.replaceAll("'","\\\'").replaceAll("\"","\\\\\"").replaceAll("\r\n", " "))
      + "\", \"soi\":\"" + (soi == null ? "" : soi.replaceAll("'","\\\'").replaceAll("\"","\\\\\"").replaceAll("\r\n", " "))
      + "\", \"road\":\"" + (road == null ? "" : road.replaceAll("'","\\\'").replaceAll("\"","\\\\\"").replaceAll("\r\n", " "))
      + "\", \"districtName\":\"" + (districtInfo == null ? "" : districtInfo.getDistrictName().replaceAll("'","\\\'").replaceAll("\"","\\\\\"").replaceAll("\r\n", " "))
      + "\", \"amphurName\":\"" + (amphurInfo == null ? "" : amphurInfo.getAmphurName().replaceAll("'","\\\'").replaceAll("\"","\\\\\"").replaceAll("\r\n", " "))
      + "\", \"provinceName\":\"" + (provinceInfo == null ? "" : provinceInfo.getProvinceName().replaceAll("'","\\\'").replaceAll("\"","\\\\\"").replaceAll("\r\n", " "))
      + "\", \"zipcode\":\"" + (zipcode == null ? "" : zipcode)
      + "\", \"phone\":\"" + (phone == null ? "" : phone)
      + "\", \"phoneNumberDisplay\":\"" + (phone == null ? "" : getPhoneDisplay())
      + "\", \"email\":\"" + (email == null ? "" : email)
      + "\", \"createdByDisplay\":\"" + (getCreatedByDisplay()==null? "" : getCreatedByDisplay().replaceAll("'","\\\'").replaceAll("\"","\\\\\"").replaceAll("\r\n", " "))
      + "\", \"updatedByDisplay\":\"" + getUpdatedByDisplay()
      + "\", \"updatedByName\":\"" + getUpdatedByName()
      + "\", \"updatedDateDisplay\":\"" + getUpdatedDateDisplay()
      + "\", \"createdDateDisplay\":\"" + getCreatedDateDisplay()
      
      +"\"}";
    }

  public void setAmphurCode(String amphurCode)
  {
    this.amphurCode = amphurCode;
  }

  public String getAmphurCode()
  {
    return amphurCode;
  }

  public void setDistrictCode(String districtCode)
  {
    this.districtCode = districtCode;
  }

  public String getDistrictCode()
  {
    return districtCode;
  }

  public String getProvinceCode()
  {
    return provinceCode;
  }

  public void setPrefixCode(String prefixCode)
  {
    this.prefixCode = prefixCode;
  }

  public String getPrefixCode()
  {
    return prefixCode;
  }

  public void setPrefixName(PrefixName prefixName)
  {
    this.prefixName = prefixName;
  }

 

  public void setPrefixOther(String prefixOther)
  {
    this.prefixOther = prefixOther;
  }

  public String getPrefixOther()
  {
    return prefixOther;
  }
}
