package pro.reg.data;

import java.io.Serializable;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@NamedQueries({
  @NamedQuery(name = "Webservice.findAll", query = "select o from Webservice o")
})
@Table(name = "REF_WEBSERVICE")
public class Webservice implements Serializable
{
    @Column(name="CREATED_BY", nullable = false, length = 10)
    private String createdBy;
    @Column(name="CREATED_DATE", nullable = false)
    private Timestamp createdDate;
    @Column(name="UPDATED_BY", nullable = false, length = 10)
    private String updatedBy;
    @Column(name="UPDATED_DATE", nullable = false)
    private Timestamp updatedDate;
    @Column(nullable = false, length = 100)
    private String url;
    @Id
    @Column(name="URL_ID", nullable = false)
    private int urlId;
    @Column(name="URL_NAME", length = 20)
    private String urlName;

    public Webservice()
    {
    }

    public Webservice(String createdBy, Timestamp createdDate,
                      String updatedBy, Timestamp updatedDate, String url,
                      int urlId, String urlName)
    {
        this.createdBy = createdBy;
        this.createdDate = createdDate;
        this.updatedBy = updatedBy;
        this.updatedDate = updatedDate;
        this.url = url;
        this.urlId = urlId;
        this.urlName = urlName;
    }

    public String getCreatedBy()
    {
        return createdBy;
    }

    public void setCreatedBy(String createdBy)
    {
        this.createdBy = createdBy;
    }

    public Timestamp getCreatedDate()
    {
        return createdDate;
    }

    public void setCreatedDate(Timestamp createdDate)
    {
        this.createdDate = createdDate;
    }

    public String getUpdatedBy()
    {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy)
    {
        this.updatedBy = updatedBy;
    }

    public Timestamp getUpdatedDate()
    {
        return updatedDate;
    }

    public void setUpdatedDate(Timestamp updatedDate)
    {
        this.updatedDate = updatedDate;
    }

    public String getUrl()
    {
        return url;
    }

    public void setUrl(String url)
    {
        this.url = url;
    }

    public int getUrlId()
    {
        return urlId;
    }

    public void setUrlId(int urlId)
    {
        this.urlId = urlId;
    }

    public String getUrlName()
    {
        return urlName;
    }

    public void setUrlName(String urlName)
    {
        this.urlName = urlName;
    }
}
