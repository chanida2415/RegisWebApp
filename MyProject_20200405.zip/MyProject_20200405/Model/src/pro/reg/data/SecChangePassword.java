package pro.reg.data;

import java.io.Serializable;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@NamedQueries({
  @NamedQuery(name = "SecChangePassword.findAll", query = "select o from SecChangePassword o")
})
@Table(name = "SEC_CHANGE_PASSWORD")
public class SecChangePassword
  implements Serializable
{
  @Id
  @Column(name="CHANGE_SEQ", nullable = false)
  private int changeSeq;
  @Column(name="CREATED_BY", nullable = false, length = 10)
  private String createdBy;
  @Column(name="CREATED_DATE", nullable = false)
  private Timestamp createdDate;
  @Column(length = 50)
  private String ipaddress;
  @Column(name="NEW_PASSWORD", length = 128)
  private String newPassword;
  @Column(name="OLD_PASSWORD", length = 128)
  private String oldPassword;
  @Column(name="UPDATED_BY", nullable = false, length = 10)
  private String updatedBy;
  @Column(name="UPDATED_DATE", nullable = false)
  private Timestamp updatedDate;
  @Column(name="USER_ID", nullable = false, length = 10)
  private String userId;

  public SecChangePassword()
  {
  }

  public SecChangePassword(int changeSeq, String createdBy,
                           Timestamp createdDate, String ipaddress,
                           String newPassword, String oldPassword,
                           String updatedBy, Timestamp updatedDate,
                           String userId)
  {
    this.changeSeq = changeSeq;
    this.createdBy = createdBy;
    this.createdDate = createdDate;
    this.ipaddress = ipaddress;
    this.newPassword = newPassword;
    this.oldPassword = oldPassword;
    this.updatedBy = updatedBy;
    this.updatedDate = updatedDate;
    this.userId = userId;
  }

  public int getChangeSeq()
  {
    return changeSeq;
  }

  public void setChangeSeq(int changeSeq)
  {
    this.changeSeq = changeSeq;
  }

  public String getCreatedBy()
  {
    return createdBy;
  }

  public void setCreatedBy(String createdBy)
  {
    this.createdBy = createdBy;
  }

  public Timestamp getCreatedDate()
  {
    return createdDate;
  }

  public void setCreatedDate(Timestamp createdDate)
  {
    this.createdDate = createdDate;
  }

  public String getIpaddress()
  {
    return ipaddress;
  }

  public void setIpaddress(String ipaddress)
  {
    this.ipaddress = ipaddress;
  }

  public String getNewPassword()
  {
    return newPassword;
  }

  public void setNewPassword(String newPassword)
  {
    this.newPassword = newPassword;
  }

  public String getOldPassword()
  {
    return oldPassword;
  }

  public void setOldPassword(String oldPassword)
  {
    this.oldPassword = oldPassword;
  }

  public String getUpdatedBy()
  {
    return updatedBy;
  }

  public void setUpdatedBy(String updatedBy)
  {
    this.updatedBy = updatedBy;
  }

  public Timestamp getUpdatedDate()
  {
    return updatedDate;
  }

  public void setUpdatedDate(Timestamp updatedDate)
  {
    this.updatedDate = updatedDate;
  }

  public String getUserId()
  {
    return userId;
  }

  public void setUserId(String userId)
  {
    this.userId = userId;
  }
}
