package pro.reg.data;

import java.io.Serializable;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@NamedQueries({
  @NamedQuery(name = "SecUserInfo.findAll", query = "select o from SecUserInfo o")
})
@Table(name = "SEC_USER_INFO")
public class SecUserInfo implements Serializable {
    @Column(name="CREATED_BY", nullable = false, length = 10)
    private String createdBy;
    @Column(name="CREATED_DATE", nullable = false)
    private Timestamp createdDate;
    @Column(length = 50)
    private String email;
    @Column(name="FIRST_NAME", nullable = false, length = 50)
    private String firstName;
    @Column(name="LAST_NAME", nullable = false, length = 50)
    private String lastName;
    @Column(name="PASSWORD_CHANG_DATE")
    private Timestamp passwordChangDate;
    @Column(name="PREFIX_NAME", nullable = false, length = 50)
    private String prefixName;
    @Column(name="IPADDRESS", length = 50)
    private String ipaddress;
    @Column(name="REGISTERED_DATE")
    private Timestamp registeredDate;
    @Column(name="UPDATED_BY", nullable = false, length = 10)
    private String updatedBy;
    @Column(name="UPDATED_DATE", nullable = false)
    private Timestamp updatedDate;
    @Id
    @Column(name="USER_ID", nullable = false, length = 10)
    private String userId;
    @Column(name="USER_PASSWORD", nullable = false, length = 128)
    private String userPassword;
    @Column(name="AGENT_ID", length = 13)
    private String agentId;
    @Column(name="REC_STATUS")
    private Integer recStatus;

    @ManyToOne()
    @JoinColumn(name="UPDATED_BY", insertable=false, updatable=false, nullable=false)
    private SecUserInfo userUpdateInfo; 
    
    public SecUserInfo() {
    }

    public SecUserInfo(String createdBy, Timestamp createdDate, String email,
                       String firstName, String lastName,String agentId,String ipaddress,
                       Timestamp passwordChangDate, String prefixName,
                        Timestamp registeredDate, String updatedBy,
                       Timestamp updatedDate, String userId,
                       String userPassword,Integer recStatus) {
        this.createdBy = createdBy;
        this.createdDate = createdDate;
        this.email = email;
        this.agentId = agentId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.passwordChangDate = passwordChangDate;
        this.prefixName = prefixName;
        this.ipaddress=ipaddress;
        this.registeredDate = registeredDate;
        this.updatedBy = updatedBy;
        this.updatedDate = updatedDate;
        this.userId = userId;
        this.userPassword = userPassword;
        this.recStatus = recStatus;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Timestamp getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Timestamp createdDate) {
        this.createdDate = createdDate;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

 
    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Timestamp getPasswordChangDate() {
        return passwordChangDate;
    }

    public void setPasswordChangDate(Timestamp passwordChangDate) {
        this.passwordChangDate = passwordChangDate;
    }

    public String getPrefixName() {
        return prefixName;
    }

    public void setPrefixName(String prefixName) {
        this.prefixName = prefixName;
    }

   
    public Timestamp getRegisteredDate() {
        return registeredDate;
    }

    public void setRegisteredDate(Timestamp registeredDate) {
        this.registeredDate = registeredDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }
    public String getUpdatedByDisplay()
    {
       String vaRtn = this.updatedBy;
       if(this.userUpdateInfo != null)
       {
          vaRtn = vaRtn+" - "+this.userUpdateInfo.getFirstName()+" "+this.userUpdateInfo.getLastName();
       }
       return vaRtn;
    }
    public Timestamp getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Timestamp updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }
    public void setUserUpdateInfo(SecUserInfo userUpdateInfo)
    {
        this.userUpdateInfo = userUpdateInfo;
    }

    public SecUserInfo getUserUpdateInfo()
    {
        return userUpdateInfo;
    }
    public String toString() 
    {
       return "{\"email\":\"" + (email==null?"":email)
          
                + "\", \"prefixName\":\"" + (prefixName==null?"":prefixName)
                + "\", \"agentId\":\"" + (agentId==null?"":agentId)
                + "\", \"registeredDate\":\"" + (registeredDate==null?"":registeredDate)
                + "\", \"firstName\":\"" + (firstName==null?"":firstName)
                + "\", \"lastName\":\"" + (lastName==null?"":lastName)
                + "\", \"userId\":\"" + (userId==null?"":userId)
                + "\", \"createdBy\":\"" + (createdBy==null?"":createdBy)
                + "\", \"createdDate\":\"" + (createdDate==null?"":createdDate)
                + "\", \"updatedBy\":\"" + (updatedBy==null?"":updatedBy)
                + "\", \"updatedDate\":\"" + (updatedDate==null?"":updatedDate)
                +"\"}";
         
    }

    public void setAgentId(String agentId)
    {
        this.agentId = agentId;
    }

    public String getAgentId()
    {
        return agentId;
    }

    public void setIpaddress(String ipaddress)
    {
        this.ipaddress = ipaddress;
    }

    public String getIpaddress()
    {
        return ipaddress;
    }

    public void setRecStatus(Integer recStatus)
    {
        this.recStatus = recStatus;
    }

    public Integer getRecStatus()
    {
        return recStatus;
    }
}
