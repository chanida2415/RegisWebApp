package pro.reg.data;

import java.io.Serializable;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import pro.address.data.ProvinceInfo;

import pro.util.DateConvert;

@Entity
@NamedQueries({
  @NamedQuery(name = "WebserviceLog.findAll", query = "select o from WebserviceLog o")
})
@Table(name = "CALL_WEBSERVICE")

public class WebserviceLog implements Serializable
{
    @Column(name="AGENT_ID", length = 13)
    private String agentId;
    @Column(name="COMPANY_ID", length = 13)
    private String companyId;
    @Column(name="CREATED_BY", nullable = false, length = 10)
    private String createdBy;
    @Column(name="CREATED_DATE", nullable = false)
    private Timestamp createdDate;
    @Column(name="DATA_RESPONSE")
    private String dataResponse;

    @Column(name="DPA_STATUS_CODE", length = 5)
    private String dpaStatusCode;
    @Column(name="DPA_STATUS_DESC_EN", length = 200)
    private String dpaStatusDescEn;
    @Column(name="DPA_STATUS_DESC_TH", length = 200)
    private String dpaStatusDescTh;
    @Column(name="IPADDRESS", length = 50)
    private String ipaddress;
    @Id
    @Column(name="REFERENCE_ID", nullable = false, length = 12)
    private String referenceId;
    @Column(name="UPDATED_BY", nullable = false, length = 10)
    private String updatedBy;
    @Column(name="UPDATED_DATE", nullable = false)
    private Timestamp updatedDate;
    @Column(name="REC_STATUS")
    private Integer recStatus;
    
    @Column(name="URL_ID")
    private int urlId;
    @Column(name="URL", length = 100)
    private String url;
    @Column(name="URL_NAME", length = 20)
    private String urlName;
    
    @ManyToOne()
    @JoinColumn(name = "CREATED_BY", referencedColumnName = "USER_ID", insertable = false, updatable = false, nullable = false)
    private SecUserInfo userCreatedInfo;
    
    @ManyToOne()
    @JoinColumn(name = "UPDATED_BY", referencedColumnName = "USER_ID", insertable = false, updatable = false, nullable = false)
    private SecUserInfo userUpdateInfo;
    
    public WebserviceLog()
    {
    }

    public WebserviceLog(String agentId,String companyId, String createdBy,
                         Timestamp createdDate, String ipaddress,
                         String dpaStatusCode, String dpaStatusDescEn,
                         String dpaStatusDescTh, String referenceId,
                         String updatedBy, Timestamp updatedDate,Integer recStatus)
    {
        this.agentId = agentId;
        this.companyId = companyId;
        this.createdBy = createdBy;
        this.createdDate = createdDate;

        this.dpaStatusCode = dpaStatusCode;
        this.dpaStatusDescEn = dpaStatusDescEn;
        this.dpaStatusDescTh = dpaStatusDescTh;
        this.referenceId = referenceId;
        this.updatedBy = updatedBy;
        this.updatedDate = updatedDate;
        this.ipaddress = ipaddress;
        this.recStatus = recStatus;
    }

    public String getCompanyId()
    {
        return companyId;
    }

    public void setCompanyId(String companyId)
    {
        this.companyId = companyId;
    }

    public String getCreatedBy()
    {
        return createdBy;
    }

    public void setCreatedBy(String createdBy)
    {
        this.createdBy = createdBy;
    }

    public Timestamp getCreatedDate()
    {
        return createdDate;
    }

    public void setCreatedDate(Timestamp createdDate)
    {
        this.createdDate = createdDate;
    }

    public String getDataResponse()
    {
        return dataResponse;
    }

    public void setDataResponse(String dataResponse)
    {
        this.dataResponse = dataResponse;
    }

    public String getDpaStatusCode()
    {
        return dpaStatusCode;
    }

    public void setDpaStatusCode(String dpaStatusCode)
    {
        this.dpaStatusCode = dpaStatusCode;
    }

    public String getDpaStatusDescEn()
    {
        return dpaStatusDescEn;
    }

    public void setDpaStatusDescEn(String dpaStatusDescEn)
    {
        this.dpaStatusDescEn = dpaStatusDescEn;
    }

    public String getDpaStatusDescTh()
    {
        return dpaStatusDescTh;
    }

    public void setDpaStatusDescTh(String dpaStatusDescTh)
    {
        this.dpaStatusDescTh = dpaStatusDescTh;
    }

    public String getReferenceId()
    {
        return referenceId;
    }

    public void setReferenceId(String referenceId)
    {
        this.referenceId = referenceId;
    }

    public String getUpdatedBy()
    {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy)
    {
        this.updatedBy = updatedBy;
    }

    public Timestamp getUpdatedDate()
    {
        return updatedDate;
    }

    public void setUpdatedDate(Timestamp updatedDate)
    {
        this.updatedDate = updatedDate;
    }

    public void setAgentId(String agentId)
    {
        this.agentId = agentId;
    }

    public String getAgentId()
    {
        return agentId;
    }

    public void setipaddress(String ipaddress)
    {
        this.ipaddress = ipaddress;
    }

    public String getipaddress()
    {
        return ipaddress;
    }

    public void setRecStatus(Integer recStatus)
    {
        this.recStatus = recStatus;
    }

    public Integer getRecStatus()
    {
        return recStatus;
    }

    public void setUrlId(int urlId)
    {
        this.urlId = urlId;
    }

    public int getUrlId()
    {
        return urlId;
    }

    public void setUrl(String url)
    {
        this.url = url;
    }

    public String getUrl()
    {
        return url;
    }

    public void setUrlName(String urlName)
    {
        this.urlName = urlName;
    }
  
    public String getUrlName()
    {
        return urlName;
    }  
    public String getCreatedDateDisplay()
    {
        String vaRtn = "";
        if (this.createdDate != null)
        {
            vaRtn = DateConvert.convTimestamp2String(this.createdDate);
        }
        return vaRtn;
    }
    public String getUpdatedDateDisplay()
    {
        String vaRtn = "";
        if (this.updatedDate != null)
        {
            vaRtn = DateConvert.convTimestamp2String(this.updatedDate);
        }
        return vaRtn;
    }

    public String getUpdatedByDisplay()
    {
        String vaRtn = this.updatedBy;
        SecUserInfo voUserUpdateInfo = this.userUpdateInfo;
        if (voUserUpdateInfo != null)
        {
            vaRtn = vaRtn + " - " + voUserUpdateInfo.getFirstName() + " " + voUserUpdateInfo.getLastName();
        }
        return vaRtn;
    }
    public String getCreatedByDisplay()
    {
        String vaRtn = this.createdBy;
        SecUserInfo voUserCreatedInfo = this.userCreatedInfo;
        if (voUserCreatedInfo != null)
        {
            vaRtn = vaRtn + " - " + voUserCreatedInfo.getFirstName() + " " + voUserCreatedInfo.getLastName();
        }
        return vaRtn;
    }
  

    public void setUserUpdateInfo(SecUserInfo userUpdateInfo)
    {
        this.userUpdateInfo = userUpdateInfo;
    }

    public SecUserInfo getUserUpdateInfo()
    {
        return userUpdateInfo;
    }

    public void setUserCreatedInfo(SecUserInfo userCreatedInfo)
    {
        this.userCreatedInfo = userCreatedInfo;
    }

    public SecUserInfo getUserCreatedInfo()
    {
        return userCreatedInfo;
    }
    
  public String toString()
  {
    return "{\"companyId\":\"" + this.companyId 
    + "\", \"agentId\":\"" + this.agentId
    + "\", \"createdDate\":\"" + this.createdDate
    + "\", \"createdBy\":\"" + this.createdBy
    + "\", \"updatedDateDisplay\":\"" + getUpdatedDateDisplay()
    + "\", \"createdDateDisplay\":\"" + getCreatedDateDisplay()
    
    +"\"}";
  }
}
