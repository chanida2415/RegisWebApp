package pro.reg.data;

import java.io.InterruptedIOException;
import java.io.Serializable;

import java.sql.Timestamp;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;

import java.util.Locale;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import pro.address.data.AmphurInfo;
import pro.address.data.DistrictInfo;
import pro.address.data.ProvinceInfo;

import pro.util.DateConvert;

@Entity
@NamedQueries({
  @NamedQuery(name = "Cmpinfo.findAll", query = "select o from Cmpinfo o")
})
public class Cmpinfo implements Serializable
{
    @Column(length = 150)
    private String amphur;
    @Column(name="AMPHUR_CODE", length = 20)
    private String amphurCode;
    @Column(length = 150)
    private String build;
    @Column(name="COMPANY_EN", length = 300)
    private String companyEn;
    @Id
    @Column(name="COMPANY_ID", nullable = false, length = 15)
    private String companyId;
    @Column(name="COMPANY_STATUS", length = 100)
    private String companyStatus;
    @Column(name="COMPANY_TH", length = 300)
    private String companyTh;
    @Column(name="COMPANY_TYPE", length = 100)
    private String companyType;
    @Column(name="CREATED_BY", length = 10)
    private String createdBy;
    @Column(name="CREATED_DATE")
    private Timestamp createdDate;
    @Column(length = 150)
    private String district;
    @Column(name="DISTRICT_CODE", length = 20)
    private String districtCode;
    @Column(length = 50)
    private String email;
    @Column(length = 20)
    private String fax;
    @Column(name="HOUSE_NUM", length = 150)
    private String houseNum;
    @Column(length = 50)
    private String ipaddress;
    @Column(length = 50)
    private String moo;
    @Column(length = 100)
    private String mooname;
    @Column(name="NUM_COMMITTEE")
    private Long numCommittee;
    @Column(name="NUM_PAGE_OBJ")
    private Long numPageObj;
    @Column(name="OLDCOMPANY_ID", length = 15)
    private String oldcompanyId;
    @Column(name="PAID_REG_CAPITAL")
    private Double paidRegCapital;
    @Column(length = 20)
    private String phone;
    @Column(length = 150)
    private String province;
    @Column(name="PROVINCE_CODE", length = 20)
    private String provinceCode;
    @Column(name="REG_CAPITAL")
    private Double regCapital;
    @Column(name="REG_DATE")
    private Timestamp regDate;
    @Column(length = 150)
    private String road;
    @Column(length = 150)
    private String soi;
    @Column(name="UPDATED_BY", length = 10)
    private String updatedBy;
    @Column(name="UPDATED_DATE")
    private Timestamp updatedDate;
    @Column(length = 10)
    private String zipcode;
    @Column(name="REC_STATUS")
    private Integer recStatus;

    @ManyToOne()
    @JoinColumn(name = "PROVINCE_CODE", referencedColumnName = "PROVINCE_CODE", insertable = false, updatable = false, nullable = false)
    private ProvinceInfo provinceInfo;

      @ManyToOne()
      @JoinColumns( { @JoinColumn(name = "PROVINCE_CODE", referencedColumnName = "PROVINCE_CODE", insertable = false, updatable = false, nullable = false),
                      @JoinColumn(name = "AMPHUR_CODE", referencedColumnName = "AMPHUR_CODE", insertable = false, updatable = false, nullable = false) })
      private AmphurInfo amphurInfo;
     
      @ManyToOne()
      @JoinColumns( { @JoinColumn(name = "PROVINCE_CODE", referencedColumnName = "PROVINCE_CODE", insertable = false, updatable = false, nullable = false),
                      @JoinColumn(name = "AMPHUR_CODE", referencedColumnName = "AMPHUR_CODE", insertable = false, updatable = false, nullable = false),
                      @JoinColumn(name = "DISTRICT_CODE", referencedColumnName = "DISTRICT_CODE", insertable = false, updatable = false, nullable = false) })
      private DistrictInfo districtInfo;
      
      @ManyToOne()
      @JoinColumn(name = "CREATED_BY", referencedColumnName = "USER_ID", insertable = false, updatable = false, nullable = false)
      private SecUserInfo userCreatedInfo;
      
      @ManyToOne()
      @JoinColumn(name = "UPDATED_BY", referencedColumnName = "USER_ID", insertable = false, updatable = false, nullable = false)
      private SecUserInfo userUpdateInfo;
    public Cmpinfo()
    {
    }

    public Cmpinfo(String amphur, String amphurCode, String build,
                   String companyEn, String companyId,
                   String companyStatus, String companyTh,
                   String companyType, String createdBy,
                   Timestamp createdDate, String district,
                   String districtCode, String email, String fax,
                   String houseNum, String ipaddress, String moo,
                   String mooname, Long numCommittee, Long numPageObj,
                   String oldcompanyId, Double paidRegCapital,
                   String phone, String province, String provinceCode,
                   Double regCapital, Timestamp regDate, String road,
                   String soi, String updatedBy, Timestamp updatedDate,
                   String zipcode,Integer recStatus)
    {
        this.amphur = amphur;
        this.amphurCode = amphurCode;
        this.build = build;
        this.companyEn = companyEn;
        this.companyId = companyId;
        this.companyStatus = companyStatus;
        this.companyTh = companyTh;
        this.companyType = companyType;
        this.createdBy = createdBy;
        this.createdDate = createdDate;
        this.district = district;
        this.districtCode = districtCode;
        this.email = email;
        this.fax = fax;
        this.houseNum = houseNum;
        this.ipaddress = ipaddress;
        this.moo = moo;
        this.mooname = mooname;
        this.numCommittee = numCommittee;
        this.numPageObj = numPageObj;
        this.oldcompanyId = oldcompanyId;
        this.paidRegCapital = paidRegCapital;
        this.phone = phone;
        this.province = province;
        this.provinceCode = provinceCode;
        this.regCapital = regCapital;
        this.regDate = regDate;
        this.road = road;
        this.soi = soi;
        this.updatedBy = updatedBy;
        this.updatedDate = updatedDate;
        this.zipcode = zipcode;
        this.recStatus = recStatus;
    }

    public String getAmphur()
    {
        return amphur;
    }

    public void setAmphur(String amphur)
    {
        this.amphur = amphur;
    }

    public String getAmphurCode()
    {
        return amphurCode;
    }

    public void setAmphurCode(String amphurCode)
    {
        this.amphurCode = amphurCode;
    }

    public String getBuild()
    {
        return build;
    }

    public void setBuild(String build)
    {
        this.build = build;
    }

    public String getCompanyEn()
    {
        return companyEn;
    }

    public void setCompanyEn(String companyEn)
    {
        this.companyEn = companyEn;
    }

    public String getCompanyId()
    {
        return companyId;
    }

    public void setCompanyId(String companyId)
    {
        this.companyId = companyId;
    }

    public String getCompanyStatus()
    {
        return companyStatus;
    }

    public void setCompanyStatus(String companyStatus)
    {
        this.companyStatus = companyStatus;
    }

    public String getCompanyTh()
    {
        return companyTh;
    }

    public void setCompanyTh(String companyTh)
    {
        this.companyTh = companyTh;
    }

    public String getCompanyType()
    {
        return companyType;
    }

    public void setCompanyType(String companyType)
    {
        this.companyType = companyType;
    }

    public String getCreatedBy()
    {
        return createdBy;
    }

    public void setCreatedBy(String createdBy)
    {
        this.createdBy = createdBy;
    }

    public Timestamp getCreatedDate()
    {
        return createdDate;
    }

    public void setCreatedDate(Timestamp createdDate)
    {
        this.createdDate = createdDate;
    }

    public String getDistrict()
    {
        return district;
    }

    public void setDistrict(String district)
    {
        this.district = district;
    }

    public String getDistrictCode()
    {
        return districtCode;
    }

    public void setDistrictCode(String districtCode)
    {
        this.districtCode = districtCode;
    }

    public String getEmail()
    {
        return email;
    }

    public void setEmail(String email)
    {
        this.email = email;
    }

    public String getFax()
    {
        return fax;
    }

    public void setFax(String fax)
    {
        this.fax = fax;
    }

    public String getHouseNum()
    {
        return houseNum;
    }

    public void setHouseNum(String houseNum)
    {
        this.houseNum = houseNum;
    }

    public String getIpaddress()
    {
        return ipaddress;
    }

    public void setIpaddress(String ipaddress)
    {
        this.ipaddress = ipaddress;
    }

    public String getMoo()
    {
        return moo;
    }

    public void setMoo(String moo)
    {
        this.moo = moo;
    }

    public String getMooname()
    {
        return mooname;
    }

    public void setMooname(String mooname)
    {
        this.mooname = mooname;
    }

    public Long getNumCommittee()
    {
        return numCommittee;
    }

    public void setNumCommittee(Long numCommittee)
    {
        this.numCommittee = numCommittee;
    }

    public Long getNumPageObj()
    {
        return numPageObj;
    }

    public void setNumPageObj(Long numPageObj)
    {
        this.numPageObj = numPageObj;
    }

    public String getOldcompanyId()
    {
        return oldcompanyId;
    }

    public void setOldcompanyId(String oldcompanyId)
    {
        this.oldcompanyId = oldcompanyId;
    }

    public Double getPaidRegCapital()
    {
        return paidRegCapital;
    }

    public void setPaidRegCapital(Double paidRegCapital)
    {
        this.paidRegCapital = paidRegCapital;
    }

    public String getPhone()
    {
        return phone;
    }

    public void setPhone(String phone)
    {
        this.phone = phone;
    }

    public String getProvince()
    {
        return province;
    }

    public void setProvince(String province)
    {
        this.province = province;
    }

    public String getProvinceCode()
    {
        return provinceCode;
    }

    public void setProvinceCode(String provinceCode)
    {
        this.provinceCode = provinceCode;
    }

    public Double getRegCapital()
    {
        return regCapital;
    }
    public String getRegCapitalDisplay()
    {
        String vaRtn = "";
        if(this.regCapital != null)
        {
         vaRtn = String.format("%.2f",this.regCapital);
        }
        return vaRtn;
    }

    public void setRegCapital(Double regCapital)
    {
        this.regCapital = regCapital;
    }

    public Timestamp getRegDate()
    {
        return regDate;
    }

    public void setRegDate(Timestamp regDate)
    {
        this.regDate = regDate;
    }

    public String getRoad()
    {
        return road;
    }

    public void setRoad(String road)
    {
        this.road = road;
    }

    public String getSoi()
    {
        return soi;
    }

    public void setSoi(String soi)
    {
        this.soi = soi;
    }

    public String getUpdatedBy()
    {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy)
    {
        this.updatedBy = updatedBy;
    }

    public Timestamp getUpdatedDate()
    {
        return updatedDate;
    }

    public void setUpdatedDate(Timestamp updatedDate)
    {
        this.updatedDate = updatedDate;
    }

    public String getZipcode()
    {
        return zipcode;
    }

    public void setZipcode(String zipcode)
    {
        this.zipcode = zipcode;
    }
    public void setRecStatus(Integer recStatus)
    {
        this.recStatus = recStatus;
    }

    public Integer getRecStatus()
    {
        return recStatus;
    }
    public void setProvinceInfo(ProvinceInfo provinceInfo)
    {
        this.provinceInfo = provinceInfo;
    }

    public ProvinceInfo getProvinceInfo()
    {
        return provinceInfo;
    }

    public void setAmphurInfo(AmphurInfo amphurInfo)
    {
        this.amphurInfo = amphurInfo;
    }

    public AmphurInfo getAmphurInfo()
    {
        return amphurInfo;
    }

    public void setDistrictInfo(DistrictInfo districtInfo)
    {
        this.districtInfo = districtInfo;
    }

    public DistrictInfo getDistrictInfo()
    {
        return districtInfo;
    }
    public void setUserInfo(SecUserInfo userCreatedInfo)
        {
            this.userCreatedInfo = userCreatedInfo;
        }

        public SecUserInfo getUserInfo()
        {
            return userCreatedInfo;
        }

        public void setUserUpdateInfo(SecUserInfo userUpdateInfo)
        {
            this.userUpdateInfo = userUpdateInfo;
        }

        public SecUserInfo getUserUpdateInfo()
        {
            return userUpdateInfo;
        }
        public String getUpdatedByDisplay()
        {
            String vaRtn = this.updatedBy;
            SecUserInfo voUserUpdateInfo = this.userUpdateInfo;
            if (voUserUpdateInfo != null)
            {
                vaRtn = vaRtn + " - " + voUserUpdateInfo.getFirstName() + " " + voUserUpdateInfo.getLastName();
            }
            return vaRtn;
        }
        
        public String getUpdatedByName()
        {
            String vaRtn = "";
                    SecUserInfo voUserUpdateInfo = this.userUpdateInfo;
            if (voUserUpdateInfo != null)
            {
                vaRtn = voUserUpdateInfo.getFirstName() + " " + voUserUpdateInfo.getLastName();
            }
            return vaRtn;
        }
        public String getUpdatedDateDisplay()
        {
            String vaRtn = "";
            if (this.updatedDate != null)
            {
                vaRtn = DateConvert.convTimestamp2String(this.updatedDate);
            }
            return vaRtn;
        }

        public String getPhoneDisplay()
        {
            String vaRtn = "";
            if (this.phone != null && this.phone.length() == 10)
            {
                vaRtn = this.phone.substring(0, 3) + "-" + this.phone.substring(3, 6) + "-" + this.phone.substring(6);
            }
            else if (this.phone != null && this.phone.length() != 10)
            {
                vaRtn = this.phone;
            }
            return vaRtn;
        }
        
        public String getCreatedName()
        {
            String vaRtn = "";
            SecUserInfo voUserCreatedInfo = this.userCreatedInfo;
            if (voUserCreatedInfo != null)
            {
                vaRtn = voUserCreatedInfo.getFirstName() + " " + voUserCreatedInfo.getLastName();
            }
            return vaRtn;
        }
        public String getRegDateDisplay()
        {
            String vaRtn = "";
            SimpleDateFormat formatDate = new SimpleDateFormat ("dd/MM/");  //ไปเอามาจาก dataConvert.convTimestamp2String
            SimpleDateFormat formatYear = new SimpleDateFormat ("yyyy",Locale.US);
            System.err.println("623 "+this.regDate);
            if (this.regDate != null)
            {
               vaRtn = formatDate.format(this.regDate);
              System.err.println("vaRtn "+vaRtn);
               vaRtn = vaRtn + (Integer.parseInt(formatYear.format(this.regDate))+543);
              System.err.println("vaRtn "+vaRtn);
            }
            return vaRtn;
        }
        public String getRegTimeDisplay()
        {
          String vaRtn = "";
          SimpleDateFormat formatTime = new SimpleDateFormat (" HH:mm:ss",Locale.US);
          if (this.regDate != null)
          {
             vaRtn = formatTime.format(this.regDate);
            
          }
          return vaRtn;
        }
        public String getCreatedDateDisplay()
        {
            String vaRtn = "";
            if (this.createdDate != null)
            {
                vaRtn = DateConvert.convTimestamp2String(this.createdDate);
            }
            return vaRtn;
        }
        public String getCreatedByDisplay()
        {
            String vaRtn = this.createdBy;
            SecUserInfo voUserCreatedInfo = this.userCreatedInfo;
            if (voUserCreatedInfo != null)
            {
                vaRtn = vaRtn + " - " + voUserCreatedInfo.getFirstName() + " " + voUserCreatedInfo.getLastName();
            }
            return vaRtn;
        }
      public String toString()
      {
        return "{\"companyId\":\"" + this.companyId 
        + "\",\"companyType\":\"" +(this.companyType == null? "": this.companyType) 
        +"\",\"companyTh\":\""    +(this.companyTh == null? "": this.companyTh) 
        +"\",\"companyEn\":\"" + (this.companyEn == null? "": this.companyEn)
        + "\",\"regCapital\":\"" + getRegCapitalDisplay()
        +"\",\"regDate\":\""    + getRegDateDisplay()
        + "\", \"houseNum\":\"" + (houseNum == null ? "" : houseNum.replaceAll("'","\\\'").replaceAll("\"","\\\\\"").replaceAll("\r\n", " ")) 
        + "\", \"moo\":\"" + (moo == null ? "" : moo.replaceAll("'","\\\'").replaceAll("\"","\\\\\"").replaceAll("\r\n", " ")) 
        + "\", \"mooname\":\"" + (mooname == null ? "" : mooname.replaceAll("'","\\\'").replaceAll("\"","\\\\\"").replaceAll("\r\n", " "))
        + "\", \"build\":\"" + (build == null ? "" : build.replaceAll("'","\\\'").replaceAll("\"","\\\\\"").replaceAll("\r\n", " "))
        + "\", \"soi\":\"" + (soi == null ? "" : soi.replaceAll("'","\\\'").replaceAll("\"","\\\\\"").replaceAll("\r\n", " "))
        + "\", \"road\":\"" + (road == null ? "" : road.replaceAll("'","\\\'").replaceAll("\"","\\\\\"").replaceAll("\r\n", " "))
        + "\", \"districtCode\":\"" + (districtCode == null ? "" : districtCode)
        + "\", \"districtName\":\"" + (districtInfo == null ? "" : districtInfo.getDistrictName().replaceAll("'","\\\'").replaceAll("\"","\\\\\"").replaceAll("\r\n", " "))
        + "\", \"amphurCode\":\"" + (amphurCode == null ? "" : amphurCode)
        + "\", \"amphurName\":\"" + (amphurInfo == null ? "" : amphurInfo.getAmphurName().replaceAll("'","\\\'").replaceAll("\"","\\\\\"").replaceAll("\r\n", " "))
        + "\", \"provinceCode\":\"" + (provinceCode == null ? "" : provinceCode)
        + "\", \"provinceName\":\"" + (provinceInfo == null ? "" : provinceInfo.getProvinceName().replaceAll("'","\\\'").replaceAll("\"","\\\\\"").replaceAll("\r\n", " "))
        + "\", \"zipcode\":\"" + (zipcode == null ? "" : zipcode)
        + "\", \"phone\":\"" + (phone == null ? "" : phone)
        + "\", \"phoneNumberDisplay\":\"" + (phone == null ? "" : getPhoneDisplay())
        + "\", \"email\":\"" + (email == null ? "" : email)
        + "\", \"createdByDisplay\":\"" + (getCreatedByDisplay()==null? "" : getCreatedByDisplay().replaceAll("'","\\\'").replaceAll("\"","\\\\\"").replaceAll("\r\n", " "))
        + "\", \"updatedByDisplay\":\"" + getUpdatedByDisplay()
        + "\", \"updatedByName\":\"" + getUpdatedByName()
        + "\", \"updatedDateDisplay\":\"" + getUpdatedDateDisplay()
        + "\", \"createdDateDisplay\":\"" + getCreatedDateDisplay()
        
        +"\"}";
      }


   
}
