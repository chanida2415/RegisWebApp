package pro.reg.data;

import java.io.Serializable;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@NamedQueries({
  @NamedQuery(name = "PrefixName.findAll", query = "select o from PrefixName o")
})
@Table(name = "REF_PREFIX_NAME")
public class PrefixName implements Serializable
{
    @Column(name="CREATED_BY", nullable = false, length = 10)
    private String createdBy;
    @Column(name="CREATED_DATE", nullable = false)
    private Timestamp createdDate;
    @Column(nullable = false, length = 50)
    private String ipaddress;
    @Id
    @Column(name="PREFIX_CODE", nullable = false, length = 3)
    private String prefixCode;
    @Column(name="PREFIX_NAME", nullable = false, length = 30)
    private String prefixName;
    @Column(name="REC_STATUS", nullable = false)
    private Long recStatus;
    @Column(name="UPDATED_BY", nullable = false, length = 10)
    private String updatedBy;
    @Column(name="UPDATED_DATE", nullable = false)
    private Timestamp updatedDate;

    public PrefixName()
    {
    }

    public PrefixName(String createdBy, Timestamp createdDate,
                      String ipaddress, String prefixCode,
                      String prefixName, Long recStatus, String updatedBy,
                      Timestamp updatedDate)
    {
        this.createdBy = createdBy;
        this.createdDate = createdDate;
        this.ipaddress = ipaddress;
        this.prefixCode = prefixCode;
        this.prefixName = prefixName;
        this.recStatus = recStatus;
        this.updatedBy = updatedBy;
        this.updatedDate = updatedDate;
    }

    public String getCreatedBy()
    {
        return createdBy;
    }

    public void setCreatedBy(String createdBy)
    {
        this.createdBy = createdBy;
    }

    public Timestamp getCreatedDate()
    {
        return createdDate;
    }

    public void setCreatedDate(Timestamp createdDate)
    {
        this.createdDate = createdDate;
    }

    public String getIpaddress()
    {
        return ipaddress;
    }

    public void setIpaddress(String ipaddress)
    {
        this.ipaddress = ipaddress;
    }

    public String getPrefixCode()
    {
        return prefixCode;
    }

    public void setPrefixCode(String prefixCode)
    {
        this.prefixCode = prefixCode;
    }

    public String getPrefixName()
    {
        return prefixName;
    }

    public void setPrefixName(String prefixName)
    {
        this.prefixName = prefixName;
    }

    public Long getRecStatus()
    {
        return recStatus;
    }

    public void setRecStatus(Long recStatus)
    {
        this.recStatus = recStatus;
    }

    public String getUpdatedBy()
    {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy)
    {
        this.updatedBy = updatedBy;
    }

    public Timestamp getUpdatedDate()
    {
        return updatedDate;
    }

    public void setUpdatedDate(Timestamp updatedDate)
    {
        this.updatedDate = updatedDate;
    }
    public String toString() 
    {
      return "{\"prefixCode\":\"" + (prefixCode==null?"":prefixCode)
              + "\", \"prefixName\":\"" + (prefixName==null?"":prefixName)
              + "\", \"createdBy\":\"" + (createdBy==null?"":createdBy)
              + "\", \"createdDate\":\"" + (createdDate==null?"":createdDate)
              + "\", \"updatedBy\":\"" + (updatedBy==null?"":updatedBy)
              + "\", \"updatedDate\":\"" + (updatedDate==null?"":updatedDate)
              + "\", \"ipaddress\":\""+ (ipaddress==null?"":ipaddress)  
              + "\", \"recStatus\":\"" + (recStatus==null?1:recStatus)
              + "\"}";
    }       
}
