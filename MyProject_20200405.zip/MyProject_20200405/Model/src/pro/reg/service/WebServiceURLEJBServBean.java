package pro.reg.service;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import pro.reg.data.Webservice;

@Stateless(name = "WebServiceURLEJBServ", mappedName = "WebServiceURLEJBServ")
@TransactionManagement(TransactionManagementType.BEAN)
public class WebServiceURLEJBServBean implements WebServiceURLEJBServ, WebServiceURLEJBServLocal
{
    @PersistenceContext(unitName="reg")
    private EntityManager em;
    public WebServiceURLEJBServBean()
    {
    }
    public Webservice getWebServiceURL(int pnParameterId) throws Exception
    {
             return em.find(Webservice.class, pnParameterId);
    }
}
