package pro.reg.service;

import java.util.List;

import javax.ejb.Local;

import pro.reg.data.PrefixName;

@Local
public interface PrefixNameEJBServLocal
{
    List<PrefixName> searchPrefixNameActiveOnly(String paPrefixCode, String paPrefixName, String paSortOrder) throws Exception;
    
    PrefixName getPrefixNameActiveOnly(String paPrefixCode) throws Exception;
}
