package pro.reg.service;

import java.math.BigDecimal;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import pro.reg.data.Cmpinfo;

import pro.util.SearchResult;

public class CompanyDAO
{
    public CompanyDAO()
    {
        super();
    }
    public void insertCompanyInfo(EntityManager em, Cmpinfo poCmpinfo) throws Exception
    {
      try
      {   
        System.out.println(poCmpinfo);
        StringBuffer sqlStmt = new StringBuffer();
        sqlStmt.append(" INSERT INTO CMPINFO ");
        sqlStmt.append(" (COMPANY_ID, COMPANY_TYPE, COMPANY_TH, COMPANY_EN, REG_CAPITAL ");
        sqlStmt.append(" , REG_DATE, HOUSE_NUM, MOO, MOONAME, SOI ");
        sqlStmt.append(" , ROAD, PROVINCE_CODE, PROVINCE, AMPHUR_CODE, AMPHUR ");   
        sqlStmt.append(" , DISTRICT_CODE, DISTRICT, ZIPCODE, EMAIL, PHONE ");
        sqlStmt.append(" , CREATED_BY, CREATED_DATE, UPDATED_BY, UPDATED_DATE,IPADDRESS) ");
          
        sqlStmt.append(" VALUES ( ?, ?, ?, ? , ? ,");   
        sqlStmt.append(" ?, ?, ?, ?, ? , ");
        sqlStmt.append(" ?, ?, ?, ?, ? , ");
        sqlStmt.append(" ?, ?, ?, ?, ? ");
        sqlStmt.append(" ,? ,CURRENT_TIMESTAMP, ? , CURRENT_TIMESTAMP,?) ");
          
      
        int vnCnt = 1;
        Query voQuery = em.createNativeQuery(sqlStmt.toString());
        //COMPANY_ID, COMPANY_TYPE, COMPANY_TH, COMPANY_EN, REG_CAPITAL
        voQuery.setParameter(vnCnt++, poCmpinfo.getCompanyId());
        voQuery.setParameter(vnCnt++, poCmpinfo.getCompanyType());
        voQuery.setParameter(vnCnt++, poCmpinfo.getCompanyTh());
        voQuery.setParameter(vnCnt++, poCmpinfo.getCompanyEn());
        voQuery.setParameter(vnCnt++, poCmpinfo.getRegCapital());

        //REG_DATE, HOUSE_NUM, MOO, MOONAME, SOI 
        voQuery.setParameter(vnCnt++, poCmpinfo.getRegDate());
        voQuery.setParameter(vnCnt++, poCmpinfo.getHouseNum());
        voQuery.setParameter(vnCnt++, poCmpinfo.getMoo());
        voQuery.setParameter(vnCnt++, poCmpinfo.getMooname());
        voQuery.setParameter(vnCnt++, poCmpinfo.getSoi());
          
          //ROAD, PROVINCE_CODE, PROVINCE, AMPHUR_CODE, AMPHUR
        voQuery.setParameter(vnCnt++, poCmpinfo.getRoad());
        voQuery.setParameter(vnCnt++, poCmpinfo.getProvinceCode());
        voQuery.setParameter(vnCnt++, poCmpinfo.getProvince());
        voQuery.setParameter(vnCnt++, poCmpinfo.getAmphurCode());
        voQuery.setParameter(vnCnt++, poCmpinfo.getAmphur());
          
          //DISTRICT_CODE, DISTRICT_CODE, ZIPCODE, EMAIL, PHONE
        voQuery.setParameter(vnCnt++, poCmpinfo.getDistrictCode());
        voQuery.setParameter(vnCnt++, poCmpinfo.getDistrict());
        voQuery.setParameter(vnCnt++, poCmpinfo.getZipcode());
        voQuery.setParameter(vnCnt++, poCmpinfo.getEmail());
        voQuery.setParameter(vnCnt++, poCmpinfo.getPhone());
        voQuery.setParameter(vnCnt++, poCmpinfo.getCreatedBy());
        voQuery.setParameter(vnCnt++, poCmpinfo.getUpdatedBy());
        voQuery.setParameter(vnCnt++, poCmpinfo.getIpaddress());

        voQuery.executeUpdate();
      }
      catch(Exception e)
      {
         throw new Exception(new StringBuffer("CompanyInfoDAO.insertCompanyInfo : ").append(e.getMessage()).toString());
      }
    }
    
    public SearchResult<Cmpinfo> searchCompany(EntityManager em, String paCompanyId, String paCompanyType, 
                                                 String paCompanyTh, String paRegCapital, int paRegDate,String paSortOrder, int pnPageNumber,byte pnRowPerPage)throws Exception
    {
        
      //em รับมาจาก bean
      int vnTotalRecord = 0;
      int vnTotalPages = 0;
      int vnStartRow = 0;
      StringBuffer jpqlStmt = null;
      //=================Condition==================
      StringBuffer jpqlCdtStmt = new StringBuffer(); //เอาไว้เก็บเงื่อนไข
      jpqlCdtStmt.append(" FROM Cmpinfo aoCmpinfo ");
      jpqlCdtStmt.append(" WHERE 1 = 1");


      if (paCompanyId != null && paCompanyId.length() > 0)
      {
        jpqlCdtStmt.append(" AND aoCmpinfo.companyId LIKE CONCAT(?1,'%') ");
      }
      if (paCompanyType != null && paCompanyType.length() > 0)
      {
        jpqlCdtStmt.append(" AND aoCmpinfo.companyType LIKE CONCAT(?2, '%') ");
        //Lowerเพื่อให้มันเทียบกันได้เอาช่องว่างออกด้วย
      }
      if (paCompanyTh != null && paCompanyTh.length() > 0)
      {
        jpqlCdtStmt.append(" AND LOWER(aoCmpinfo.companyTh) LIKE CONCAT(CONCAT('%', LOWER(?3)), '%') ");
        //Lowerเพื่อให้มันเทียบกันได้เอาช่องว่างออกด้วย
      }
      if (paRegCapital != null && paRegCapital.length() > 0)
      {
        jpqlCdtStmt.append(" AND LOWER(aoCmpinfo.regCapital) LIKE CONCAT(CONCAT('%', LOWER(?4)), '%') ");
        //Lowerเพื่อให้มันเทียบกันได้เอาช่องว่างออกด้วย
      }
        if(paRegDate > 0)
        {
                jpqlCdtStmt.append(" AND FUNC('TO_NUMBER', FUNC('TO_CHAR', aoCmpinfo.regDate, 'YYYYMMDD'))+5430000 = ?5 ");
        }
      
      


      //=================Count Total==================
      jpqlStmt = new StringBuffer();
      jpqlStmt.append(" SELECT COUNT(aoCmpinfo) ");
      jpqlStmt.append(jpqlCdtStmt); //เอาที่เขียนด้านบนมาต่อ
      Query voQuery = em.createQuery(jpqlStmt.toString());

      if (paCompanyId != null && paCompanyId.length() > 0)
      {
        voQuery.setParameter(1, paCompanyId);
      }
      if (paCompanyType != null && paCompanyType.length() > 0)
      {
        voQuery.setParameter(2, paCompanyType);
      }
      if (paCompanyTh != null && paCompanyTh.length() > 0)
      {
        voQuery.setParameter(3, paCompanyTh);
      }

      if (paRegCapital != null && paRegCapital.length() > 0)
      {
        voQuery.setParameter(4, paRegCapital);
      }
        if(paRegDate > 0)
        {
                voQuery.setParameter(5, paRegDate);
        }
        
        
        vnTotalRecord = ((Long)voQuery.getSingleResult()).intValue();
      //====================Find Data List===========================
      jpqlStmt = new StringBuffer();
      jpqlStmt.append(" SELECT aoCmpinfo "); //select field ทั้งหมด
      jpqlStmt.append(jpqlCdtStmt);
      if (paSortOrder != null && paSortOrder.length() > 0)
      {
        jpqlStmt.append(paSortOrder); //ถ้าส่งค่ามาก็sortให้
      }
      else
      {
        jpqlStmt.append(" ORDER BY aoCmpinfo.companyId"); //ถึงไม่ส่งค่าอะไรก็ sortให้
      }

         voQuery = em.createQuery(jpqlStmt.toString());
          if (paCompanyId != null && paCompanyId.length() > 0)
          {
            voQuery.setParameter(1, paCompanyId);
          }
          if (paCompanyType != null && paCompanyType.length() > 0)
          {
            voQuery.setParameter(2, paCompanyType);
          }
          if (paCompanyTh != null && paCompanyTh.length() > 0)
          {
            voQuery.setParameter(3, paCompanyTh);
          }

          if (paRegCapital != null && paRegCapital.length() > 0)
          {
            voQuery.setParameter(4, paRegCapital);
          }
        if(paRegDate > 0)
        {
                voQuery.setParameter(5, paRegDate);
        }

        vnStartRow = (pnPageNumber - 1) * pnRowPerPage;
        vnTotalPages = ((Double)Math.ceil((double)vnTotalRecord / pnRowPerPage)).intValue();

        List<Cmpinfo> voTmpList = voQuery.setFirstResult(vnStartRow).setMaxResults(pnRowPerPage == -1 ? vnTotalRecord : pnRowPerPage).getResultList();
      System.err.println("DAO "+voTmpList);
        //=============Set Search Result=============
        SearchResult<Cmpinfo> voSearchResult = new SearchResult<Cmpinfo>();
        voSearchResult.setResultList(voTmpList);
        voSearchResult.setCurrentPage(pnPageNumber);
        voSearchResult.setTotalPages(vnTotalPages);
        voSearchResult.setTotalRecords(vnTotalRecord);
      System.out.println(voSearchResult);
        return voSearchResult;
    }

    public void updateCompanyInfo(EntityManager em, Cmpinfo poCmpinfo) throws Exception
    {
      try
      {
        StringBuffer jpqlStmt = new StringBuffer();
          jpqlStmt.append(" UPDATE Cmpinfo aoCmpinfo  ");
          jpqlStmt.append(" SET aoCmpinfo.companyType = ?2 ");
          jpqlStmt.append("    , aoCmpinfo.companyTh = ?3 ");
          jpqlStmt.append("    , aoCmpinfo.companyEn = ?4 ");
          jpqlStmt.append("    , aoCmpinfo.regCapital = ?5 ");
          jpqlStmt.append("    , aoCmpinfo.regDate = ?6 ");
          jpqlStmt.append("    , aoCmpinfo.houseNum  = ?7 ");
          jpqlStmt.append("    , aoCmpinfo.moo = ?8 ");
          jpqlStmt.append("    , aoCmpinfo.mooname = ?9 ");
          jpqlStmt.append("    , aoCmpinfo.soi = ?10 ");
          jpqlStmt.append("    , aoCmpinfo.road = ?11 ");
          jpqlStmt.append("    , aoCmpinfo.province  = ?12 ");
          jpqlStmt.append("    , aoCmpinfo.provinceCode  = ?13 ");
          jpqlStmt.append("    , aoCmpinfo.amphur  = ?14 ");
          jpqlStmt.append("    , aoCmpinfo.amphurCode  = ?15 ");
          
          jpqlStmt.append("    , aoCmpinfo.district = ?16 ");
          jpqlStmt.append("    , aoCmpinfo.districtCode = ?17 ");
          jpqlStmt.append("    , aoCmpinfo.zipcode  = ?18 ");
          jpqlStmt.append("    , aoCmpinfo.email   = ?19 ");
          jpqlStmt.append("    , aoCmpinfo.phone  = ?20 ");
        jpqlStmt.append("    , aoCmpinfo.createdBy   = ?21 ");
        jpqlStmt.append("    , aoCmpinfo.createdDate  = ?22 ");
        jpqlStmt.append("    , aoCmpinfo.updatedBy   = ?23 ");
        jpqlStmt.append("    , aoCmpinfo.updatedDate  = ?24 ");
          jpqlStmt.append("    , aoCmpinfo.ipaddress  = ?25 ");
            jpqlStmt.append(" WHERE aoCmpinfo.companyId = ?1 ");
        
        Query voQuery = em.createQuery(jpqlStmt.toString());
        
          //EMPLOYEE_ID, COMPANY_TYPE, LAST_NAME, EMAIL, PHONE_NUMBER 
          voQuery.setParameter(1, poCmpinfo.getCompanyId());
          voQuery.setParameter(2, poCmpinfo.getCompanyType());
          voQuery.setParameter(3, poCmpinfo.getCompanyTh());
          voQuery.setParameter(4, poCmpinfo.getCompanyEn());
          voQuery.setParameter(5, poCmpinfo.getRegCapital());

          //HIRE_DATE, JOB_ID, SALARY, COMMISSION_PCT, MANAGER_ID, DEPARTMENT_ID
          voQuery.setParameter(6, poCmpinfo.getRegDate());
          voQuery.setParameter(7, poCmpinfo.getHouseNum());
          voQuery.setParameter(8, poCmpinfo.getMoo());
          voQuery.setParameter(9, poCmpinfo.getMooname());
            voQuery.setParameter(10, poCmpinfo.getSoi());
        
            voQuery.setParameter(11, poCmpinfo.getRoad());
            voQuery.setParameter(12, poCmpinfo.getProvince());
            voQuery.setParameter(13, poCmpinfo.getProvinceCode());
            voQuery.setParameter(14, poCmpinfo.getAmphur());
            voQuery.setParameter(15, poCmpinfo.getAmphurCode());
        
            voQuery.setParameter(16, poCmpinfo.getDistrict());
            voQuery.setParameter(17, poCmpinfo.getDistrictCode());
            voQuery.setParameter(18, poCmpinfo.getZipcode());
            voQuery.setParameter(19, poCmpinfo.getEmail());
            voQuery.setParameter(20, poCmpinfo.getPhone());
        
            voQuery.setParameter(21, poCmpinfo.getCreatedBy());
            voQuery.setParameter(22, poCmpinfo.getCreatedDate());
            voQuery.setParameter(23, poCmpinfo.getUpdatedBy());
            voQuery.setParameter(24, poCmpinfo.getUpdatedDate());
           voQuery.setParameter(25, poCmpinfo.getIpaddress());
          
        voQuery.executeUpdate();
      }
      catch (Exception e)
      {
        throw new Exception(new StringBuffer("CompanyDAO.updateCompany : ").append(e.getMessage()).toString());
      }
    }
    
    public int deleteCompany(EntityManager em, Cmpinfo voCompany) throws Exception
    {
        StringBuffer jpqlStmt = new StringBuffer();
        jpqlStmt.append(" DELETE FROM Cmpinfo o ");
        jpqlStmt.append(" WHERE o.companyId = ?1 ");
       
        Query voQuery = em.createQuery(jpqlStmt.toString());
        voQuery.setParameter(1, voCompany.getCompanyId());
        int a = voQuery.executeUpdate();
        return a;
    }
    public boolean validateCompanyForUpdate(EntityManager em,String paCompanyID) throws Exception
    {
      try
      {
          System.err.println("paCompanyID "+paCompanyID);
        StringBuffer jpqlStmt = new StringBuffer();
        jpqlStmt.append(" SELECT  COMPANY_ID");
        jpqlStmt.append(" FROM CMPINFO");
        jpqlStmt.append(" WHERE COMPANY_ID = ?2  ");
        
        Query voQuery = em.createNativeQuery(jpqlStmt.toString());
       
          voQuery.setParameter(2,paCompanyID);

        boolean vbResult = false;
        if(voQuery.getResultList() != null && voQuery.getResultList().size() > 0)
        {
          vbResult = true;
        }
          System.err.println("vbResult "+vbResult);
        return vbResult;
      }
      catch (Exception e)
      {
        throw new Exception(new StringBuffer("CompanyInfoDAO.validateCompanyForUpdate : ").append(e.getMessage()).toString());
      }
    }
    public boolean validateCompanyForInsert(EntityManager em, String paCompanyID) throws Exception
    {
      try
      {
          System.err.println("68 indao vainsert");
        StringBuffer jpqlStmt = new StringBuffer();
        jpqlStmt.append(" SELECT  COMPANY_ID");
        jpqlStmt.append(" FROM CMPINFO");
        jpqlStmt.append(" WHERE COMPANY_ID = ?1 ");

        Query voQuery = em.createNativeQuery(jpqlStmt.toString());
        voQuery.setParameter(1,paCompanyID);
        
        boolean vbResult = false;
        if(voQuery.getResultList() != null && voQuery.getResultList().size() > 0)
        {
          vbResult = true;  //have info
        }
        return vbResult;
      }
      catch (Exception e)
      {
        throw new Exception(new StringBuffer("CompanyInfoDAO.validateCompanyForInsert : ").append(e.getMessage()).toString());
      }
    }
}
