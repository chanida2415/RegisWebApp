package pro.reg.service;

import javax.ejb.Local;

import pro.reg.data.EmployeeInfo;

import pro.util.SearchResult;

import reg.exception.ApplicationException;

@Local
public interface EmployeeEJBServLocal
{
    public EmployeeInfo getEmployee(String paCitizenId) throws Exception;
    SearchResult<EmployeeInfo> searchEmployee(String paCompanyId, String paFristname,String paLastname, String paCitizenId, String paSortOrder, int pnPageNumber,byte pnRowPerPage) throws Exception;
    void insertEmployeeInfo(EmployeeInfo poEmployeeInfo) throws ApplicationException, Exception;
    void updateEmployees(EmployeeInfo poEmployeeInfo) throws Exception;
    void deleteEmployee(EmployeeInfo poEmployeeInfo) throws Exception ;
}
