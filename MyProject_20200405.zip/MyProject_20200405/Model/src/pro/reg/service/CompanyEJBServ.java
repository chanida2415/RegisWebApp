package pro.reg.service;

import javax.ejb.Remote;

import pro.reg.data.Cmpinfo;

import pro.util.SearchResult;

import reg.exception.ApplicationException;

@Remote
public interface CompanyEJBServ
{
    void insertCompanyInfo(Cmpinfo poCmpinfo) throws ApplicationException, Exception;

    Cmpinfo getCompany(String paCompanyId) throws Exception;

    SearchResult<Cmpinfo> searchCompany(String paCompanyId,
                                        String paCompanyType,
                                        String paCompanyTh,
                                        String paRegCapital,
                                        int paRegDate,
                                        String paSortOrder,
                                        int pnPageNumber,
                                        byte pnRowPerPage) throws Exception;

    void updateCompanys(Cmpinfo poCmpinfo) throws Exception;
    void deleteCompany(Cmpinfo poCmpinfo) throws Exception ;
}
