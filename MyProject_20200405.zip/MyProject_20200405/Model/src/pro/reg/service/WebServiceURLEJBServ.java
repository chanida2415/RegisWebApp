package pro.reg.service;

import javax.ejb.Remote;

import pro.reg.data.Webservice;

@Remote
public interface WebServiceURLEJBServ
{
    Webservice getWebServiceURL(int pnParameterId) throws Exception;
}
