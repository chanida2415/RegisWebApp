package pro.reg.service;

import javax.ejb.Local;

import pro.reg.data.ShareHoderInfo;

import pro.util.SearchResult;

import reg.exception.ApplicationException;

@Local
public interface ShareHoderEJBServLocal
{
    ShareHoderInfo getShareHoder(String paCitizenId) throws Exception;
    SearchResult<ShareHoderInfo> searchShareHoder(String paCompanyId, String paFristname,String paLastname, String paCitizenId, String paSortOrder, int pnPageNumber,byte pnRowPerPage) throws Exception;
    void insertShareHoderInfo(ShareHoderInfo poShareHoderInfo) throws ApplicationException, Exception;
    void updateShareHoders(ShareHoderInfo poShareHoderInfo) throws Exception;
    void deleteShareHoder(ShareHoderInfo poShareHoderInfo) throws Exception  ;
}
