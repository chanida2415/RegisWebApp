package pro.reg.service;

public class JuristicIMG extends ResponseData implements java.io.Serializable
{
    protected java.lang.String type;
    protected java.lang.String page;
    protected java.lang.String Contents;
    protected java.lang.String ContentsPage;
    protected java.lang.String ContentsType;
    protected java.lang.String total;
    protected java.lang.String size;
    protected java.lang.String data;
    private  byte[] file;
    public JuristicIMG() {
    }
    public void setType(java.lang.String type)
    {
        this.type = type;
    }

    public java.lang.String getType()
    {
        return type;
    }

    public void setPage(java.lang.String page)
    {
        this.page = page;
    }

    public java.lang.String getPage()
    {
        return page;
    }

    public void setContents(java.lang.String Contents)
    {
        this.Contents = Contents;
    }

    public java.lang.String getContents()
    {
        return Contents;
    }

    public void setContentsPage(java.lang.String ContentsPage)
    {
        this.ContentsPage = ContentsPage;
    }

    public java.lang.String getContentsPage()
    {
        return ContentsPage;
    }

    public void setContentsType(java.lang.String ContentsType)
    {
        this.ContentsType = ContentsType;
    }

    public java.lang.String getContentsType()
    {
        return ContentsType;
    }

    public void setTotal(java.lang.String total)
    {
        this.total = total;
    }

    public java.lang.String getTotal()
    {
        return total;
    }

    public void setSize(java.lang.String size)
    {
        this.size = size;
    }

    public java.lang.String getSize()
    {
        return size;
    }

    public void setData(java.lang.String data)
    {
        this.data = data;
    }

    public java.lang.String getData()
    {
        return data;
    }
    public void setOGAPicBase64(byte[] file)
    {
        this.file = file;
    }

    public String getOGAPicBase64()
    {
      
       String s = new sun.misc.BASE64Encoder().encode(this.file);
       return s;
    }
}
