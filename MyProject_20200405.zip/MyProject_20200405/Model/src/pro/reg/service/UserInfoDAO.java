package pro.reg.service;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import pro.reg.data.SecUserInfo;
import pro.reg.data.WebserviceLog;

public class UserInfoDAO
{
  public UserInfoDAO()
  {
    super();
  }
  public void insertUserInfo(EntityManager em, SecUserInfo poSecUserInfo) throws Exception
  {
    try
    { 
      StringBuffer sqlStmt = new StringBuffer();
      sqlStmt.append(" INSERT INTO SEC_USER_INFO ");
      sqlStmt.append(" (USER_ID, AGENT_ID, USER_PASSWORD, FIRST_NAME, LAST_NAME ");
      sqlStmt.append(" , EMAIL, PREFIX_NAME, REGISTERED_DATE, PASSWORD_CHANG_DATE ");
      sqlStmt.append(" , CREATED_BY, CREATED_DATE, UPDATED_BY, UPDATED_DATE,IPADDRESS) ");

      sqlStmt.append(" VALUES ( ?, ?, ?, ?, ? ");
      sqlStmt.append(" , ?, ?, CURRENT_TIMESTAMP , ? ");
      sqlStmt.append(" , ?, CURRENT_TIMESTAMP, ?, CURRENT_TIMESTAMP,?) ");

      Query voQuery = em.createNativeQuery(sqlStmt.toString());

      int vnCnt = 1;
      // REFERENCE_ID, AGENT_ID, CITIZEN_ID, DPA_STATUS_CODE, DPA_STATUS_DESC_TH
      voQuery.setParameter(vnCnt++, poSecUserInfo.getUserId());
      voQuery.setParameter(vnCnt++, poSecUserInfo.getAgentId());
      voQuery.setParameter(vnCnt++, poSecUserInfo.getUserPassword());
      voQuery.setParameter(vnCnt++, poSecUserInfo.getFirstName());
      voQuery.setParameter(vnCnt++, poSecUserInfo.getLastName());
      //DPA_STATUS_DESC_EN, LINK_TYPE
      voQuery.setParameter(vnCnt++, poSecUserInfo.getEmail());
      //DATA_RESPONSE, OFFICE_ID, SERVICE_ID, SERVICE_VERSION
      voQuery.setParameter(vnCnt++, poSecUserInfo.getPrefixName());
      voQuery.setParameter(vnCnt++, poSecUserInfo.getPasswordChangDate());
      //CREATED_BY, CREATED_DATE, UPDATED_BY, UPDATED_DATE, REC_STATUS, IPADDRESS, SCREEN_ID
      voQuery.setParameter(vnCnt++, poSecUserInfo.getCreatedBy());
      voQuery.setParameter(vnCnt++, poSecUserInfo.getUpdatedBy());
        voQuery.setParameter(vnCnt++, poSecUserInfo.getIpaddress());

      voQuery.executeUpdate();
    }
    catch(Exception e)
    {
       throw new Exception(new StringBuffer("UserInfoDAO.insertUserInfo : ").append(e.getMessage()).toString());
    }
  }
  public boolean validateUserInfoForInsert(EntityManager em, String paUserId) throws Exception
  {
    try
    {
        System.err.println("68 indao vainsert");
      StringBuffer jpqlStmt = new StringBuffer();
      jpqlStmt.append(" SELECT  USER_ID");
      jpqlStmt.append(" FROM SEC_USER_INFO");
      jpqlStmt.append(" WHERE USER_ID = ?1 ");

      Query voQuery = em.createNativeQuery(jpqlStmt.toString());
      voQuery.setParameter(1,paUserId);
      
      boolean vbResult = false;
      if(voQuery.getResultList() != null && voQuery.getResultList().size() > 0)
      {
        vbResult = true;  //have info
      }
      return vbResult;
    }
    catch (Exception e)
    {
      throw new Exception(new StringBuffer("UserInfoDAO.validateUserInfoForInsert : ").append(e.getMessage()).toString());
    }
  }
}
