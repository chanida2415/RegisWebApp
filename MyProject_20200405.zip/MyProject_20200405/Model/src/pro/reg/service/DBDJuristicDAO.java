package pro.reg.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import pro.reg.data.Cmpinfo;
import pro.reg.data.WebserviceLog;
import pro.reg.data.WebserviceLog;

import pro.util.DateConvert;
import pro.util.SearchResult;

public class DBDJuristicDAO
{
    public DBDJuristicDAO()
    {
        super();
    }
    public String generateWebserviceLog() throws Exception
    {
        String vaReferenceId = "";
        try
        {
            String vaDateTime = DateConvert.getCurrentDateTime();
            String vaDate = DateConvert.displayDate2StoreDate(vaDateTime.substring(0, 10)); //YYYYMMDD
            String vaTime = vaDateTime.substring(11).replaceAll(":", "");   //HHMMSS
            String vaYear = vaDate.substring(2, 4);   //YY
            vaDate = vaDate.substring(4, 8); //MMDD
            
            vaReferenceId = vaYear + vaDate + vaTime;
            return vaReferenceId;
        }
        catch (Exception e)
        {
            throw new Exception(new StringBuffer("DBDJuristicDAO.generateWebserviceLog : ").append(e.getMessage()).toString());
        }
    }
    
    public boolean validateWebserviceLog(EntityManager em, String paReferenceId) throws Exception
    {
        StringBuffer jpqlStmt = new StringBuffer();
        jpqlStmt.append(" SELECT o ");
        jpqlStmt.append(" FROM WebserviceLog o ");
        jpqlStmt.append(" WHERE o.referenceId = ?1 ");

        Query voQuery = em.createQuery(jpqlStmt.toString());
        voQuery.setParameter(1, paReferenceId);
        boolean vbResult = false;
        if (voQuery != null && voQuery.getResultList() != null && voQuery.getResultList().size() > 0)
        {
            vbResult = true;
        }
        return vbResult;
    }
    public void insertWebserviceLog(EntityManager em, WebserviceLog poWebserviceLog) throws Exception
    {
        StringBuffer sqlStmt = new StringBuffer();
        sqlStmt.append(" INSERT INTO CALL_WEBSERVICE ");
        sqlStmt.append(" (REFERENCE_ID, AGENT_ID, COMPANY_ID, DPA_STATUS_CODE, DPA_STATUS_DESC_TH ");
        sqlStmt.append(" , DPA_STATUS_DESC_EN ");
        sqlStmt.append(" , DATA_RESPONSE, URL_ID,URL, URL_NAME ");
        sqlStmt.append(" , CREATED_BY, CREATED_DATE, UPDATED_BY, UPDATED_DATE ,IPADDRESS) ");

        sqlStmt.append(" VALUES ( ?, ?, ?, ?, ? ");
        sqlStmt.append(" , ? ");
        sqlStmt.append(" , ? , ? , ? , ? ");
        sqlStmt.append(" , ?, CURRENT_TIMESTAMP, ?, CURRENT_TIMESTAMP,?) ");

        Query voQuery = em.createNativeQuery(sqlStmt.toString());

        int vnCnt = 1;
        // REFERENCE_ID, AGENT_ID, CITIZEN_ID, DPA_STATUS_CODE, DPA_STATUS_DESC_TH
        voQuery.setParameter(vnCnt++, poWebserviceLog.getReferenceId());
        voQuery.setParameter(vnCnt++, poWebserviceLog.getAgentId());
        voQuery.setParameter(vnCnt++, poWebserviceLog.getCompanyId());
        voQuery.setParameter(vnCnt++, poWebserviceLog.getDpaStatusCode());
        voQuery.setParameter(vnCnt++, poWebserviceLog.getDpaStatusDescTh());
        //DPA_STATUS_DESC_EN, LINK_TYPE
        voQuery.setParameter(vnCnt++, poWebserviceLog.getDpaStatusDescEn());
        //DATA_RESPONSE, OFFICE_ID, SERVICE_ID, SERVICE_VERSION
        voQuery.setParameter(vnCnt++, poWebserviceLog.getDataResponse());
        voQuery.setParameter(vnCnt++, poWebserviceLog.getUrlId());
        voQuery.setParameter(vnCnt++, poWebserviceLog.getUrl());
        voQuery.setParameter(vnCnt++, poWebserviceLog.getUrlName());

        //CREATED_BY, CREATED_DATE, UPDATED_BY, UPDATED_DATE, REC_STATUS, IPADDRESS, SCREEN_ID
        voQuery.setParameter(vnCnt++, poWebserviceLog.getCreatedBy());
        voQuery.setParameter(vnCnt++, poWebserviceLog.getUpdatedBy());
        voQuery.setParameter(vnCnt++, poWebserviceLog.getipaddress());

        voQuery.executeUpdate();
    }
    public SearchResult<WebserviceLog> searchCallWebService(EntityManager em, String paCompanyId, String paAgentId
                                                ,String paSortOrder, int pnPageNumber,byte pnRowPerPage)throws Exception
    {
        System.err.println("in DAO callwebservice");
      //em รับมาจาก bean
      int vnTotalRecord = 0;
      int vnTotalPages = 0;
      int vnStartRow = 0;
      StringBuffer jpqlStmt = null;
      //=================Condition==================
      StringBuffer jpqlCdtStmt = new StringBuffer(); //เอาไว้เก็บเงื่อนไข
      jpqlCdtStmt.append(" FROM WebserviceLog aoWebserviceLog ");
      jpqlCdtStmt.append(" WHERE 1 = 1");


      if (paCompanyId != null && paCompanyId.length() > 0)
      {
        jpqlCdtStmt.append(" AND aoWebserviceLog.companyId LIKE CONCAT(?1,'%') ");
      }
      if (paAgentId != null && paAgentId.length() > 0)
      {
        jpqlCdtStmt.append(" AND LOWER(aoWebserviceLog.agentId) LIKE CONCAT(CONCAT('%', LOWER(?2)), '%') ");
        //Lowerเพื่อให้มันเทียบกันได้เอาช่องว่างออกด้วย
      }
      
        
      


      //=================Count Total==================
      jpqlStmt = new StringBuffer();
      jpqlStmt.append(" SELECT COUNT(aoWebserviceLog) ");
      jpqlStmt.append(jpqlCdtStmt); //เอาที่เขียนด้านบนมาต่อ
      Query voQuery = em.createQuery(jpqlStmt.toString());

        if (paCompanyId != null && paCompanyId.length() > 0)
        {
            voQuery.setParameter(1, paCompanyId);
        }
        if (paAgentId != null && paAgentId.length() > 0)
        {
            voQuery.setParameter(2, paAgentId);
        }
        
       
        
        
        vnTotalRecord = ((Long)voQuery.getSingleResult()).intValue();
      //====================Find Data List===========================
      jpqlStmt = new StringBuffer();
      jpqlStmt.append(" SELECT aoWebserviceLog "); //select field ทั้งหมด
      jpqlStmt.append(jpqlCdtStmt);
      if (paSortOrder != null && paSortOrder.length() > 0)
      {
        jpqlStmt.append(paSortOrder); //ถ้าส่งค่ามาก็sortให้
      }
      else
      {
        jpqlStmt.append(" ORDER BY aoWebserviceLog.companyId"); //ถึงไม่ส่งค่าอะไรก็ sortให้
      }

         voQuery = em.createQuery(jpqlStmt.toString());
              if (paCompanyId != null && paCompanyId.length() > 0)
              {
                  voQuery.setParameter(1, paCompanyId);
              }
              if (paAgentId != null && paAgentId.length() > 0)
              {
                  voQuery.setParameter(2, paAgentId);
              }
    

        vnStartRow = (pnPageNumber - 1) * pnRowPerPage;
        vnTotalPages = ((Double)Math.ceil((double)vnTotalRecord / pnRowPerPage)).intValue();

        List<WebserviceLog> voTmpList = voQuery.setFirstResult(vnStartRow).setMaxResults(pnRowPerPage == -1 ? vnTotalRecord : pnRowPerPage).getResultList();
      System.err.println("DAO "+voTmpList);
        //=============Set Search Result=============
      SearchResult<WebserviceLog> voSearchResult = new SearchResult<WebserviceLog>();
      voSearchResult.setResultList(voTmpList);
      voSearchResult.setCurrentPage(pnPageNumber);
      voSearchResult.setTotalPages(vnTotalPages);
      voSearchResult.setTotalRecords(vnTotalRecord);
        System.out.println(voSearchResult);
        return voSearchResult;
    }
}
