package pro.reg.service;

public class UserContext implements  java.io.Serializable
{
    private String userId ;
    private String firstName ;
    private String lastName ;
    private String agentId;
    private String ipaddress;
    public UserContext()
    {
        super();
    }
    public String getUserName ()   
    {
      String usrNme ;
      usrNme = firstName + "  " + lastName ;  
      return usrNme ;
    }
    public void setUserId(String userId)
    {
        this.userId = userId;
    }

    public String getUserId()
    {
        return userId;
    }

    public void setFirstName(String firstName)
    {
        this.firstName = firstName;
    }

    public String getFirstName()
    {
        return firstName;
    }

    public void setLastName(String lastName)
    {
        this.lastName = lastName;
    }

    public String getLastName()
    {
        return lastName;
    }

    public void setAgentId(String agentId)
    {
        this.agentId = agentId;
    }

    public String getAgentId()
    {
        return agentId;
    }

    public void setIpaddress(String ipaddress)
    {
        this.ipaddress = ipaddress;
    }

    public String getIpaddress()
    {
        return ipaddress;
    }
}
