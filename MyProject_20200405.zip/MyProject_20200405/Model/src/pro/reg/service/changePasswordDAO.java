package pro.reg.service;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import pro.reg.data.SecChangePassword;
import pro.reg.data.SecUserInfo;

public class changePasswordDAO
{
  public changePasswordDAO()
  {
    super();
  }
  public int generateSeq(EntityManager em) throws Exception
  {
          try
          {
                  int vnChangeSeq = 1;

                  StringBuffer jpqlStmt = new StringBuffer();
                  jpqlStmt.append(" SELECT COALESCE(MAX(aoSecChangePassword.changeSeq),0)+1 ");
                  jpqlStmt.append(" FROM SecChangePassword aoSecChangePassword ");

                  Query voQuery = em.createQuery(jpqlStmt.toString());
                  if (voQuery != null && voQuery.getResultList() != null)
                  {
                          vnChangeSeq = Integer.parseInt(voQuery.getSingleResult().toString());
                  }

                  return vnChangeSeq;
          }
          catch (Exception e)
          {
                  throw new Exception(new StringBuffer("changePasswordDAO.generateSeq : ").append(e.getMessage()).toString());
          }
  }
  public void insertChangePassword(EntityManager em, SecChangePassword poSecChangePassword) throws Exception
  {
    try
    { 
      StringBuffer sqlStmt = new StringBuffer();
      sqlStmt.append(" INSERT INTO SEC_CHANGE_PASSWORD ");
      sqlStmt.append(" (USER_ID, CHANGE_SEQ, NEW_PASSWORD, OLD_PASSWORD ");
   
      sqlStmt.append(" , CREATED_BY, CREATED_DATE, UPDATED_BY, UPDATED_DATE,IPADDRESS) ");

      sqlStmt.append(" VALUES ( ?, ?, ?, ? ");
      sqlStmt.append(" , ?, CURRENT_TIMESTAMP, ?, CURRENT_TIMESTAMP,?) ");

      Query voQuery = em.createNativeQuery(sqlStmt.toString());
      int vnChangSeq = generateSeq(em);
      int vnCnt = 1;
      // REFERENCE_ID, AGENT_ID, CITIZEN_ID, DPA_STATUS_CODE, DPA_STATUS_DESC_TH
      voQuery.setParameter(vnCnt++, poSecChangePassword.getUserId());
      voQuery.setParameter(vnCnt++, vnChangSeq);
      voQuery.setParameter(vnCnt++, poSecChangePassword.getNewPassword());
      voQuery.setParameter(vnCnt++, poSecChangePassword.getOldPassword());

      //CREATED_BY, CREATED_DATE, UPDATED_BY, UPDATED_DATE, REC_STATUS, IPADDRESS, SCREEN_ID
      voQuery.setParameter(vnCnt++, poSecChangePassword.getCreatedBy());
      voQuery.setParameter(vnCnt++, poSecChangePassword.getUpdatedBy());
        voQuery.setParameter(vnCnt++, poSecChangePassword.getIpaddress());

      voQuery.executeUpdate();
    }
    catch(Exception e)
    {
       throw new Exception(new StringBuffer("changePasswordDAO.insertChangePassword : ").append(e.getMessage()).toString());
    }
  }
  
  public void updatePassword(EntityManager em, SecChangePassword poSecChangePassword) throws Exception
  {
    System.err.println("inupdate");
     try
     {
        StringBuffer jpqlStmt = new StringBuffer();
        jpqlStmt.append(" UPDATE SecUserInfo aoSecUserInfo ");
        jpqlStmt.append(" SET aoSecUserInfo.userPassword = ?2 ");

        jpqlStmt.append("    , aoSecUserInfo.passwordChangDate = CURRENT_TIMESTAMP ");
       
        jpqlStmt.append(" WHERE aoSecUserInfo.userId = ?1 ");

        Query voQuery = em.createQuery(jpqlStmt.toString());

        voQuery.setParameter(1, poSecChangePassword.getUserId());
        voQuery.setParameter(2, poSecChangePassword.getNewPassword());
        voQuery.executeUpdate();
     }
     catch (Exception e)
     {
        throw new Exception(new StringBuffer("changePasswordDAO.updatePassword : ").append(e.getMessage()).toString());
     }
  }
  
  public boolean validateUserInfoForInsert(EntityManager em, String paUserId,String paUserPassword )throws Exception
  {
    try
    {
        System.err.println("68 indao vainsert");
      StringBuffer jpqlStmt = new StringBuffer();
      jpqlStmt.append(" SELECT  USER_ID");
      jpqlStmt.append(" FROM SEC_USER_INFO");
      jpqlStmt.append(" WHERE USER_ID = ?1 ");
      jpqlStmt.append(" AND USER_PASSWORD = ?2 ");

      Query voQuery = em.createNativeQuery(jpqlStmt.toString());
      System.err.println(paUserId);
      System.err.println(paUserPassword);
      voQuery.setParameter(1,paUserId);
      voQuery.setParameter(2,paUserPassword);
      
      boolean vbResult = false;
      if(voQuery.getResultList() != null && voQuery.getResultList().size() > 0)
      {
        vbResult = true;  //have info
      }
      return vbResult;
    }
    catch (Exception e)
    {
      throw new Exception(new StringBuffer("changePasswordDAO.validateUserInfoForInsert : ").append(e.getMessage()).toString());
    }
  }
}
