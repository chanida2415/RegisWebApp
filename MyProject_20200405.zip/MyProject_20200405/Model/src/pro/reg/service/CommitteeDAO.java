package pro.reg.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import pro.reg.data.Cmpinfo;
import pro.reg.data.CommiteeInfo;
import pro.reg.data.CommiteeInfo;
import pro.reg.data.CommiteeInfo;

import pro.util.SearchResult;

public class CommitteeDAO
{
    public CommitteeDAO()
    {
        super();
    }
  public void insertCommitteeDAOInfo(EntityManager em, CommiteeInfo poCommiteeInfo) throws Exception
      {
        try
        {   System.err.println("14 indao insert");
          
          StringBuffer sqlStmt = new StringBuffer();
          sqlStmt.append(" INSERT INTO COMMITEE_INFO ");
          sqlStmt.append(" ( FRISTNAME,  LASTNAME, CITIZEN_ID, COMPANY_ID,PREFIX_CODE ");
          sqlStmt.append(" , START_DATE, END_DATE, HOUSE_NUM,  BUILD,   MOO ");
          sqlStmt.append(" , MOONAME,    SOI,      ROAD,       PROVINCE,   AMPHUR ");   
          sqlStmt.append(" , DISTRICT,   ZIPCODE,  EMAIL,      PHONE ");
          sqlStmt.append(" , PROVINCE_CODE,   AMPHUR_CODE,  DISTRICT_CODE ");
          sqlStmt.append(" , CREATED_BY, CREATED_DATE, UPDATED_BY, UPDATED_DATE, IPADDRESS) ");
            
          sqlStmt.append(" VALUES ( ?, ?, ?, ? ,? ,");   
          sqlStmt.append(" ?, ?, ?, ?, ? , ");
          sqlStmt.append(" ?, ?, ?, ?, ? , ");
          sqlStmt.append(" ?, ?, ?, ? ,");
          sqlStmt.append(" ?, ?, ? ");
          sqlStmt.append(" ,? ,'', ? , '',?) ");
            
          System.err.println("42 indao insert");
          int vnCnt = 1;
          Query voQuery = em.createNativeQuery(sqlStmt.toString());
          //COMPANY_ID, COMPANY_TYPE, COMPANY_TH, COMPANY_EN, REG_CAPITAL
          voQuery.setParameter(vnCnt++, poCommiteeInfo.getFristname());
          voQuery.setParameter(vnCnt++, poCommiteeInfo.getLastname());
          voQuery.setParameter(vnCnt++, poCommiteeInfo.getCitizenId());
          voQuery.setParameter(vnCnt++, poCommiteeInfo.getCompanyId());
          voQuery.setParameter(vnCnt++, poCommiteeInfo.getPrefixCode());
      

          //REG_DATE, HOUSE_NUM, MOO, MOONAME, SOI 
          voQuery.setParameter(vnCnt++, poCommiteeInfo.getStartDate());
          voQuery.setParameter(vnCnt++, poCommiteeInfo.getEndDate());
          voQuery.setParameter(vnCnt++, poCommiteeInfo.getHouseNum());
          voQuery.setParameter(vnCnt++, poCommiteeInfo.getBuild());
          voQuery.setParameter(vnCnt++, poCommiteeInfo.getMoo());
         
            //ROAD, PROVINCE_CODE, PROVINCE, AMPHUR_CODE, AMPHUR
          voQuery.setParameter(vnCnt++, poCommiteeInfo.getMooname());
          voQuery.setParameter(vnCnt++, poCommiteeInfo.getSoi());
          voQuery.setParameter(vnCnt++, poCommiteeInfo.getRoad());
          voQuery.setParameter(vnCnt++, poCommiteeInfo.getProvince());
          voQuery.setParameter(vnCnt++, poCommiteeInfo.getAmphur());
            
            //DISTRICT_CODE, DISTRICT_CODE, ZIPCODE, EMAIL, PHONE
    
          voQuery.setParameter(vnCnt++, poCommiteeInfo.getDistrict());
          voQuery.setParameter(vnCnt++, poCommiteeInfo.getZipcode());
          voQuery.setParameter(vnCnt++, poCommiteeInfo.getEmail());
          voQuery.setParameter(vnCnt++, poCommiteeInfo.getPhone());
          
          voQuery.setParameter(vnCnt++, poCommiteeInfo.getProvinceCode());
          voQuery.setParameter(vnCnt++, poCommiteeInfo.getAmphurCode());
          voQuery.setParameter(vnCnt++, poCommiteeInfo.getDistrictCode());
          
          voQuery.setParameter(vnCnt++, poCommiteeInfo.getCreatedBy());
          voQuery.setParameter(vnCnt++, poCommiteeInfo.getUpdatedBy());
          voQuery.setParameter(vnCnt++, poCommiteeInfo.getIpaddress());
          System.err.println("81 indao insert");
          voQuery.executeUpdate();
          System.err.println("83 indao insert");
        }
        catch(Exception e)
        {
           throw new Exception(new StringBuffer("CommitteeDAO.insertCommitteeInfo : ").append(e.getMessage()).toString());
        }
      }
      
    
    public SearchResult<CommiteeInfo> searchCommitteeDAO(EntityManager em, String paCompanyId, String paFristname, 
                                                 String paLastname, String paCitizenId,String paSortOrder, int pnPageNumber,byte pnRowPerPage)throws Exception
    {
        
      //em รับมาจาก bean
      int vnTotalRecord = 0;
      int vnTotalPages = 0;
      int vnStartRow = 0;
      StringBuffer jpqlStmt = null;
      //=================Condition==================
      StringBuffer jpqlCdtStmt = new StringBuffer(); //เอาไว้เก็บเงื่อนไข
      jpqlCdtStmt.append(" FROM CommiteeInfo aoCommiteeInfo ");
      jpqlCdtStmt.append(" WHERE 1 = 1");


      if (paCompanyId != null && paCompanyId.length() > 0)
      {
        jpqlCdtStmt.append("  AND aoCommiteeInfo.companyId LIKE CONCAT(?1,'%') ");
      }
      if (paFristname != null && paFristname.length() > 0)
      {
        jpqlCdtStmt.append(" AND LOWER(aoCommiteeInfo.fristname) LIKE CONCAT(CONCAT('%', LOWER(?2)), '%') ");
        //Lowerเพื่อให้มันเทียบกันได้เอาช่องว่างออกด้วย
      }
      if (paLastname != null && paLastname.length() > 0)
      {
        jpqlCdtStmt.append(" AND LOWER(aoCommiteeInfo.lastname) LIKE CONCAT(CONCAT('%', LOWER(?3)), '%') ");
        //Lowerเพื่อให้มันเทียบกันได้เอาช่องว่างออกด้วย
      }
      if (paCitizenId != null && paCitizenId.length() > 0)
      {
        jpqlCdtStmt.append(" AND LOWER(aoCommiteeInfo.citizenId) LIKE CONCAT(CONCAT('%', LOWER(?4)), '%') ");
        //Lowerเพื่อให้มันเทียบกันได้เอาช่องว่างออกด้วย
      }
        

      //=================Count Total==================
      jpqlStmt = new StringBuffer();
      jpqlStmt.append(" SELECT COUNT(aoCommiteeInfo) ");
      jpqlStmt.append(jpqlCdtStmt); //เอาที่เขียนด้านบนมาต่อ
      Query voQuery = em.createQuery(jpqlStmt.toString());

      if (paCompanyId != null && paCompanyId.length() > 0)
      {
        voQuery.setParameter(1, paCompanyId);
      }
      if (paFristname != null && paFristname.length() > 0)
      {
        voQuery.setParameter(2, paFristname);
      }
      if (paLastname != null && paLastname.length() > 0)
      {
        voQuery.setParameter(3, paLastname);
      }

      if (paCitizenId != null && paCitizenId.length() > 0)
      {
        voQuery.setParameter(4, paCitizenId);
      }
        
        
        
        vnTotalRecord = ((Long)voQuery.getSingleResult()).intValue();
      //====================Find Data List===========================
      jpqlStmt = new StringBuffer();
      jpqlStmt.append(" SELECT aoCommiteeInfo "); //select field ทั้งหมด
      jpqlStmt.append(jpqlCdtStmt);
      if (paSortOrder != null && paSortOrder.length() > 0)
      {
        jpqlStmt.append(paSortOrder); //ถ้าส่งค่ามาก็sortให้
      }
      else
      {
        jpqlStmt.append(" ORDER BY aoCommiteeInfo.companyId"); //ถึงไม่ส่งค่าอะไรก็ sortให้
      }

         voQuery = em.createQuery(jpqlStmt.toString());
          if (paCompanyId != null && paCompanyId.length() > 0)
          {
            voQuery.setParameter(1, paCompanyId);
          }
          if (paFristname != null && paFristname.length() > 0)
          {
            voQuery.setParameter(2, paFristname);
          }
          if (paLastname != null && paLastname.length() > 0)
          {
            voQuery.setParameter(3, paLastname);
          }

          if (paCitizenId != null && paCitizenId.length() > 0)
          {
            voQuery.setParameter(4, paCitizenId);
          }
       

      vnStartRow = (pnPageNumber - 1) * pnRowPerPage;
      vnTotalPages = ((Double)Math.ceil((double)vnTotalRecord / pnRowPerPage)).intValue();

      List<CommiteeInfo> voTmpList = voQuery.setFirstResult(vnStartRow).setMaxResults(pnRowPerPage == -1 ? vnTotalRecord : pnRowPerPage).getResultList();
      System.err.println("DAO "+voTmpList);
      //=============Set Search Result=============
      SearchResult<CommiteeInfo> voSearchResult = new SearchResult<CommiteeInfo>();
      voSearchResult.setResultList(voTmpList);
      voSearchResult.setCurrentPage(pnPageNumber);
      voSearchResult.setTotalPages(vnTotalPages);
      voSearchResult.setTotalRecords(vnTotalRecord);
      System.out.println(voSearchResult);
      return voSearchResult;
    }
    public void updateCommitteeInfo(EntityManager em, CommiteeInfo poCommiteeInfo) throws Exception
    {
      try
      {
        StringBuffer jpqlStmt = new StringBuffer();
          jpqlStmt.append(" UPDATE CommiteeInfo aoCommiteeInfo  ");
            jpqlStmt.append(" SET aoCommiteeInfo.companyId = ?2 ");
            jpqlStmt.append("    , aoCommiteeInfo.prefixCode = ?3 ");
            jpqlStmt.append("    , aoCommiteeInfo.fristname = ?4 ");
            jpqlStmt.append("    , aoCommiteeInfo.lastname = ?5 ");
//            jpqlStmt.append("    , aoCommiteeInfo.startDate = ?6 ");
//            jpqlStmt.append("    , aoCommiteeInfo.endDate = ?7 ");
            jpqlStmt.append("    , aoCommiteeInfo.houseNum = ?8 ");
            jpqlStmt.append("    , aoCommiteeInfo.build = ?9 ");
            jpqlStmt.append("    , aoCommiteeInfo.soi = ?10 ");
            jpqlStmt.append("    , aoCommiteeInfo.road = ?11 ");
            jpqlStmt.append("    , aoCommiteeInfo.moo = ?12 ");
            jpqlStmt.append("    , aoCommiteeInfo.mooname= ?13");
            jpqlStmt.append("    , aoCommiteeInfo.province = ?14 ");
            jpqlStmt.append("    , aoCommiteeInfo.amphur = ?15 ");
            jpqlStmt.append("    , aoCommiteeInfo.district = ?16 ");
            jpqlStmt.append("    , aoCommiteeInfo.zipcode = ?17 ");
            jpqlStmt.append("    , aoCommiteeInfo.email = ?18 ");
            jpqlStmt.append("    , aoCommiteeInfo.phone = ?19 ");
            jpqlStmt.append("    , aoCommiteeInfo.createdBy = ?20 ");
            jpqlStmt.append("    , aoCommiteeInfo.createdDate = ?21 ");
            jpqlStmt.append("    , aoCommiteeInfo.updatedBy = ?22 ");
            jpqlStmt.append("    , aoCommiteeInfo.updatedDate = ?23 ");
            jpqlStmt.append("    , aoCommiteeInfo.ipaddress = ?24 ");
            jpqlStmt.append("    , aoCommiteeInfo.provinceCode  = ?25 ");
            jpqlStmt.append("    , aoCommiteeInfo.amphurCode  = ?26 ");
            jpqlStmt.append("    , aoCommiteeInfo.districtCode = ?27 ");
            jpqlStmt.append(" WHERE aoCommiteeInfo.citizenId = ?1 ");
        
            Query voQuery = em.createQuery(jpqlStmt.toString());
            
            //EMPLOYEE_ID, COMPANY_TYPE, LAST_NAME, EMAIL, PHONE_NUMBER 
            voQuery.setParameter(1, poCommiteeInfo.getCitizenId());
            voQuery.setParameter(2, poCommiteeInfo.getCompanyId());
            voQuery.setParameter(3, poCommiteeInfo.getPrefixCode());
            voQuery.setParameter(4, poCommiteeInfo.getFristname());
            voQuery.setParameter(5, poCommiteeInfo.getLastname());
            
            //HIRE_DATE, JOB_ID, SALARY, COMMISSION_PCT, MANAGER_ID, DEPARTMENT_ID
//            voQuery.setParameter(6, poCommiteeInfo.getStartDate());
//            voQuery.setParameter(7, poCommiteeInfo.getEndDate());
            voQuery.setParameter(8, poCommiteeInfo.getHouseNum());
            voQuery.setParameter(9, poCommiteeInfo.getBuild());
            voQuery.setParameter(10, poCommiteeInfo.getSoi());
            voQuery.setParameter(11, poCommiteeInfo.getRoad());
            voQuery.setParameter(12, poCommiteeInfo.getMoo());
            voQuery.setParameter(13, poCommiteeInfo.getMooname());
            voQuery.setParameter(14, poCommiteeInfo.getProvince());
            voQuery.setParameter(15, poCommiteeInfo.getAmphur());
            voQuery.setParameter(16, poCommiteeInfo.getDistrict());
            voQuery.setParameter(17, poCommiteeInfo.getZipcode());
            voQuery.setParameter(18, poCommiteeInfo.getEmail());
            voQuery.setParameter(19, poCommiteeInfo.getPhone());
            voQuery.setParameter(20, poCommiteeInfo.getCreatedBy());
            voQuery.setParameter(21, poCommiteeInfo.getCreatedDate());
            voQuery.setParameter(22, poCommiteeInfo.getUpdatedBy());
            voQuery.setParameter(23, poCommiteeInfo.getUpdatedDate());
            voQuery.setParameter(24, poCommiteeInfo.getIpaddress());
            voQuery.setParameter(25, poCommiteeInfo.getProvinceCode());
            voQuery.setParameter(26, poCommiteeInfo.getAmphurCode());
            voQuery.setParameter(27, poCommiteeInfo.getDistrictCode());
          
        voQuery.executeUpdate();
      }
      catch (Exception e)
      {
        throw new Exception(new StringBuffer("CommitteeDAO.updateCommittee : ").append(e.getMessage()).toString());
      }
    }
    public boolean validateCommitteeForUpdate(EntityManager em,String paCitizenId) throws Exception
    {
      try
      {
        
        StringBuffer jpqlStmt = new StringBuffer();
        jpqlStmt.append(" SELECT  CITIZEN_ID");
        jpqlStmt.append(" FROM COMMITEE_INFO");
        jpqlStmt.append(" WHERE CITIZEN_ID = ?2  ");
        
        Query voQuery = em.createNativeQuery(jpqlStmt.toString());
       
          voQuery.setParameter(2,paCitizenId);

        boolean vbResult = false;
        if(voQuery.getResultList() != null && voQuery.getResultList().size() > 0)
        {
          vbResult = true;
        }
          System.err.println("vbResult "+vbResult);
        return vbResult;
      }
      catch (Exception e)
      {
        throw new Exception(new StringBuffer("CommitteeDAO.validateCommitteeForUpdate : ").append(e.getMessage()).toString());
      }
    }
    public boolean validateCommitteeForInsert(EntityManager em, String paCitizenId) throws Exception
    {
      try
      {
          System.err.println("68 indao vainsert");
        StringBuffer jpqlStmt = new StringBuffer();
        jpqlStmt.append(" SELECT  CITIZEN_ID");
        jpqlStmt.append(" FROM COMMITEE_INFO");
        jpqlStmt.append(" WHERE CITIZEN_ID = ?1 ");

        Query voQuery = em.createNativeQuery(jpqlStmt.toString());
        voQuery.setParameter(1,paCitizenId);
        
        boolean vbResult = false;
        if(voQuery.getResultList() != null && voQuery.getResultList().size() > 0)
        {
          vbResult = true;  //have info
        }
        return vbResult;
      }
      catch (Exception e)
      {
        throw new Exception(new StringBuffer("CommitteeDAO.validateCommitteeForInsert : ").append(e.getMessage()).toString());
      }
    }
    public int deleteCommittee(EntityManager em, CommiteeInfo poCommitteeInfo) throws Exception
    {
        StringBuffer jpqlStmt = new StringBuffer();
        jpqlStmt.append(" DELETE FROM CommiteeInfo o ");
        jpqlStmt.append(" WHERE o.citizenId = ?1 ");
       
        Query voQuery = em.createQuery(jpqlStmt.toString());
        voQuery.setParameter(1, poCommitteeInfo.getCitizenId());
       
       int a = voQuery.executeUpdate();
       return a;
    }
}
