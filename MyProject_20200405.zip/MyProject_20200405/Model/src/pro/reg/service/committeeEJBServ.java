package pro.reg.service;

import javax.ejb.Remote;

import pro.reg.data.CommiteeInfo;

import pro.util.SearchResult;

import reg.exception.ApplicationException;

@Remote
public interface committeeEJBServ
{
    public CommiteeInfo getCommittee(String paCitizenId) throws Exception;
    SearchResult<CommiteeInfo> searchCommittee(String paCompanyId, String paFristname,String paLastname, String paCitizenId, String paSortOrder, int pnPageNumber,byte pnRowPerPage) throws Exception;
    void insertCommitteeInfo(CommiteeInfo poCommiteeInfo) throws ApplicationException, Exception;
    void updateCommittees(CommiteeInfo poCommiteeInfo) throws Exception;
    void deleteCommittee(CommiteeInfo poCommitteeInfo) throws Exception ;
}
