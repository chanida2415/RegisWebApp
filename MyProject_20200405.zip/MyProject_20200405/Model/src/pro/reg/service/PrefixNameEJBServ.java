package pro.reg.service;

import java.util.List;

import javax.ejb.Remote;

import pro.reg.data.PrefixName;

@Remote
public interface PrefixNameEJBServ
{
    List<PrefixName> searchPrefixNameActiveOnly(String paPrefixCode, String paPrefixName, String paSortOrder) throws Exception;
    
    PrefixName getPrefixNameActiveOnly(String paPrefixCode) throws Exception;
}
