package pro.reg.service;

public class ResponseData implements java.io.Serializable {
    protected java.lang.String message;
    protected java.lang.String status;
    
    public ResponseData() {
    }
    
    public java.lang.String getMessage() {
        return message;
    }
    
    public void setMessage(java.lang.String message) {
        this.message = message;
    }
    
    public java.lang.String getStatus() {
        return status;
    }
    
    public void setStatus(java.lang.String status) {
        this.status = status;
    }
}
