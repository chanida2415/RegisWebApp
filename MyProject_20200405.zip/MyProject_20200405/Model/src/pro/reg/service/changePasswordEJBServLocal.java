package pro.reg.service;

import javax.ejb.Local;

import pro.reg.data.SecChangePassword;

import reg.exception.ApplicationException;

@Local
public interface changePasswordEJBServLocal
{
 void insertChangePassword(SecChangePassword poSecChangePassword) throws ApplicationException, Exception;
}
