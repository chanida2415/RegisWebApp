package pro.reg.service;

import javax.ejb.Remote;

import pro.reg.data.WebserviceLog;

import pro.util.SearchResult;

import reg.exception.ApplicationException;

@Remote
public interface DBDJuristicEJBServ
{
    String insertWebserviceLog(WebserviceLog poWebserviceLog) throws ApplicationException, Exception;
    String getToken(String paConsumerKey ,String paAgentId) throws ApplicationException, Exception;
     WebserviceLog getJuristic(String vaJuristicID ,String paAgentId,String paUidAmn,String paIpAdr) throws ApplicationException, Exception;
    JuristicFile getJuristicSinged(String paJuristicID,String paAgentId,String paUidAmn,String paIpAdr) throws ApplicationException, Exception ;
    WebserviceLog getShareholder(String vaJuristicID ,String paAgentId,String paUidAmn,String paIpAdr) throws ApplicationException, Exception ;
    JuristicFile getShareholderFile(String paJuristicID,String paAgentId,String paUidAmn,String paIpAdr) throws ApplicationException, Exception ;
    JuristicFile getJuristicSingedFile(String paJuristicID,String paPage,String paAgentId,String paUidAmn,String paIpAdr) throws ApplicationException, Exception;
    JuristicIMG getShareholderFileImg(String paJuristicID,String paPage,String paAgentId,String paUidAmn,String paIpAdr) throws ApplicationException, Exception;
    SearchResult<WebserviceLog> searchCallWebService(String paCompanyId, String paAgentId,String paSortOrder, int pnPageNumber,byte pnRowPerPage) throws Exception;
}
