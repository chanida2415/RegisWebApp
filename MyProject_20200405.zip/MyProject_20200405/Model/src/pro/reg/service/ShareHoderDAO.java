package pro.reg.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import pro.reg.data.Cmpinfo;
import pro.reg.data.ShareHoderInfo;

import pro.util.SearchResult;

public class ShareHoderDAO
{
    public ShareHoderDAO()
    {
        super();
    }
    public void insertShareHoder(EntityManager em, ShareHoderInfo poShareHoderInfo) throws Exception
    {
      try
      {  
        
        StringBuffer sqlStmt = new StringBuffer();
        sqlStmt.append(" INSERT INTO SHARE_HODER");
        sqlStmt.append(" ( CITIZEN_ID ,COMPANY_ID,COMPANY_NAME,SUM_HODER,FIRSTNAME,  LASTNAME , PREFIX_CODE ");
        sqlStmt.append(" , PER_VALUE, CAREER, NATIONALITY,  DESCRIPTION,   TOTAL ");
        sqlStmt.append(" , HOUSE_NUM,  BUILD,   MOO , MOONAME,    SOI");
        sqlStmt.append(" , ROAD,       PROVINCE_CODE, PROVINCE, AMPHUR_CODE, AMPHUR ");   
        sqlStmt.append(" , DISTRICT_CODE, DISTRICT, ZIPCODE, EMAIL, PHONE ");
        sqlStmt.append(" , CREATED_BY, CREATED_DATE, UPDATED_BY, UPDATED_DATE, IPADDRESS, REC_STATUS) ");
          
        sqlStmt.append(" VALUES ( ?, ?, ?, ? , ? , ?, ?,");   
        sqlStmt.append(" ?, ?, ?, ?, ? , ");
        sqlStmt.append(" ?, ?, ?, ?, ? , ");
        sqlStmt.append(" ?, ?, ? ,?, ? , ");
        sqlStmt.append(" ?, ?, ?, ?, ?");
        sqlStmt.append(" ,? ,CURRENT_TIMESTAMP, ? , CURRENT_TIMESTAMP, ? , 1) ");
          
      
        int vnCnt = 1;
        Query voQuery = em.createNativeQuery(sqlStmt.toString());
        //COMPANY_ID, COMPANY_TYPE, COMPANY_TH, COMPANY_EN, REG_CAPITAL
        voQuery.setParameter(vnCnt++, poShareHoderInfo.getCitizenId());
        voQuery.setParameter(vnCnt++, poShareHoderInfo.getCompanyId());
          voQuery.setParameter(vnCnt++, poShareHoderInfo.getCompanyName());
          voQuery.setParameter(vnCnt++, poShareHoderInfo.getSumHoder());
        voQuery.setParameter(vnCnt++, poShareHoderInfo.getFirstname());
        voQuery.setParameter(vnCnt++, poShareHoderInfo.getLastname());
        voQuery.setParameter(vnCnt++, poShareHoderInfo.getPrefixCode());


          voQuery.setParameter(vnCnt++, poShareHoderInfo.getPerValue());
          voQuery.setParameter(vnCnt++, poShareHoderInfo.getCareer());
          voQuery.setParameter(vnCnt++, poShareHoderInfo.getNationality());
          voQuery.setParameter(vnCnt++, poShareHoderInfo.getDescription());
          voQuery.setParameter(vnCnt++, poShareHoderInfo.getTotal());
          
        //REG_DATE, HOUSE_NUM, MOO, MOONAME, SOI 
        
        voQuery.setParameter(vnCnt++, poShareHoderInfo.getHouseNum());
        voQuery.setParameter(vnCnt++, poShareHoderInfo.getBuild());
        voQuery.setParameter(vnCnt++, poShareHoderInfo.getMoo());
        voQuery.setParameter(vnCnt++, poShareHoderInfo.getMooname());
        voQuery.setParameter(vnCnt++, poShareHoderInfo.getSoi());
       
          //ROAD, PROVINCE_CODE, PROVINCE, AMPHUR_CODE, AMPHUR
        voQuery.setParameter(vnCnt++, poShareHoderInfo.getRoad());
        voQuery.setParameter(vnCnt++, poShareHoderInfo.getProvinceCode());
        voQuery.setParameter(vnCnt++, poShareHoderInfo.getProvince());
        voQuery.setParameter(vnCnt++, poShareHoderInfo.getAmphurCode());
        voQuery.setParameter(vnCnt++, poShareHoderInfo.getAmphur());
          
          //DISTRICT_CODE, DISTRICT_CODE, ZIPCODE, EMAIL, PHONE
        voQuery.setParameter(vnCnt++, poShareHoderInfo.getDistrictCode());
        voQuery.setParameter(vnCnt++, poShareHoderInfo.getDistrict());
        voQuery.setParameter(vnCnt++, poShareHoderInfo.getZipcode());
        voQuery.setParameter(vnCnt++, poShareHoderInfo.getEmail());
        voQuery.setParameter(vnCnt++, poShareHoderInfo.getPhone());
          
        voQuery.setParameter(vnCnt++, poShareHoderInfo.getCreatedBy());
        voQuery.setParameter(vnCnt++, poShareHoderInfo.getUpdatedBy());
        voQuery.setParameter(vnCnt++, poShareHoderInfo.getIpaddress());

        voQuery.executeUpdate();
      }
      catch(Exception e)
      {
         throw new Exception(new StringBuffer("ShareHoderDAO.insertShareHoderInfo : ").append(e.getMessage()).toString());
      }
    }
    
    public SearchResult<ShareHoderInfo> searchShareHoder(EntityManager em, String paCompanyId, String paFristname, 
                                                 String paLastname, String paCitizenId,String paSortOrder, int pnPageNumber,byte pnRowPerPage)throws Exception
    {
        
      //em รับมาจาก bean
      int vnTotalRecord = 0;
      int vnTotalPages = 0;
      int vnStartRow = 0;
      StringBuffer jpqlStmt = null;
      //=================Condition==================
      StringBuffer jpqlCdtStmt = new StringBuffer(); //เอาไว้เก็บเงื่อนไข
      jpqlCdtStmt.append(" FROM ShareHoderInfo aoShareHoderInfo ");
      jpqlCdtStmt.append(" WHERE 1 = 1");


      if (paCompanyId != null && paCompanyId.length() > 0)
      {
        jpqlCdtStmt.append(" AND aoShareHoderInfo.companyId LIKE CONCAT(?1,'%') ");
      }
      if (paFristname != null && paFristname.length() > 0)
      {
        jpqlCdtStmt.append(" AND LOWER(aoShareHoderInfo.firstname) LIKE CONCAT(CONCAT('%', LOWER(?2)), '%') ");
        //Lowerเพื่อให้มันเทียบกันได้เอาช่องว่างออกด้วย
      }
      if (paLastname != null && paLastname.length() > 0)
      {
        jpqlCdtStmt.append(" AND LOWER(aoShareHoderInfo.lastname) LIKE CONCAT(CONCAT('%', LOWER(?3)), '%') ");
        //Lowerเพื่อให้มันเทียบกันได้เอาช่องว่างออกด้วย
      }
      if (paCitizenId != null && paCitizenId.length() > 0)
      {
        jpqlCdtStmt.append(" AND LOWER(aoShareHoderInfo.citizenId) LIKE CONCAT(CONCAT('%', LOWER(?4)), '%') ");
        //Lowerเพื่อให้มันเทียบกันได้เอาช่องว่างออกด้วย
      }
        

      //=================Count Total==================
      jpqlStmt = new StringBuffer();
      jpqlStmt.append(" SELECT COUNT(aoShareHoderInfo) ");
      jpqlStmt.append(jpqlCdtStmt); //เอาที่เขียนด้านบนมาต่อ
      Query voQuery = em.createQuery(jpqlStmt.toString());

      if (paCompanyId != null && paCompanyId.length() > 0)
      {
        voQuery.setParameter(1, paCompanyId);
      }
      if (paFristname != null && paFristname.length() > 0)
      {
        voQuery.setParameter(2, paFristname);
      }
      if (paLastname != null && paLastname.length() > 0)
      {
        voQuery.setParameter(3, paLastname);
      }

      if (paCitizenId != null && paCitizenId.length() > 0)
      {
        voQuery.setParameter(4, paCitizenId);
      }
        
        
        
        vnTotalRecord = ((Long)voQuery.getSingleResult()).intValue();
      //====================Find Data List===========================
      jpqlStmt = new StringBuffer();
      jpqlStmt.append(" SELECT aoShareHoderInfo "); //select field ทั้งหมด
      jpqlStmt.append(jpqlCdtStmt);
      if (paSortOrder != null && paSortOrder.length() > 0)
      {
        jpqlStmt.append(paSortOrder); //ถ้าส่งค่ามาก็sortให้
      }
      else
      {
        jpqlStmt.append(" ORDER BY aoShareHoderInfo.companyId"); //ถึงไม่ส่งค่าอะไรก็ sortให้
      }

         voQuery = em.createQuery(jpqlStmt.toString());
          if (paCompanyId != null && paCompanyId.length() > 0)
          {
            voQuery.setParameter(1, paCompanyId);
          }
          if (paFristname != null && paFristname.length() > 0)
          {
            voQuery.setParameter(2, paFristname);
          }
          if (paLastname != null && paLastname.length() > 0)
          {
            voQuery.setParameter(3, paLastname);
          }

          if (paCitizenId != null && paCitizenId.length() > 0)
          {
            voQuery.setParameter(4, paCitizenId);
          }
       

        vnStartRow = (pnPageNumber - 1) * pnRowPerPage;
        vnTotalPages = ((Double)Math.ceil((double)vnTotalRecord / pnRowPerPage)).intValue();

        List<ShareHoderInfo> voTmpList = voQuery.setFirstResult(vnStartRow).setMaxResults(pnRowPerPage == -1 ? vnTotalRecord : pnRowPerPage).getResultList();

        //=============Set Search Result=============
        SearchResult<ShareHoderInfo> voSearchResult = new SearchResult<ShareHoderInfo>();
        voSearchResult.setResultList(voTmpList);
        voSearchResult.setCurrentPage(pnPageNumber);
        voSearchResult.setTotalPages(vnTotalPages);
        voSearchResult.setTotalRecords(vnTotalRecord);
   
        return voSearchResult;
     
    }
    public void updateShareHoder(EntityManager em, ShareHoderInfo poShareHoderInfo) throws Exception
    {
      try
      {
        StringBuffer jpqlStmt = new StringBuffer();
          jpqlStmt.append(" UPDATE ShareHoderInfo aoShareHoderInfo  ");
            jpqlStmt.append(" SET aoShareHoderInfo.companyId = ?2 ");
            jpqlStmt.append("    , aoShareHoderInfo.prefixCode = ?3 ");
            jpqlStmt.append("    , aoShareHoderInfo.firstname = ?4 ");
            jpqlStmt.append("    , aoShareHoderInfo.lastname = ?5 ");
          jpqlStmt.append("    , aoShareHoderInfo.perValue = ?6 ");
          jpqlStmt.append("    , aoShareHoderInfo.career = ?7 ");
          jpqlStmt.append("    , aoShareHoderInfo.nationality = ?8 ");
          jpqlStmt.append("    , aoShareHoderInfo.description = ?9 ");
          jpqlStmt.append("    , aoShareHoderInfo.total = ?10 ");
            jpqlStmt.append("    , aoShareHoderInfo.houseNum = ?11 ");
            jpqlStmt.append("    , aoShareHoderInfo.build = ?12 ");
            jpqlStmt.append("    , aoShareHoderInfo.soi = ?13 ");
            jpqlStmt.append("    , aoShareHoderInfo.road = ?14 ");
            jpqlStmt.append("    , aoShareHoderInfo.moo = ?15 ");
            jpqlStmt.append("    , aoShareHoderInfo.mooname= ?16 ");
          jpqlStmt.append("    , aoShareHoderInfo.province  = ?17 ");
          jpqlStmt.append("    , aoShareHoderInfo.provinceCode  = ?18 ");
          jpqlStmt.append("    , aoShareHoderInfo.amphur  = ?19 ");
          jpqlStmt.append("    , aoShareHoderInfo.amphurCode  = ?20 ");
          
          jpqlStmt.append("    , aoShareHoderInfo.district = ?21 ");
          jpqlStmt.append("    , aoShareHoderInfo.districtCode = ?22 ");
            jpqlStmt.append("    , aoShareHoderInfo.zipcode = ?23 ");
            jpqlStmt.append("    , aoShareHoderInfo.email = ?24 ");
            jpqlStmt.append("    , aoShareHoderInfo.phone = ?25 ");
            jpqlStmt.append("    , aoShareHoderInfo.createdBy = ?26 ");
            jpqlStmt.append("    , aoShareHoderInfo.createdDate = ?27 ");
            jpqlStmt.append("    , aoShareHoderInfo.updatedBy = ?28 ");
            jpqlStmt.append("    , aoShareHoderInfo.updatedDate = ?29 ");
            jpqlStmt.append("    , aoShareHoderInfo.ipaddress = ?30 ");
          jpqlStmt.append("    , aoShareHoderInfo.companyName = ?31 ");
          jpqlStmt.append("    , aoShareHoderInfo.sumHoder = ?32 ");
            jpqlStmt.append(" WHERE aoShareHoderInfo.citizenId = ?1 ");
        
            Query voQuery = em.createQuery(jpqlStmt.toString());
       
            //EMPLOYEE_ID, COMPANY_TYPE, LAST_NAME, EMAIL, PHONE_NUMBER 
            voQuery.setParameter(1, poShareHoderInfo.getCitizenId());
            voQuery.setParameter(2, poShareHoderInfo.getCompanyId());
            voQuery.setParameter(3, poShareHoderInfo.getPrefixCode());
            voQuery.setParameter(4, poShareHoderInfo.getFirstname());
            voQuery.setParameter(5, poShareHoderInfo.getLastname());
            
            voQuery.setParameter(6, poShareHoderInfo.getPerValue());
            voQuery.setParameter(7, poShareHoderInfo.getCareer());
            voQuery.setParameter(8, poShareHoderInfo.getNationality());
            voQuery.setParameter(9, poShareHoderInfo.getDescription());
            voQuery.setParameter(10, poShareHoderInfo.getTotal());
        
    
            //HIRE_DATE, JOB_ID, SALARY, COMMISSION_PCT, MANAGER_ID, DEPARTMENT_ID
            voQuery.setParameter(11, poShareHoderInfo.getHouseNum());
            voQuery.setParameter(12, poShareHoderInfo.getBuild());
            voQuery.setParameter(13, poShareHoderInfo.getSoi());
            voQuery.setParameter(14, poShareHoderInfo.getRoad());
            voQuery.setParameter(15, poShareHoderInfo.getMoo());
            voQuery.setParameter(16, poShareHoderInfo.getMooname());
          voQuery.setParameter(17, poShareHoderInfo.getProvince());
          voQuery.setParameter(18, poShareHoderInfo.getProvinceCode());
          voQuery.setParameter(19, poShareHoderInfo.getAmphur());
          voQuery.setParameter(20, poShareHoderInfo.getAmphurCode());
          
          voQuery.setParameter(21, poShareHoderInfo.getDistrict());
          voQuery.setParameter(22, poShareHoderInfo.getDistrictCode());
          
            voQuery.setParameter(23, poShareHoderInfo.getZipcode());
            voQuery.setParameter(24, poShareHoderInfo.getEmail());
            voQuery.setParameter(25, poShareHoderInfo.getPhone());
            
            voQuery.setParameter(26, poShareHoderInfo.getCreatedBy());
            voQuery.setParameter(27, poShareHoderInfo.getCreatedDate());
            voQuery.setParameter(28, poShareHoderInfo.getUpdatedBy());
            voQuery.setParameter(29, poShareHoderInfo.getUpdatedDate());
            voQuery.setParameter(30, poShareHoderInfo.getIpaddress());
          voQuery.setParameter(31, poShareHoderInfo.getCompanyName());
          voQuery.setParameter(32, poShareHoderInfo.getSumHoder());
          
        voQuery.executeUpdate();
      }
      catch (Exception e)
      {
        throw new Exception(new StringBuffer("ShareHoderDAO.updateShareHoder : ").append(e.getMessage()).toString());
      }
    }
    public boolean validateShareHoderForUpdate(EntityManager em,String paCitizenId) throws Exception
    {
      try
      {
        
        StringBuffer jpqlStmt = new StringBuffer();
        jpqlStmt.append(" SELECT  CITIZEN_ID");
        jpqlStmt.append(" FROM SHARE_HODER");
        jpqlStmt.append(" WHERE CITIZEN_ID = ?2  ");
        
        Query voQuery = em.createNativeQuery(jpqlStmt.toString());
       
          voQuery.setParameter(2,paCitizenId);

        boolean vbResult = false;
        if(voQuery.getResultList() != null && voQuery.getResultList().size() > 0)
        {
          vbResult = true;
        }
          System.err.println("vbResult "+vbResult);
        return vbResult;
      }
      catch (Exception e)
      {
        throw new Exception(new StringBuffer("ShareHoderDAO.validateShareHoderForUpdate : ").append(e.getMessage()).toString());
      }
    }
    public boolean validateShareHoderForInsert(EntityManager em, String paCitizenId) throws Exception
    {
      try
      {
        StringBuffer jpqlStmt = new StringBuffer();
        jpqlStmt.append(" SELECT  CITIZEN_ID");
        jpqlStmt.append(" FROM SHARE_HODER");
        jpqlStmt.append(" WHERE CITIZEN_ID = ?1 ");

        Query voQuery = em.createNativeQuery(jpqlStmt.toString());
        voQuery.setParameter(1,paCitizenId);
        
        boolean vbResult = false;
        if(voQuery.getResultList() != null && voQuery.getResultList().size() > 0)
        {
          vbResult = true;  //have info
        }
        return vbResult;
      }
      catch (Exception e)
      {
        throw new Exception(new StringBuffer("ShareHoderDAO.validateShareHoderForInsert : ").append(e.getMessage()).toString());
      }
    }
    public int deleteShareHoder(EntityManager em, ShareHoderInfo poShareHoderInfo) throws Exception
    {
        StringBuffer jpqlStmt = new StringBuffer();
        jpqlStmt.append(" DELETE FROM ShareHoderInfo o ");
        jpqlStmt.append(" WHERE o.companyId = ?1 ");
       
        Query voQuery = em.createQuery(jpqlStmt.toString());
        voQuery.setParameter(1, poShareHoderInfo.getCompanyId());
        int a = voQuery.executeUpdate();
        return a;
    }
}
