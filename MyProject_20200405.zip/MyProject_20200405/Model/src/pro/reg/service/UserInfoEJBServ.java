package pro.reg.service;

import javax.ejb.Remote;

import pro.reg.data.SecUserInfo;

import reg.exception.ApplicationException;

@Remote
public interface UserInfoEJBServ
{
  void insertUserInfo(SecUserInfo poSecUserInfo) throws ApplicationException, Exception;
}
