package pro.reg.service;

import javax.ejb.Local;

import pro.reg.data.Webservice;

@Local
public interface WebServiceURLEJBServLocal
{
    Webservice getWebServiceURL(int pnParameterId) throws Exception;
}
