package pro.reg.service;

import javax.ejb.Local;

import pro.reg.data.SecUserInfo;

import reg.exception.ApplicationException;

@Local
public interface UserInfoEJBServLocal
{
  void insertUserInfo(SecUserInfo poSecUserInfo) throws ApplicationException, Exception;
}
