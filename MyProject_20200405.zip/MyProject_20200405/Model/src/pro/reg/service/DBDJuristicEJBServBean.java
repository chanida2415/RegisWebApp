package pro.reg.service;


import com.sun.jersey.api.client.Client;

import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;



import javax.annotation.Resource;

import javax.ejb.EJB;
import javax.ejb.EJBContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import javax.ws.rs.core.MediaType;

import org.json.JSONArray;
import org.json.JSONObject;

import org.json.JSONTokener;

import pro.reg.data.Cmpinfo;
import pro.reg.data.Webservice;
import pro.reg.data.WebserviceLog;


import pro.util.SearchResult;

import reg.exception.ApplicationException;

@Stateless(name = "DBDJuristicEJBServ", mappedName = "DBDJuristicEJBServ")
@TransactionManagement(TransactionManagementType.BEAN)
public class DBDJuristicEJBServBean implements DBDJuristicEJBServ, DBDJuristicEJBServLocal
{
    @PersistenceContext(unitName="reg") 
    private EntityManager em;

    @Resource
    private EJBContext context;
    @EJB 
    private  WebServiceURLEJBServLocal voWebServiceURLEJBServLocal;
    public DBDJuristicEJBServBean()
    {
    }
   
    
    public String insertWebserviceLog(WebserviceLog poWebserviceLog) throws ApplicationException, Exception
    {
       String vaReferenceId = "";
       boolean vbResult = false;
       DBDJuristicDAO voDBDJuristicDAO = new DBDJuristicDAO();
       try
       {
          context.getUserTransaction().begin();
          vaReferenceId = voDBDJuristicDAO.generateWebserviceLog();
          vbResult = voDBDJuristicDAO.validateWebserviceLog(em, vaReferenceId);
          if(vbResult)
          { //กรณี ReferenceId ซ้ำ
             vaReferenceId = String.valueOf(Long.parseLong(vaReferenceId) + 1);
          }
          poWebserviceLog.setReferenceId(vaReferenceId);
          voDBDJuristicDAO.insertWebserviceLog(em, poWebserviceLog);
          context.getUserTransaction().commit();
       }
       catch(ApplicationException ae)
       {
          try
          {
             context.getUserTransaction().rollback();
          }
          catch(Exception ee)
          {
             System.out.println("DBDJuristicEJBServBean insertWebserviceLog ee: "+ee.getMessage());
          }
          throw new ApplicationException(ae.getMessage());
       }
       catch(Exception e)
       {
          try
          {
             context.getUserTransaction().rollback();
          }
          catch(Exception ee)
          {
              System.out.println("DBDJuristicEJBServBean insertWebserviceLog ee: "+ee.getMessage());
          }
          throw new Exception(new StringBuffer("DBDJuristicEJBServBean.insertWebserviceLog : ").append(e.getMessage()).toString());
       }
       return vaReferenceId;
    }
    public String getToken(String paConsumerKey ,String paAgentId) throws ApplicationException, Exception 
        {
          
          String vaToken = "";
          String vaAgentID = paAgentId;
          String vaConsumerSecret = "";
          try {
              //call ws
              Webservice voWebServiceConsumerSecret = voWebServiceURLEJBServLocal.getWebServiceURL(3);
              if(voWebServiceConsumerSecret!=null && voWebServiceConsumerSecret.getUrl()!=null && voWebServiceConsumerSecret.getUrl().length()>0)
              {
                  vaConsumerSecret = voWebServiceConsumerSecret.getUrl();
              }
              String vaUri = "https://api.egov.go.th/ws/auth/validate"; //default
              Client client = Client.create();
              client.setConnectTimeout(10000);
              client.setReadTimeout(10000);

              WebResource resource = client.resource(vaUri)
                                           .queryParam("ConsumerSecret",vaConsumerSecret)
                                           .queryParam("AgentID",vaAgentID);
             //System.err.println("resource"+resource);
              ClientResponse responseReturn = resource.accept(MediaType.APPLICATION_JSON)
                                              .header("Content-Type","application/json;charset=UTF-8")
                                              .header("Consumer-Key", paConsumerKey)
                                              .get(ClientResponse.class);
            //System.err.println("responseReturn"+responseReturn);
              if (responseReturn.getStatus() != 200) {
                throw new ApplicationException("call WS Error : "+responseReturn.getStatus());
              }

              String output = responseReturn.getEntity(String.class);
              JSONObject voOutJson = new JSONObject(output);
              if (!voOutJson.isNull("Message")) 
              {
                throw new Exception(voOutJson.getString("Message"));
              } 
              else if (!voOutJson.isNull("Result")) 
              {
                  vaToken = voOutJson.getString("Result");
              }
          } 
          catch (Exception e) 
          {
              System.err.println("error "+ e.getMessage());
            throw new Exception(e.getMessage());
          }
          System.err.println("vaToken "+vaToken);
          return vaToken;
        }
        
        
      public WebserviceLog getJuristic(String vaJuristicID ,String paAgentId,String paUidAmn,String paIpAdr) throws ApplicationException, Exception 
      {
        String error;
          String vaReturnStatus = "";
          String vaReturnStatusDesc = "";
          String vaStringJson = "";
          String vaToken = "";
          String vaReturnData = null;
          WebserviceLog voWebserviceLog = new WebserviceLog();
          String vaConsumerKey = "";
          String vaUrlName = "";

          try 
          {
            Webservice voWebServiceConsumerKey = voWebServiceURLEJBServLocal.getWebServiceURL(2);
            if(voWebServiceConsumerKey!=null && voWebServiceConsumerKey.getUrl()!=null && voWebServiceConsumerKey.getUrl().length()>0)
            {
                vaConsumerKey = voWebServiceConsumerKey.getUrl();
            }
              vaToken = getToken(vaConsumerKey,paAgentId);
              String vaUri = "https://api.egov.go.th/ws/auth/validate"; //default
              Webservice voWebServiceURL = voWebServiceURLEJBServLocal.getWebServiceURL(7);
              if(voWebServiceURL!=null && voWebServiceURL.getUrl()!=null && voWebServiceURL.getUrl().length()>0)
              {
                  vaUri = voWebServiceURL.getUrl();
                  vaUrlName = voWebServiceURL.getUrlName();
              }
              Client client = Client.create();
              client.setConnectTimeout(10000);
              client.setReadTimeout(10000);
              WebResource resource = client.resource(vaUri)
                                           .queryParam("JuristicID", vaJuristicID);
              ClientResponse responseReturn = resource.accept(MediaType.APPLICATION_JSON)
                                                      .header("Content-Type","application/x-www-form-urlencoded")
                                                      .header("Consumer-Key", vaConsumerKey)
                                                      .header("Token",vaToken).get(ClientResponse.class);
              
              vaReturnStatus = String.valueOf(responseReturn.getStatus());
              vaReturnStatusDesc = String.valueOf(responseReturn.getStatusInfo().getReasonPhrase());
              if (responseReturn.getStatus() == 200) 
              {
                  vaReturnData = responseReturn.getEntity(String.class);
               
              }
            vaStringJson = "{\"returnStatus\":\""
                           + vaReturnStatus + "\", \"returnStatusDesc\":\"" 
                           + vaReturnStatusDesc + "\", \"data\":" + vaReturnData + "}";

             
            voWebserviceLog.setAgentId(paAgentId);
            voWebserviceLog.setipaddress(paIpAdr);
            voWebserviceLog.setCompanyId(vaJuristicID);
            voWebserviceLog.setDpaStatusCode(vaReturnStatus);
            voWebserviceLog.setDpaStatusDescTh(vaReturnStatusDesc);
            voWebserviceLog.setDataResponse(vaStringJson);
            voWebserviceLog.setUrl(vaUri);
            voWebserviceLog.setUrlName(vaUrlName);
            voWebserviceLog.setUrlId(7);
            voWebserviceLog.setCreatedBy(paUidAmn);
            voWebserviceLog.setUpdatedBy(paUidAmn);
            String vaReferenceId = insertWebserviceLog(voWebserviceLog);
            voWebserviceLog.setReferenceId(vaReferenceId);
            
          } 
          catch (Exception e) 
          {
              System.err.println("error "+ e.getMessage());
             
                throw new Exception(e.getMessage());
                
           
          }
          System.err.println("223 vaReturnStatusDesc"+ vaReturnStatusDesc);
          return voWebserviceLog;
      }
    public WebserviceLog getShareholder(String vaJuristicID ,String paAgentId,String paUidAmn,String paIpAdr) throws ApplicationException, Exception 
    {
        String vaReturnStatus = "";
        String vaReturnStatusDesc = "";
        String vaStringJson = "";
        String vaToken = "";
        String vaReturnData = null;
        WebserviceLog voWebserviceLog = new WebserviceLog();
        String vaConsumerKey = "";
        String vaUrlName = "";

        try 
        {
          Webservice voWebServiceConsumerKey = voWebServiceURLEJBServLocal.getWebServiceURL(2);
          if(voWebServiceConsumerKey!=null && voWebServiceConsumerKey.getUrl()!=null && voWebServiceConsumerKey.getUrl().length()>0)
          {
              vaConsumerKey = voWebServiceConsumerKey.getUrl();
          }
            vaToken = getToken(vaConsumerKey,paAgentId);
            String vaUri = "https://api.egov.go.th/ws/auth/validate"; //default
            Webservice voWebServiceURL = voWebServiceURLEJBServLocal.getWebServiceURL(8);
            if(voWebServiceURL!=null && voWebServiceURL.getUrl()!=null && voWebServiceURL.getUrl().length()>0)
            {
                vaUri = voWebServiceURL.getUrl();
                vaUrlName = voWebServiceURL.getUrlName();
            }
            Client client = Client.create();
            client.setConnectTimeout(10000);
            client.setReadTimeout(10000);
            WebResource resource = client.resource(vaUri)
                                         .queryParam("JuristicID", vaJuristicID);
            ClientResponse responseReturn = resource.accept(MediaType.APPLICATION_JSON)
                                                    .header("Content-Type","application/x-www-form-urlencoded")
                                                    .header("Consumer-Key", vaConsumerKey)
                                                    .header("Token",vaToken).get(ClientResponse.class);
            
            vaReturnStatus = String.valueOf(responseReturn.getStatus());
            vaReturnStatusDesc = String.valueOf(responseReturn.getStatusInfo().getReasonPhrase());
            if (responseReturn.getStatus() == 200) 
            {
                vaReturnData = responseReturn.getEntity(String.class);
            }

            vaStringJson = "{\"returnStatus\":\""
                           + vaReturnStatus + "\", \"returnStatusDesc\":\"" 
                           + vaReturnStatusDesc + "\", \"data\":" + vaReturnData + "}";

        
          voWebserviceLog.setAgentId(paAgentId);
          voWebserviceLog.setipaddress(paIpAdr);
          voWebserviceLog.setCompanyId(vaJuristicID);
          voWebserviceLog.setDpaStatusCode(vaReturnStatus);
          voWebserviceLog.setDpaStatusDescTh(vaReturnStatusDesc);
          voWebserviceLog.setDataResponse(vaStringJson);
          voWebserviceLog.setUrl(vaUri);
          voWebserviceLog.setUrlName(vaUrlName);
          voWebserviceLog.setUrlId(8);
          voWebserviceLog.setCreatedBy(paUidAmn);
          voWebserviceLog.setUpdatedBy(paUidAmn);
          String vaReferenceId = insertWebserviceLog(voWebserviceLog);
          voWebserviceLog.setReferenceId(vaReferenceId);
          
        } 
        catch (Exception e) 
        {
            System.err.println("error "+ e.getMessage());
          throw new Exception(e.getMessage());
        }
        System.err.println("vaReturnStatus"+ vaReturnStatus);
        return voWebserviceLog;
    }
    public JuristicFile getShareholderFile(String paJuristicID,String paAgentId,String paUidAmn,String paIpAdr) throws ApplicationException, Exception 
    {
        WebserviceLog voWebserviceLog = new WebserviceLog();
        JuristicFile voJuristicFile = new JuristicFile();
        String vaReturnStatus = "";
        String vaReturnStatusDesc = "";
        String vaStringJson = "";
        String vaToken = "";
        String vaReturnData = null;
        String vaConsumerKey = "";
        String vaUrlName = "";
        try
        {           
            Webservice voWebServiceConsumerKey = voWebServiceURLEJBServLocal.getWebServiceURL(2);
            if(voWebServiceConsumerKey!=null && voWebServiceConsumerKey.getUrl()!=null && voWebServiceConsumerKey.getUrl().length()>0)
            {
                vaConsumerKey = voWebServiceConsumerKey.getUrl();
            }
              vaToken = getToken(vaConsumerKey,paAgentId);
              String vaUri = "https://api.egov.go.th/ws/auth/validate"; //default
              Webservice voWebServiceURL = voWebServiceURLEJBServLocal.getWebServiceURL(4);
              if(voWebServiceURL!=null && voWebServiceURL.getUrl()!=null && voWebServiceURL.getUrl().length()>0)
              {
                  vaUri = voWebServiceURL.getUrl();
                  vaUrlName = voWebServiceURL.getUrlName();
              }

            Client client = Client.create();
            client.setConnectTimeout(10000);
            client.setReadTimeout(10000);
            WebResource resource = client.resource(vaUri)
            .queryParam("JuristicID", paJuristicID);
            ClientResponse responseReturn = resource.accept(MediaType.APPLICATION_JSON)
                                                    .header("Content-Type", "application/x-www-form-urlencoded")
                                                    .header("Consumer-Key", vaConsumerKey)
                                                    .header("Token", vaToken)
                                                    .get(ClientResponse.class);
            
            vaReturnStatus = String.valueOf(responseReturn.getStatus());
            vaReturnStatusDesc = String.valueOf(responseReturn.getStatusInfo().getReasonPhrase());
            if (responseReturn.getStatus() == 200) 
            {
                vaReturnData = responseReturn.getEntity(String.class);
            }

            vaStringJson = "{\"returnStatus\":\""
                           + vaReturnStatus + "\", \"returnStatusDesc\":\"" 
                           + vaReturnStatusDesc + "\", \"data\":" + vaReturnData + "}";

            voWebserviceLog.setAgentId(paAgentId);
            voWebserviceLog.setipaddress(paIpAdr);
            voWebserviceLog.setCompanyId(paJuristicID);
            voWebserviceLog.setDpaStatusCode(vaReturnStatus);
            voWebserviceLog.setDpaStatusDescTh(vaReturnStatusDesc);
            voWebserviceLog.setDataResponse(vaStringJson);
            voWebserviceLog.setUrl(vaUri);
            voWebserviceLog.setUrlName(vaUrlName);
            voWebserviceLog.setUrlId(4);
            
            voWebserviceLog.setCreatedBy(paUidAmn);
            voWebserviceLog.setUpdatedBy(paUidAmn);
            insertWebserviceLog(voWebserviceLog);
            
              JSONObject voOutJson = new JSONObject(vaReturnData);
                if(!voOutJson.isNull("Message"))
                {
                      throw new Exception(voOutJson.getString("Message"));
                }
                else
                {
                    voJuristicFile = new JuristicFile();
                    if(!voOutJson.isNull("FileName"))
                    {
                        voJuristicFile.setFileName(voOutJson.getString("FileName"));
                    }
                    if(!voOutJson.isNull("FileSize"))
                    {
                        voJuristicFile.setFileSize(voOutJson.getString("FileSize"));
                    }
                    if(!voOutJson.isNull("mimeType"))
                    {
                        voJuristicFile.setMimeType(voOutJson.getString("mimeType"));
                    }
                    if(!voOutJson.isNull("Hashes"))
                    {
                        voJuristicFile.setHashes(voOutJson.getString("Hashes"));
                    }
                    if(!voOutJson.isNull("Result"))
                    {
                        voJuristicFile.setResult(voOutJson.getString("Result"));
                    }
                }
            }
            catch (Exception e)
            {
                System.err.println("error "+ e.getMessage());
                throw new Exception(e.getMessage());
            }
            System.err.println("voJuristicFile"+ voJuristicFile);
            return voJuristicFile;
    }
    public JuristicIMG getShareholderFileImg(String paJuristicID,String paPage,String paAgentId,String paUidAmn,String paIpAdr) throws ApplicationException, Exception 
    {
        WebserviceLog voWebserviceLog = new WebserviceLog();
        JuristicIMG voJuristicIMG = new JuristicIMG();
        String vaReturnStatus = "";
        String vaReturnStatusDesc = "";
        String vaStringJson = "";
        String vaToken = "";
        String vaReturnData = null;
        String vaConsumerKey = "";
        String vaUrlName = "";
      
        try
        {           
            Webservice voWebServiceConsumerKey = voWebServiceURLEJBServLocal.getWebServiceURL(2);
            if(voWebServiceConsumerKey!=null && voWebServiceConsumerKey.getUrl()!=null && voWebServiceConsumerKey.getUrl().length()>0)
            {
                vaConsumerKey = voWebServiceConsumerKey.getUrl();
            }
              vaToken = getToken(vaConsumerKey,paAgentId);
              String vaUri = "https://api.egov.go.th/ws/auth/validate"; //default
              Webservice voWebServiceURL = voWebServiceURLEJBServLocal.getWebServiceURL(9);
              if(voWebServiceURL!=null && voWebServiceURL.getUrl()!=null && voWebServiceURL.getUrl().length()>0)
              {
                  vaUri = voWebServiceURL.getUrl();
                  vaUrlName = voWebServiceURL.getUrlName();
              }

            Client client = Client.create();
            client.setConnectTimeout(10000);
            client.setReadTimeout(10000);
            WebResource resource = client.resource(vaUri)
            .queryParam("JuristicID", paJuristicID).queryParam("Page", paPage);
            ClientResponse responseReturn = resource.accept(MediaType.APPLICATION_JSON)
                                                    .header("Content-Type", "application/x-www-form-urlencoded")
                                                    .header("Consumer-Key", vaConsumerKey)
                                                    .header("Token", vaToken)
                                                    .get(ClientResponse.class);
            
            vaReturnStatus = String.valueOf(responseReturn.getStatus());
            vaReturnStatusDesc = String.valueOf(responseReturn.getStatusInfo().getReasonPhrase());
            if (responseReturn.getStatus() == 200) 
            {
                vaReturnData = responseReturn.getEntity(String.class);
            }

            vaStringJson = "{\"returnStatus\":\""
                           + vaReturnStatus + "\", \"returnStatusDesc\":\"" 
                           + vaReturnStatusDesc + "\", \"data\":" + vaReturnData + "}";

            voWebserviceLog.setAgentId(paAgentId);
            voWebserviceLog.setipaddress(paIpAdr);
            voWebserviceLog.setCompanyId(paJuristicID);
            voWebserviceLog.setDpaStatusCode(vaReturnStatus);
            voWebserviceLog.setDpaStatusDescTh(vaReturnStatusDesc);
            voWebserviceLog.setDataResponse(vaStringJson);
            voWebserviceLog.setUrl(vaUri);
            voWebserviceLog.setUrlName(vaUrlName);
            voWebserviceLog.setUrlId(4);
            
            voWebserviceLog.setCreatedBy(paUidAmn);
            voWebserviceLog.setUpdatedBy(paUidAmn);
            insertWebserviceLog(voWebserviceLog);
            
              JSONObject voOutJson = new JSONObject(vaReturnData);
                if(!voOutJson.isNull("Message"))
                {
                      throw new Exception(voOutJson.getString("Message"));
                }
                else
                {
                  
                    if(!voOutJson.isNull("Type"))
                    {
                        voJuristicIMG.setType(voOutJson.getString("Type"));
                    }
                    if(!voOutJson.isNull("Page"))
                    {
                        voJuristicIMG.setPage(voOutJson.getString("Page"));
                    }
                    if(!voOutJson.isNull("Contents"))
                    {
                        voJuristicIMG.setContents(voOutJson.getString("Contents"));
                    }
                   
                    JSONArray jArray = (JSONArray) new JSONTokener(voOutJson.getString("Contents")).nextValue();
                    JSONObject voOutJsonArray = jArray.getJSONObject(0);
                     System.out.println(voOutJsonArray.getString("Data"));
                    if(!voOutJsonArray.isNull("Page"))
                    {
                        voJuristicIMG.setContentsPage(voOutJsonArray.getString("Page"));
                    }
                    if(!voOutJsonArray.isNull("Total"))
                    {
                        voJuristicIMG.setTotal(voOutJsonArray.getString("Total"));
                    }
                    if(!voOutJsonArray.isNull("Type"))
                    {
                        System.err.println(voOutJsonArray.getString("Type"));
                        voJuristicIMG.setContentsType(voOutJsonArray.getString("Type"));
                    }
                    if(!voOutJsonArray.isNull("Size"))
                    {
                        voJuristicIMG.setSize(voOutJsonArray.getString("Size"));
                    }
                    if(!voOutJsonArray.isNull("Data"))
                    {
                        voJuristicIMG.setData(voOutJsonArray.getString("Data"));
                    }
                }
            }
            catch (Exception e)
            {
                System.err.println("error "+ e.getMessage());
                throw new Exception(e.getMessage());
            }
            System.out.println("voJuristicFile Bean "+ voJuristicIMG);
            return voJuristicIMG;
    }
    public JuristicFile getJuristicSinged(String paJuristicID,String paAgentId,String paUidAmn,String paIpAdr) throws ApplicationException, Exception 
    {
        WebserviceLog voWebserviceLog = new WebserviceLog();
        JuristicFile voJuristicFile = new JuristicFile();
        String vaReturnStatus = "";
        String vaReturnStatusDesc = "";
        String vaStringJson = "";
        String vaToken = "";
        String vaReturnData = null;
        String vaConsumerKey = "";
        String vaUrlName = "";
        try
        {           
            Webservice voWebServiceConsumerKey = voWebServiceURLEJBServLocal.getWebServiceURL(2);
            if(voWebServiceConsumerKey!=null && voWebServiceConsumerKey.getUrl()!=null && voWebServiceConsumerKey.getUrl().length()>0)
            {
                vaConsumerKey = voWebServiceConsumerKey.getUrl();
            }
              vaToken = getToken(vaConsumerKey,paAgentId);
              String vaUri = "https://api.egov.go.th/ws/auth/validate"; //default
              Webservice voWebServiceURL = voWebServiceURLEJBServLocal.getWebServiceURL(6);
              if(voWebServiceURL!=null && voWebServiceURL.getUrl()!=null && voWebServiceURL.getUrl().length()>0)
              {
                  vaUri = voWebServiceURL.getUrl();
                  vaUrlName = voWebServiceURL.getUrlName();
              }

            Client client = Client.create();
            client.setConnectTimeout(10000);
            client.setReadTimeout(10000);
            WebResource resource = client.resource(vaUri)
            .queryParam("JuristicID", paJuristicID);
            ClientResponse responseReturn = resource.accept(MediaType.APPLICATION_JSON)
                                                    .header("Content-Type", "application/x-www-form-urlencoded")
                                                    .header("Consumer-Key", vaConsumerKey)
                                                    .header("Token", vaToken)
                                                    .get(ClientResponse.class);
            
            vaReturnStatus = String.valueOf(responseReturn.getStatus());
            vaReturnStatusDesc = String.valueOf(responseReturn.getStatusInfo().getReasonPhrase());
            if (responseReturn.getStatus() == 200) 
            {
                vaReturnData = responseReturn.getEntity(String.class);
            }

            vaStringJson = "{\"returnStatus\":\""
                           + vaReturnStatus + "\", \"returnStatusDesc\":\"" 
                           + vaReturnStatusDesc + "\", \"data\":" + vaReturnData + "}";

            voWebserviceLog.setAgentId(paAgentId);
            voWebserviceLog.setipaddress(paIpAdr);
            voWebserviceLog.setCompanyId(paJuristicID);
            voWebserviceLog.setDpaStatusCode(vaReturnStatus);
            voWebserviceLog.setDpaStatusDescTh(vaReturnStatusDesc);
            voWebserviceLog.setDataResponse(vaStringJson);
            voWebserviceLog.setUrl(vaUri);
            voWebserviceLog.setUrlName(vaUrlName);
            voWebserviceLog.setUrlId(6);
            
            voWebserviceLog.setCreatedBy(paUidAmn);
            voWebserviceLog.setUpdatedBy(paUidAmn);
            insertWebserviceLog(voWebserviceLog);
          
              voJuristicFile = new JuristicFile();
              JSONObject voOutJson = new JSONObject(vaReturnData);
          
                if(!voOutJson.isNull("Message"))
                {
                       System.out.println(voOutJson.getString("Message"));
                  voJuristicFile.setMessage(voOutJson.getString("Message"));
                 
                }
                else
                {
                    
                    if(!voOutJson.isNull("FileName"))
                    {
                        voJuristicFile.setFileName(voOutJson.getString("FileName"));
                    }
                    if(!voOutJson.isNull("FileSize"))
                    {
                        voJuristicFile.setFileSize(voOutJson.getString("FileSize"));
                    }
                    if(!voOutJson.isNull("mimeType"))
                    {
                        voJuristicFile.setMimeType(voOutJson.getString("mimeType"));
                    }
                    if(!voOutJson.isNull("Hashes"))
                    {
                        voJuristicFile.setHashes(voOutJson.getString("Hashes"));
                    }
                    if(!voOutJson.isNull("Result"))
                    {
                        voJuristicFile.setResult(voOutJson.getString("Result"));
                    }
                }
            }
            catch (Exception e)
            {
            
                System.err.println("err "+ e.getMessage());
                throw new Exception(e.getMessage());
              
            }
            System.err.println("voJuristicFile"+ voJuristicFile);
            return voJuristicFile;
    }
    public JuristicFile getJuristicSingedFile(String paJuristicID,String paPage,String paAgentId,String paUidAmn,String paIpAdr) throws ApplicationException, Exception 
    {
        WebserviceLog voWebserviceLog = new WebserviceLog();
        JuristicFile voJuristicFile = new JuristicFile();
        String vaReturnStatus = "";
        String vaReturnStatusDesc = "";
        String vaStringJson = "";
        String vaToken = "";
        String vaReturnData = null;
        String vaConsumerKey = "";
        String vaUrlName = "";
        String vaPage = paPage;
        try
        {           
            Webservice voWebServiceConsumerKey = voWebServiceURLEJBServLocal.getWebServiceURL(2);
            if(voWebServiceConsumerKey!=null && voWebServiceConsumerKey.getUrl()!=null && voWebServiceConsumerKey.getUrl().length()>0)
            {
                vaConsumerKey = voWebServiceConsumerKey.getUrl();
            }
              vaToken = getToken(vaConsumerKey,paAgentId);
              String vaUri = "https://api.egov.go.th/ws/auth/validate"; //default
              Webservice voWebServiceURL = voWebServiceURLEJBServLocal.getWebServiceURL(5);
              if(voWebServiceURL!=null && voWebServiceURL.getUrl()!=null && voWebServiceURL.getUrl().length()>0)
              {
                  vaUri = voWebServiceURL.getUrl();
                  vaUrlName = voWebServiceURL.getUrlName();
              }

            Client client = Client.create();
            client.setConnectTimeout(10000);
            client.setReadTimeout(10000);
            WebResource resource = client.resource(vaUri)
            .queryParam("JuristicID", paJuristicID).queryParam("Page", vaPage);
            ClientResponse responseReturn = resource.accept(MediaType.APPLICATION_JSON)
                                                    .header("Content-Type", "application/x-www-form-urlencoded")
                                                    .header("Consumer-Key", vaConsumerKey)
                                                    .header("Token", vaToken)
                                                    .get(ClientResponse.class);
            
            vaReturnStatus = String.valueOf(responseReturn.getStatus());
            vaReturnStatusDesc = String.valueOf(responseReturn.getStatusInfo().getReasonPhrase());
            if (responseReturn.getStatus() == 200) 
            {
                vaReturnData = responseReturn.getEntity(String.class);
            }

            vaStringJson = "{\"returnStatus\":\""
                           + vaReturnStatus + "\", \"returnStatusDesc\":\"" 
                           + vaReturnStatusDesc + "\", \"data\":" + vaReturnData + "}";

            voWebserviceLog.setAgentId(paAgentId);
            voWebserviceLog.setipaddress(paIpAdr);
            voWebserviceLog.setCompanyId(paJuristicID);
            voWebserviceLog.setDpaStatusCode(vaReturnStatus);
            voWebserviceLog.setDpaStatusDescTh(vaReturnStatusDesc);
            voWebserviceLog.setDataResponse(vaStringJson);
            voWebserviceLog.setUrl(vaUri);
            voWebserviceLog.setUrlName(vaUrlName);
            voWebserviceLog.setUrlId(5);
            
            voWebserviceLog.setCreatedBy(paUidAmn);
            voWebserviceLog.setUpdatedBy(paUidAmn);
            insertWebserviceLog(voWebserviceLog);
            
              JSONObject voOutJson = new JSONObject(vaReturnData);
                if(!voOutJson.isNull("Message"))
                {
                      throw new ApplicationException("ไม่พบข้อมูลที่ต้องการพิมพ์");
                     
                }
                else
                {
                    voJuristicFile = new JuristicFile();
                    if(!voOutJson.isNull("FileName"))
                    {
                        voJuristicFile.setFileName(voOutJson.getString("FileName"));
                    }
                    if(!voOutJson.isNull("FileSize"))
                    {
                        voJuristicFile.setFileSize(voOutJson.getString("FileSize"));
                    }
                    if(!voOutJson.isNull("mimeType"))
                    {
                        voJuristicFile.setMimeType(voOutJson.getString("mimeType"));
                    }
                    if(!voOutJson.isNull("Hashes"))
                    {
                        voJuristicFile.setHashes(voOutJson.getString("Hashes"));
                    }
                    if(!voOutJson.isNull("Result"))
                    {
                        voJuristicFile.setResult(voOutJson.getString("Result"));
                    }
                }
            }
            catch (Exception e)
            {
                System.err.println("error "+ e.getMessage());
                throw new ApplicationException(e.getMessage());
            }
            System.err.println("voJuristicFile"+ voJuristicFile);
            return voJuristicFile;
    }
    public SearchResult<WebserviceLog> searchCallWebService(String paCompanyId, String paAgentId ,String paSortOrder, int pnPageNumber,byte pnRowPerPage) throws   Exception
    { 
      
      SearchResult<WebserviceLog> voDBDJuristicList = null;
      
        try
        {
          System.out.println("in bean");
          DBDJuristicDAO  voDBDJuristic = new DBDJuristicDAO();
          voDBDJuristicList  = voDBDJuristic.searchCallWebService(em, paCompanyId, paAgentId, paSortOrder, pnPageNumber, pnRowPerPage);
        }
        catch (Exception e)
        {
          throw new Exception(new StringBuffer("DBDJuristicEJBServBean.searchCallWebService : ").append(e.getMessage()).toString());
        }
       
      return voDBDJuristicList;
    }
}
