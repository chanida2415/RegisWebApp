package pro.reg.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import pro.reg.data.SecUserInfo;


public class SecurityDAO {
     public int Login(EntityManager em, SecUserInfo voSecUserInfo) throws Exception
       {
           try
           {
             System.out.println("15 in login");
               
               StringBuffer jpqlCdtStmt = new StringBuffer();
                jpqlCdtStmt.append(" SELECT aoSecUserInfo ");
               jpqlCdtStmt.append(" FROM SecUserInfo aoSecUserInfo ");
               jpqlCdtStmt.append(" WHERE 1=1 ");

             

               if (voSecUserInfo.getUserId() != null && voSecUserInfo.getUserId().length() > 0)
               {
                   jpqlCdtStmt.append(" AND LOWER(aoSecUserInfo.userId) LIKE CONCAT(CONCAT('%', LOWER(?1)), '%') ");
               }
               if (voSecUserInfo.getUserPassword() != null && voSecUserInfo.getUserPassword().length() > 0)
               {
                   jpqlCdtStmt.append(" AND LOWER(aoSecUserInfo.userPassword) LIKE CONCAT(CONCAT('%', LOWER(?2)), '%') ");

               }
             
             Query voQuery = em.createQuery(jpqlCdtStmt.toString());
               
             voQuery.setParameter(1, voSecUserInfo.getUserId());
             voQuery.setParameter(2, voSecUserInfo.getUserPassword());

               int vbResult = 0;
               if (voQuery.getResultList() != null && voQuery.getResultList().size() > 0)
               {
                 System.out.println(" 49 DAo in if");
                   vbResult = 1; //have info can login
               }
               System.err.println("50"+vbResult);
               return vbResult;
           }
           catch (Exception e)
           {
               throw new Exception(new StringBuffer("SecurityDAO.Login : ").append(e.getMessage()).toString());
           }


       }

     

       public boolean validateUser(EntityManager em,String paUserId) throws Exception
       {
           try
           {
            
               StringBuffer jpqlStmt = new StringBuffer();
               jpqlStmt.append(" SELECT aoSecUserInfo ");
               jpqlStmt.append(" FROM SecUserInfo aoSecUserInfo ");
               jpqlStmt.append(" WHERE aoSecUserInfo.userId = ?1 ");

               Query voQuery = em.createQuery(jpqlStmt.toString());
               voQuery.setParameter(1, paUserId);
           

               boolean vbResult = false;
             System.err.println("77"+voQuery.getResultList());
               if (voQuery.getResultList() != null && voQuery.getResultList().size() > 0)
               {
                   vbResult = true; //have info
               }
               System.err.println("82"+vbResult);
               return vbResult;
           }
           catch (Exception e)
           {
               throw new Exception(new StringBuffer("SecurityDAO.validateLogin : ").append(e.getMessage()).toString());
           }
       }
    public boolean validatePass(EntityManager em,String paUserId,String paUserPass) throws Exception
    {
        try
        {
         
            StringBuffer jpqlStmt = new StringBuffer();
            jpqlStmt.append(" SELECT aoSecUserInfo ");
            jpqlStmt.append(" FROM SecUserInfo aoSecUserInfo ");
            jpqlStmt.append(" WHERE aoSecUserInfo.userId = ?1  ");
            jpqlStmt.append(" AND aoSecUserInfo.userPassword = ?2  ");
            Query voQuery = em.createQuery(jpqlStmt.toString());
            voQuery.setParameter(1, paUserId);
            voQuery.setParameter(2, paUserPass);
        

            boolean vbResult = false;
          System.err.println("77"+voQuery.getResultList());
            if (voQuery.getResultList() != null && voQuery.getResultList().size() > 0)
            {
                vbResult = true; //have info
            }
            System.err.println("82"+vbResult);
            return vbResult;
        }
        catch (Exception e)
        {
            throw new Exception(new StringBuffer("SecurityDAO.validateLogin : ").append(e.getMessage()).toString());
        }
    }

}