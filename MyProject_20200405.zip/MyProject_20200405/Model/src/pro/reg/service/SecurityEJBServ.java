package pro.reg.service;

import javax.ejb.Remote;

import pro.reg.data.SecUserInfo;

@Remote
public interface SecurityEJBServ {
  int authenticate(SecUserInfo voSecUserInfo) throws Exception;
  UserContext getSecUserInfo(String paUserId ,String paIPAddress) throws Exception;
}
