package pro.reg.service;

import javax.annotation.Resource;

import javax.ejb.EJBContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import pro.reg.data.SecChangePassword;
import pro.reg.data.SecUserInfo;

import reg.exception.ApplicationException;

@Stateless(name = "changPasswordEJBServ", mappedName = "changPasswordEJBServ")
@TransactionManagement(TransactionManagementType.BEAN)
public class changePasswordEJBServBean
  implements changePasswordEJBServ, changePasswordEJBServLocal
{
  @PersistenceContext(unitName="reg") 
  private EntityManager em;

  @Resource
  private EJBContext context;
  public changePasswordEJBServBean()
  {
  }
  public void insertChangePassword(SecChangePassword poSecChangePassword) throws ApplicationException, Exception
  {
    boolean vbRsl = true;
    try
    {
      System.err.println("37 Bean");
        
      context.getUserTransaction().begin();
      changePasswordDAO voChangePasswordDAO = new changePasswordDAO();
        
      

     

      if (voChangePasswordDAO.validateUserInfoForInsert(em,poSecChangePassword.getUserId(),poSecChangePassword.getOldPassword()) == true)
      {
        
        voChangePasswordDAO.insertChangePassword(em, poSecChangePassword);
        voChangePasswordDAO.updatePassword(em, poSecChangePassword);
      }
      else
      {
        throw new ApplicationException("ไม่มีข้อมูลไม่สามารถเปลี่ยนรหัสผ่านได้");
      }
      vbRsl = true;
      System.err.println("84 Bean");
      context.getUserTransaction().commit();

    }
    catch (ApplicationException ae)
    {
      context.getUserTransaction().rollback();
      throw new ApplicationException(ae.getMessage());
    }
    catch (Exception e)
    {
      context.getUserTransaction().rollback();
      throw new Exception(e.getMessage());
    }
    
  }
  
}
