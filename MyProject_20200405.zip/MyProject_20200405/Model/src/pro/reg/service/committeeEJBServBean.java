package pro.reg.service;

import javax.annotation.Resource;

import javax.ejb.EJBContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;


import pro.reg.data.CommiteeInfo;


import pro.util.SearchResult;

import reg.exception.ApplicationException;

@Stateless(name = "committeeEJBServ", mappedName = "committeeEJBServ")
@TransactionManagement(TransactionManagementType.BEAN)
public class committeeEJBServBean implements committeeEJBServ, committeeEJBServLocal
{
    @PersistenceContext(unitName="reg") 
    private EntityManager em;

    @Resource
    private EJBContext context;
    
    public CommiteeInfo getCommittee(String paCitizenId) throws Exception
    {
      return em.find(CommiteeInfo.class, paCitizenId);
    }
    public SearchResult<CommiteeInfo> searchCommittee(String paCompanyId, String paFristname,String paLastname, String paCitizenId, String paSortOrder, int pnPageNumber,byte pnRowPerPage) throws Exception
    { 
      
      SearchResult<CommiteeInfo> voCommitteeList = null;
      CommitteeDAO voCommitteeDAO = new CommitteeDAO();
      try
      {
        voCommitteeList = voCommitteeDAO.searchCommitteeDAO(em, paCompanyId, paFristname, paLastname, paCitizenId, paSortOrder, pnPageNumber, pnRowPerPage);
      }
      catch (Exception e)
      {
        throw new Exception(new StringBuffer("CommitteeEJBServBean.searchCommittee : ").append(e.getMessage()).toString());
      }
      return voCommitteeList;
    }
    public void insertCommitteeInfo(CommiteeInfo poCommiteeInfo) throws ApplicationException, Exception
    {
      boolean vbRsl = true;
      try
      {         
        context.getUserTransaction().begin();
        CommitteeDAO voCommitteeDAO = new CommitteeDAO();
          
        if (poCommiteeInfo == null)
        {
          throw new ApplicationException("ข้อมูลไม่ครบถ้วน กรุณาตรวจสอบ");
        }

        else if (poCommiteeInfo.getCitizenId() == null ||poCommiteeInfo.getCitizenId().length() == 0)
        {
          throw new ApplicationException("ข้อมูลไม่ครบถ้วน กรุณาตรวจสอบ");
        }


        if (voCommitteeDAO.validateCommitteeForInsert(em,poCommiteeInfo.getCitizenId()) == false)
        {
          System.out.println("84 Bean");
          voCommitteeDAO.insertCommitteeDAOInfo(em, poCommiteeInfo);
          System.err.println("184 Bean");
        }
        else
        {
          throw new ApplicationException("มีข้อมูลในระบบแล้ว ไม่สามารถเพิ่มได้");
        }
        vbRsl = true;
        System.err.println("84 Bean");
        context.getUserTransaction().commit();

      }
      catch (ApplicationException ae)
      {
        context.getUserTransaction().rollback();
        throw new ApplicationException(ae.getMessage());
      }
      catch (Exception e)
      {
        context.getUserTransaction().rollback();
        throw new Exception(e.getMessage());
      }
      
    }
    
    public void updateCommittees(CommiteeInfo poCommiteeInfo) throws Exception
    {
        CommitteeDAO voCommitteeDAO = new CommitteeDAO();
      boolean vbRsl = false;
      try
      {
        context.getUserTransaction().begin();

          if (poCommiteeInfo == null)
          {
            throw new ApplicationException("ข้อมูลไม่ครบถ้วน กรุณาตรวจสอบ");
          }

          else if (poCommiteeInfo.getCitizenId() == null ||poCommiteeInfo.getCitizenId().length() == 0)
          {
            throw new ApplicationException("ข้อมูลไม่ครบถ้วน กรุณาตรวจสอบ");
          }

        if (voCommitteeDAO.validateCommitteeForUpdate(em,poCommiteeInfo.getCitizenId())== true)
        {
          voCommitteeDAO.updateCommitteeInfo(em ,poCommiteeInfo);
        }
        else
        {
            throw new ApplicationException("ไม่พบข้อมูล <b>" + poCommiteeInfo.getCitizenId() + "</b> ในระบบ");
        }
        vbRsl = true;
      
        context.getUserTransaction().commit();
        // return vnEmail;    
      }
      catch (ApplicationException ae)
      {
        context.getUserTransaction().rollback();
        throw new ApplicationException(ae.getMessage());
      }
      catch (Exception e)
      {
        context.getUserTransaction().rollback();
        throw new Exception(e.getMessage());
      }
      
    }
    public void deleteCommittee(CommiteeInfo poCommitteeInfo) throws Exception 
    {
      CommitteeDAO voCommittee = new CommitteeDAO();
      try
      {
         context.getUserTransaction().begin();
         
         int a = voCommittee.deleteCommittee(em, poCommitteeInfo);
        if(a == 0)
        {
          throw new ApplicationException("ไม่สามารถลบข้อมูลได้");
        }
         context.getUserTransaction().commit();
      }
          
      catch (ApplicationException ae)
      {
        context.getUserTransaction().rollback();
        throw new ApplicationException(ae.getMessage());
      }
      catch(Exception e)
      {
         try
         {
            context.getUserTransaction().rollback();
         }
         catch(Exception ee){System.out.println();}
         throw new Exception(new StringBuffer("CommitteeEJBServBean.deleteCommittee : ").append(e.getMessage()).toString()) ;
      }
    }
}
