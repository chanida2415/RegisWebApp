package pro.reg.service;

import javax.ejb.Local;

import pro.reg.data.Cmpinfo;

import pro.util.SearchResult;

import reg.exception.ApplicationException;

@Local
public interface CompanyEJBServLocal
{
    void insertCompanyInfo(Cmpinfo poCmpinfo) throws ApplicationException, Exception;
    Cmpinfo getCompany(String paCompanyId) throws Exception;
    SearchResult<Cmpinfo> searchCompany(String paCompanyId, String paCompanyType,String paCompanyTh, String paRegCapital, int paRegDate,String paSortOrder, int pnPageNumber,byte pnRowPerPage) throws Exception;
    void updateCompanys(Cmpinfo poCmpinfo) throws Exception;
    void deleteCompany(Cmpinfo poCmpinfo) throws Exception ;
}
