package pro.reg.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import pro.reg.data.EmployeeInfo;
import pro.reg.data.EmployeeInfo;

import pro.util.SearchResult;

public class EmployeeDAO
{
    public EmployeeDAO()
    {
        super();
    }
    public void insertEmployeeInfo(EntityManager em, EmployeeInfo poEmployeeInfo) throws Exception
    {
      try
      {  
        StringBuffer sqlStmt = new StringBuffer();
        sqlStmt.append(" INSERT INTO EMPLOYEE_CMP ");
        sqlStmt.append(" (POSITION, FRISTNAME,  LASTNAME, CITIZEN_ID, COMPANY_ID, PREFIX_CODE ");
        sqlStmt.append(" , START_DATE, END_DATE, HOUSE_NUM,  BUILD,   MOO ");
        sqlStmt.append(" , MOONAME,    SOI,      ROAD,       PROVINCE,   AMPHUR ");   
        sqlStmt.append(" , DISTRICT,   ZIPCODE,  EMAIL,      PHONE ");
        sqlStmt.append(" , PROVINCE_CODE,   AMPHUR_CODE,  DISTRICT_CODE ");
        sqlStmt.append(" , CREATED_BY, CREATED_DATE, UPDATED_BY, UPDATED_DATE, IPADDRESS) ");
          
        sqlStmt.append(" VALUES ( ?, ?, ?, ? , ? ,? , ");   
        sqlStmt.append(" ?, ?, ?, ?, ? , ");
        sqlStmt.append(" ?, ?, ?, ?, ? , ");
        sqlStmt.append(" ?, ?, ?, ? , ");
        sqlStmt.append(" ?, ?, ? , ");
        sqlStmt.append(" ? ,CURRENT_TIMESTAMP, ? , CURRENT_TIMESTAMP,?) ");
          
      
        int vnCnt = 1;
        Query voQuery = em.createNativeQuery(sqlStmt.toString());
        //COMPANY_ID, COMPANY_TYPE, COMPANY_TH, COMPANY_EN, REG_CAPITAL
        voQuery.setParameter(vnCnt++, poEmployeeInfo.getPosition());
        voQuery.setParameter(vnCnt++, poEmployeeInfo.getFristname());
        voQuery.setParameter(vnCnt++, poEmployeeInfo.getLastname());
        voQuery.setParameter(vnCnt++, poEmployeeInfo.getCitizenId());
        voQuery.setParameter(vnCnt++, poEmployeeInfo.getCompanyId());
        voQuery.setParameter(vnCnt++, poEmployeeInfo.getPrefixCode());

        //REG_DATE, HOUSE_NUM, MOO, MOONAME, SOI 
        voQuery.setParameter(vnCnt++, poEmployeeInfo.getStartDate());
        voQuery.setParameter(vnCnt++, poEmployeeInfo.getEndDate());
        voQuery.setParameter(vnCnt++, poEmployeeInfo.getHouseNum());
        voQuery.setParameter(vnCnt++, poEmployeeInfo.getBuild());
        voQuery.setParameter(vnCnt++, poEmployeeInfo.getMoo());
       
          //ROAD, PROVINCE_CODE, PROVINCE, AMPHUR_CODE, AMPHUR
        voQuery.setParameter(vnCnt++, poEmployeeInfo.getMooname());
        voQuery.setParameter(vnCnt++, poEmployeeInfo.getSoi());
        voQuery.setParameter(vnCnt++, poEmployeeInfo.getRoad());
        voQuery.setParameter(vnCnt++, poEmployeeInfo.getProvince());
        voQuery.setParameter(vnCnt++, poEmployeeInfo.getAmphur());
          
          //DISTRICT_CODE, DISTRICT_CODE, ZIPCODE, EMAIL, PHONE
    
        voQuery.setParameter(vnCnt++, poEmployeeInfo.getDistrict());
        voQuery.setParameter(vnCnt++, poEmployeeInfo.getZipcode());
        voQuery.setParameter(vnCnt++, poEmployeeInfo.getEmail());
        voQuery.setParameter(vnCnt++, poEmployeeInfo.getPhone());
        
        voQuery.setParameter(vnCnt++, poEmployeeInfo.getProvinceCode());
        voQuery.setParameter(vnCnt++, poEmployeeInfo.getAmphurCode());
        voQuery.setParameter(vnCnt++, poEmployeeInfo.getDistrictCode());
        
        
        voQuery.setParameter(vnCnt++, poEmployeeInfo.getCreatedBy());
        voQuery.setParameter(vnCnt++, poEmployeeInfo.getUpdatedBy());
        voQuery.setParameter(vnCnt++, poEmployeeInfo.getIpaddress());
        voQuery.executeUpdate();
      }
      catch(Exception e)
      {
         throw new Exception(new StringBuffer("EmployeeDAO.insertEmployeeInfo : ").append(e.getMessage()).toString());
      }
    }
    
    public SearchResult<EmployeeInfo> searchEmployee(EntityManager em, String paCompanyId, String paFristname, 
                                                 String paLastname, String paCitizenId,String paSortOrder, int pnPageNumber,byte pnRowPerPage)throws Exception
    {
      int vnTotalRecord = 0;
      int vnTotalPages = 0;
      int vnStartRow = 0;
      StringBuffer jpqlStmt = null;
      //=================Condition==================
      StringBuffer jpqlCdtStmt = new StringBuffer(); 
      jpqlCdtStmt.append(" FROM EmployeeInfo aoEmployeeInfo ");
      jpqlCdtStmt.append(" WHERE 1 = 1");

      if (paCompanyId != null && paCompanyId.length() > 0)
      {
        jpqlCdtStmt.append(" AND aoEmployeeInfo.companyId LIKE CONCAT(?1,'%') ");
      }
      if (paFristname != null && paFristname.length() > 0)
      {
        jpqlCdtStmt.append(" AND LOWER(aoEmployeeInfo.fristname) LIKE CONCAT(CONCAT('%', LOWER(?2)), '%') ");
      }
      if (paLastname != null && paLastname.length() > 0)
      {
        jpqlCdtStmt.append(" AND LOWER(aoEmployeeInfo.lastname) LIKE CONCAT(CONCAT('%', LOWER(?3)), '%') ");
      }
      if (paCitizenId != null && paCitizenId.length() > 0)
      {
        jpqlCdtStmt.append(" AND LOWER(aoEmployeeInfo.citizenId) LIKE CONCAT(CONCAT('%', LOWER(?4)), '%') ");
      }
      //=================Count Total==================
      jpqlStmt = new StringBuffer();
      jpqlStmt.append(" SELECT COUNT(aoEmployeeInfo) ");
      jpqlStmt.append(jpqlCdtStmt); 
      Query voQuery = em.createQuery(jpqlStmt.toString());

      if (paCompanyId != null && paCompanyId.length() > 0)
      {
        voQuery.setParameter(1, paCompanyId);
      }
      if (paFristname != null && paFristname.length() > 0)
      {
        voQuery.setParameter(2, paFristname);
      }
      if (paLastname != null && paLastname.length() > 0)
      {
        voQuery.setParameter(3, paLastname);
      }

      if (paCitizenId != null && paCitizenId.length() > 0)
      {
        voQuery.setParameter(4, paCitizenId);
      }
        vnTotalRecord = ((Long)voQuery.getSingleResult()).intValue();
      //====================Find Data List===========================
      jpqlStmt = new StringBuffer();
      jpqlStmt.append(" SELECT aoEmployeeInfo "); 
      jpqlStmt.append(jpqlCdtStmt);
      if (paSortOrder != null && paSortOrder.length() > 0)
      {
        jpqlStmt.append(paSortOrder); 
      }
      else
      {
        jpqlStmt.append(" ORDER BY aoEmployeeInfo.companyId"); 
      }

         voQuery = em.createQuery(jpqlStmt.toString());
          if (paCompanyId != null && paCompanyId.length() > 0)
          {
            voQuery.setParameter(1, paCompanyId);
          }
          if (paFristname != null && paFristname.length() > 0)
          {
            voQuery.setParameter(2, paFristname);
          }
          if (paLastname != null && paLastname.length() > 0)
          {
            voQuery.setParameter(3, paLastname);
          }

          if (paCitizenId != null && paCitizenId.length() > 0)
          {
            voQuery.setParameter(4, paCitizenId);
          }
          
        vnStartRow = (pnPageNumber - 1) * pnRowPerPage;
        vnTotalPages = ((Double)Math.ceil((double)vnTotalRecord / pnRowPerPage)).intValue();

        List<EmployeeInfo> voTmpList = voQuery.setFirstResult(vnStartRow).setMaxResults(pnRowPerPage == -1 ? vnTotalRecord : pnRowPerPage).getResultList();

        //=============Set Search Result=============
        SearchResult<EmployeeInfo> voSearchResult = new SearchResult<EmployeeInfo>();
        voSearchResult.setResultList(voTmpList);
        voSearchResult.setCurrentPage(pnPageNumber);
        voSearchResult.setTotalPages(vnTotalPages);
        voSearchResult.setTotalRecords(vnTotalRecord);

        return voSearchResult;
    }
    public void updateEmployeeInfo(EntityManager em, EmployeeInfo poEmployeeInfo) throws Exception
    {
      try
      {
        StringBuffer jpqlStmt = new StringBuffer();
          jpqlStmt.append(" UPDATE EmployeeInfo aoEmployeeInfo  ");
            jpqlStmt.append(" SET  aoEmployeeInfo.companyId = ?2 ");
            jpqlStmt.append("    , aoEmployeeInfo.prefixCode = ?3 ");
            jpqlStmt.append("    , aoEmployeeInfo.fristname = ?4 ");
            jpqlStmt.append("    , aoEmployeeInfo.lastname = ?5 ");
//            jpqlStmt.append("    , aoEmployeeInfo.startDate = ?6 ");
//            jpqlStmt.append("    , aoEmployeeInfo.endDate = ?7 ");
            jpqlStmt.append("    , aoEmployeeInfo.houseNum = ?8 ");
            jpqlStmt.append("    , aoEmployeeInfo.build = ?9 ");
            jpqlStmt.append("    , aoEmployeeInfo.soi = ?10 ");
            jpqlStmt.append("    , aoEmployeeInfo.road = ?11 ");
            jpqlStmt.append("    , aoEmployeeInfo.moo = ?12 ");
            jpqlStmt.append("    , aoEmployeeInfo.mooname= ?13");
            jpqlStmt.append("    , aoEmployeeInfo.province = ?14 ");
            jpqlStmt.append("    , aoEmployeeInfo.amphur = ?15 ");
            jpqlStmt.append("    , aoEmployeeInfo.district = ?16 ");
            jpqlStmt.append("    , aoEmployeeInfo.zipcode = ?17 ");
            jpqlStmt.append("    , aoEmployeeInfo.email = ?18 ");
            jpqlStmt.append("    , aoEmployeeInfo.phone = ?19 ");
            jpqlStmt.append("    , aoEmployeeInfo.createdBy = ?20 ");
            jpqlStmt.append("    , aoEmployeeInfo.createdDate = ?21 ");
            jpqlStmt.append("    , aoEmployeeInfo.updatedBy = ?22 ");
            jpqlStmt.append("    , aoEmployeeInfo.updatedDate = ?23 ");
            jpqlStmt.append("    , aoEmployeeInfo.ipaddress = ?24 ");

        jpqlStmt.append("    , aoEmployeeInfo.provinceCode  = ?25 ");
        jpqlStmt.append("    , aoEmployeeInfo.amphurCode  = ?26 ");
        jpqlStmt.append("    , aoEmployeeInfo.districtCode = ?27 ");
            jpqlStmt.append(" WHERE aoEmployeeInfo.citizenId = ?1 ");
        
            Query voQuery = em.createQuery(jpqlStmt.toString());
            
            //EMPLOYEE_ID, COMPANY_TYPE, LAST_NAME, EMAIL, PHONE_NUMBER 
            voQuery.setParameter(1, poEmployeeInfo.getCitizenId());
            voQuery.setParameter(2, poEmployeeInfo.getCompanyId());
            voQuery.setParameter(3, poEmployeeInfo.getPrefixCode());
            voQuery.setParameter(4, poEmployeeInfo.getFristname());
            voQuery.setParameter(5, poEmployeeInfo.getLastname());
            
            //HIRE_DATE, JOB_ID, SALARY, COMMISSION_PCT, MANAGER_ID, DEPARTMENT_ID
//            voQuery.setParameter(6, poEmployeeInfo.getStartDate());
//            voQuery.setParameter(7, poEmployeeInfo.getEndDate());
            voQuery.setParameter(8, poEmployeeInfo.getHouseNum());
            voQuery.setParameter(9, poEmployeeInfo.getBuild());
            voQuery.setParameter(10, poEmployeeInfo.getSoi());
            voQuery.setParameter(11, poEmployeeInfo.getRoad());
            voQuery.setParameter(12, poEmployeeInfo.getMoo());
            voQuery.setParameter(13, poEmployeeInfo.getMooname());
            voQuery.setParameter(14, poEmployeeInfo.getProvince());
            voQuery.setParameter(15, poEmployeeInfo.getAmphur());
            voQuery.setParameter(16, poEmployeeInfo.getDistrict());
            voQuery.setParameter(17, poEmployeeInfo.getZipcode());
            voQuery.setParameter(18, poEmployeeInfo.getEmail());
            voQuery.setParameter(19, poEmployeeInfo.getPhone());
            
            voQuery.setParameter(20, poEmployeeInfo.getCreatedBy());
            voQuery.setParameter(21, poEmployeeInfo.getCreatedDate());
            voQuery.setParameter(22, poEmployeeInfo.getUpdatedBy());
            voQuery.setParameter(23, poEmployeeInfo.getUpdatedDate());
            voQuery.setParameter(24, poEmployeeInfo.getIpaddress());

        voQuery.setParameter(25, poEmployeeInfo.getProvinceCode());
        voQuery.setParameter(26, poEmployeeInfo.getAmphurCode());
        voQuery.setParameter(27, poEmployeeInfo.getDistrictCode());
          
        voQuery.executeUpdate();
      }
      catch (Exception e)
      {
        throw new Exception(new StringBuffer("EmployeeDAO.updateEmployee : ").append(e.getMessage()).toString());
      }
    }
    public boolean validateEmployeeForUpdate(EntityManager em,String paCitizenId) throws Exception
    {
      try
      {
        
        StringBuffer jpqlStmt = new StringBuffer();
        jpqlStmt.append(" SELECT  CITIZEN_ID");
        jpqlStmt.append(" FROM EMPLOYEE_CMP");
        jpqlStmt.append(" WHERE CITIZEN_ID = ?2  ");
        
        Query voQuery = em.createNativeQuery(jpqlStmt.toString());
       
          voQuery.setParameter(2,paCitizenId);

        boolean vbResult = false;
        if(voQuery.getResultList() != null && voQuery.getResultList().size() > 0)
        {
          vbResult = true;
        }
          System.err.println("vbResult "+vbResult);
        return vbResult;
      }
      catch (Exception e)
      {
        throw new Exception(new StringBuffer("EmployeeDAO.validateEmployeeForUpdate : ").append(e.getMessage()).toString());
      }
    }
    public boolean validateEmployeeForInsert(EntityManager em, String paCitizenId) throws Exception
    {
      try
      {
        StringBuffer jpqlStmt = new StringBuffer();
        jpqlStmt.append(" SELECT  CITIZEN_ID");
        jpqlStmt.append(" FROM EMPLOYEE_CMP");
        jpqlStmt.append(" WHERE CITIZEN_ID = ?1 ");

        Query voQuery = em.createNativeQuery(jpqlStmt.toString());
        voQuery.setParameter(1,paCitizenId);
        
        boolean vbResult = false;
        if(voQuery.getResultList() != null && voQuery.getResultList().size() > 0)
        {
          vbResult = true;  //have info
        }
        return vbResult;
      }
      catch (Exception e)
      {
        throw new Exception(new StringBuffer("EmployeeDAO.validateEmployeeForInsert : ").append(e.getMessage()).toString());
      }
    }
    public int deleteEmployee(EntityManager em, EmployeeInfo poEmployeeInfo) throws Exception
    {
        StringBuffer jpqlStmt = new StringBuffer();
        jpqlStmt.append(" DELETE FROM EmployeeInfo o ");
        jpqlStmt.append(" WHERE o.citizenId = ?1 ");
       
        Query voQuery = em.createQuery(jpqlStmt.toString());
        voQuery.setParameter(1, poEmployeeInfo.getCitizenId());
       
       int a = voQuery.executeUpdate();
       return a;
    }
}
