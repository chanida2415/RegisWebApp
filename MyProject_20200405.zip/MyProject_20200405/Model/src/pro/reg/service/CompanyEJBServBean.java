package pro.reg.service;

import javax.annotation.Resource;

import javax.ejb.EJBContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import pro.reg.data.Cmpinfo;

import reg.exception.ApplicationException;
import pro.util.SearchResult;

@Stateless(name = "CompanyEJBServ", mappedName = "CompanyEJBServ")
@TransactionManagement(TransactionManagementType.BEAN)
public class CompanyEJBServBean implements CompanyEJBServ, CompanyEJBServLocal
{
    @PersistenceContext(unitName="reg") 
    private EntityManager em;

    @Resource
    private EJBContext context;
    
    
    public Cmpinfo getCompany(String paCompanyId) throws Exception
    {
        System.err.println("paCompanyId"+paCompanyId);
        System.err.println(em.find(Cmpinfo.class, paCompanyId));
      return em.find(Cmpinfo.class, paCompanyId);
    }
     
                                        
    public SearchResult<Cmpinfo> searchCompany(String paCompanyId, String paCompanyType,String paCompanyTh, String paRegCapital, int paRegDate,String paSortOrder, int pnPageNumber,byte pnRowPerPage) throws Exception
    { 
      
      SearchResult<Cmpinfo> voCompanyList = null;
        CompanyDAO voCompanyDAO = new CompanyDAO();
      try
      {
        voCompanyList = voCompanyDAO.searchCompany(em, paCompanyId, paCompanyType, paCompanyTh,paRegCapital,paRegDate,paSortOrder, pnPageNumber, pnRowPerPage);
      }
      catch (Exception e)
      {
        throw new Exception(new StringBuffer("CompanyEJBServBean.searchCompany : ").append(e.getMessage()).toString());
      }
      return voCompanyList;
    }
    public void insertCompanyInfo(Cmpinfo poCmpinfo) throws ApplicationException, Exception
    {
      boolean vbRsl = true;
      try
      {
        System.err.println("37 Bean");
          
        context.getUserTransaction().begin();
        CompanyDAO voCompanyDAO = new CompanyDAO();
          
        if (poCmpinfo == null)
        {
          throw new ApplicationException("ข้อมูลไม่ครบถ้วน กรุณาตรวจสอบ");
        }

        else if (poCmpinfo.getCompanyId() == null ||poCmpinfo.getCompanyId().length() == 0)
        {
          throw new ApplicationException("ข้อมูลไม่ครบถ้วน กรุณาตรวจสอบ");
        }


        if (voCompanyDAO.validateCompanyForInsert(em,poCmpinfo.getCompanyId()) == false)
        {
          voCompanyDAO.insertCompanyInfo(em, poCmpinfo);
        }
        else
        {
          throw new ApplicationException("มีข้อมูลในระบบแล้ว ไม่สามารถเพิ่มได้");
        }
        vbRsl = true;
        System.err.println("84 Bean");
        context.getUserTransaction().commit();

      }
      catch (ApplicationException ae)
      {
        context.getUserTransaction().rollback();
        throw new ApplicationException(ae.getMessage());
      }
      catch (Exception e)
      {
        context.getUserTransaction().rollback();
        throw new Exception(e.getMessage());
      }
      
    }
    
    public void updateCompanys(Cmpinfo poCmpinfo) throws Exception
    {
        CompanyDAO voCompanyDAO = new CompanyDAO();
      boolean vbRsl = false;
      try
      {
        context.getUserTransaction().begin();

          if (poCmpinfo == null)
          {
            throw new ApplicationException("ข้อมูลไม่ครบถ้วน กรุณาตรวจสอบ");
          }

          else if (poCmpinfo.getCompanyId() == null ||poCmpinfo.getCompanyId().length() == 0)
          {
            throw new ApplicationException("ข้อมูลไม่ครบถ้วน กรุณาตรวจสอบ");
          }

        if (voCompanyDAO.validateCompanyForUpdate(em,poCmpinfo.getCompanyId())== true)
        {
          voCompanyDAO.updateCompanyInfo(em ,poCmpinfo);
        }
        else
        {
            throw new ApplicationException("ไม่พบข้อมูล <b>" + poCmpinfo.getCompanyId() + "</b> ในระบบ");
        }
        vbRsl = true;
      
        context.getUserTransaction().commit();
        // return vnEmail;    
      }
      catch (ApplicationException ae)
      {
        context.getUserTransaction().rollback();
        throw new ApplicationException(ae.getMessage());
      }
      catch (Exception e)
      {
        context.getUserTransaction().rollback();
        throw new Exception(e.getMessage());
      }
      
    }
    public void deleteCompany(Cmpinfo poCmpinfo) throws Exception 
    {
      CompanyDAO voCompany = new CompanyDAO();
      try
      {
         context.getUserTransaction().begin();
         
         int a = voCompany.deleteCompany(em, poCmpinfo);
        if(a == 0)
        {
          throw new ApplicationException("ไม่สามารถลบข้อมูลได้");
        }
         context.getUserTransaction().commit();
      }
          
      catch (ApplicationException ae)
      {
        context.getUserTransaction().rollback();
        throw new ApplicationException(ae.getMessage());
      }
      catch(Exception e)
      {
         try
         {
            context.getUserTransaction().rollback();
         }
         catch(Exception ee){System.out.println();}
         throw new Exception(new StringBuffer("CompanyEJBServBean.deleteCompany : ").append(e.getMessage()).toString()) ;
      }
    }
}
