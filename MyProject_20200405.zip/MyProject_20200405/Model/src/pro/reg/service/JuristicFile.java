package pro.reg.service;

public class JuristicFile extends ResponseData implements java.io.Serializable
{
      protected java.lang.String ID;
      protected java.lang.String fileName;
      protected java.lang.String fileSize;
      protected java.lang.String mimeType;
      protected java.lang.String hashes;
      protected java.lang.String result;
      protected java.lang.String message;
      
      public JuristicFile() {
      }
      
      public java.lang.String getID() {
          return ID;
      }
      
      public void setID(java.lang.String ID) {
          this.ID = ID;
      }
      
      public java.lang.String getFileName() {
          return fileName;
      }
      
      public void setFileName(java.lang.String fileName) {
          this.fileName = fileName;
      }
      
      public java.lang.String getFileSize() {
          return fileSize;
      }
      
      public void setFileSize(java.lang.String fileSize) {
          this.fileSize = fileSize;
      }
      
      public java.lang.String getMimeType() {
          return mimeType;
      }
      
      public void setMimeType(java.lang.String mimeType) {
          this.mimeType = mimeType;
      }
      
      public java.lang.String getHashes() {
          return hashes;
      }
      
      public void setHashes(java.lang.String hashes) {
          this.hashes = hashes;
      }
      
      public java.lang.String getResult() {
          return result;
      }
      
      public void setResult(java.lang.String result) {
          this.result = result;
      }
  public java.lang.String getMessage() {
      return message;
  }
  
  public void setMessage(java.lang.String message) {
      this.message = message;
  }
  
}
