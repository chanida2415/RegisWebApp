package pro.reg.service;

import javax.annotation.Resource;

import javax.ejb.EJBContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import pro.reg.data.ShareHoderInfo;

import pro.util.SearchResult;

import reg.exception.ApplicationException;

@Stateless(name = "ShareHoderEJBServ", mappedName = "ShareHoderEJBServ")
@TransactionManagement(TransactionManagementType.BEAN)
public class ShareHoderEJBServBean implements ShareHoderEJBServ, ShareHoderEJBServLocal
{
    @PersistenceContext(unitName="reg") 
    private EntityManager em;

    @Resource
    private EJBContext context;
    
    public ShareHoderInfo getShareHoder(String paCitizenId) throws Exception
    {
      return em.find(ShareHoderInfo.class, paCitizenId);
    }
    public SearchResult<ShareHoderInfo> searchShareHoder(String paCompanyId, String paFristname,String paLastname, String paCitizenId, String paSortOrder, int pnPageNumber,byte pnRowPerPage) throws Exception
    { 
      
      SearchResult<ShareHoderInfo> voShareHoderList = null;
      ShareHoderDAO voShareHoderDAO = new ShareHoderDAO();
      try
      {
        voShareHoderList = voShareHoderDAO.searchShareHoder(em, paCompanyId, paFristname, paLastname, paCitizenId, paSortOrder, pnPageNumber, pnRowPerPage);
      }
      catch (Exception e)
      {
        throw new Exception(new StringBuffer("ShareHoderEJBServBean.searchShareHoder : ").append(e.getMessage()).toString());
      }
      return voShareHoderList;
    }
    public void insertShareHoderInfo(ShareHoderInfo poShareHoderInfo) throws ApplicationException, Exception
    {
      boolean vbRsl = true;
      try
      {         
        context.getUserTransaction().begin();
        ShareHoderDAO voShareHoderDAO = new ShareHoderDAO();
          
        if (poShareHoderInfo == null)
        {
          throw new ApplicationException("ข้อมูลไม่ครบถ้วน กรุณาตรวจสอบ");
        }

        else if (poShareHoderInfo.getCitizenId() == null ||poShareHoderInfo.getCitizenId().length() == 0)
        {
          throw new ApplicationException("ข้อมูลไม่ครบถ้วน กรุณาตรวจสอบ");
        }


        if (voShareHoderDAO.validateShareHoderForInsert(em,poShareHoderInfo.getCitizenId()) == false)
        {
          voShareHoderDAO.insertShareHoder(em, poShareHoderInfo);
        }
        else
        {
          throw new ApplicationException("มีข้อมูลในระบบแล้ว ไม่สามารถเพิ่มได้");
        }
        vbRsl = true;
        context.getUserTransaction().commit();

      }
      catch (ApplicationException ae)
      {
        context.getUserTransaction().rollback();
        throw new ApplicationException(ae.getMessage());
      }
      catch (Exception e)
      {
        context.getUserTransaction().rollback();
        throw new Exception(e.getMessage());
      }
      
    }
    
    public void updateShareHoders(ShareHoderInfo poShareHoderInfo) throws Exception
    {
        ShareHoderDAO voShareHoderDAO = new ShareHoderDAO();
      boolean vbRsl = false;
      try
      {
        context.getUserTransaction().begin();

       
        if (voShareHoderDAO.validateShareHoderForUpdate(em,poShareHoderInfo.getCitizenId())== true)
        {
        System.err.println("in if Bean Shd UPD");
          voShareHoderDAO.updateShareHoder(em ,poShareHoderInfo);
          System.out.println("in if Bean Shd UPD");
        }
        else
        {
            throw new ApplicationException("ไม่พบข้อมูล <b>" + poShareHoderInfo.getCitizenId() + "</b> ในระบบ");
        }
        vbRsl = true;
      
        context.getUserTransaction().commit();
        // return vnEmail;    
      }
      catch (ApplicationException ae)
      {System.err.println("error");
        context.getUserTransaction().rollback();
        throw new ApplicationException(ae.getMessage());
        
      }
      catch (Exception e)
      { System.out.println("error");
        context.getUserTransaction().rollback();
        throw new Exception(e.getMessage());
       
      }
      
    }
    public void deleteShareHoder(ShareHoderInfo poShareHoderInfo) throws Exception 
    {
      ShareHoderDAO voShareHoder = new ShareHoderDAO();
      try
      {
         context.getUserTransaction().begin();
         
         int a = voShareHoder.deleteShareHoder(em, poShareHoderInfo);
        if(a == 0)
        {
          throw new ApplicationException("ไม่สามารถลบข้อมูลได้");
        }
         context.getUserTransaction().commit();
      }
          
      catch (ApplicationException ae)
      {
        context.getUserTransaction().rollback();
        throw new ApplicationException(ae.getMessage());
      }
      catch(Exception e)
      {
         try
         {
            context.getUserTransaction().rollback();
         }
         catch(Exception ee){System.out.println();}
         throw new Exception(new StringBuffer("ShareHoderEJBServBean.deleteShareHoder : ").append(e.getMessage()).toString()) ;
      }
    }
}
