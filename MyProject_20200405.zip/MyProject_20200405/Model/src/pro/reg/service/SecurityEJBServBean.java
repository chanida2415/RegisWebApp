package pro.reg.service;


import java.util.List;

import javax.annotation.Resource;

import javax.ejb.EJBContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import pro.reg.data.SecUserInfo;

import pro.util.DateConvert;

import reg.exception.ApplicationException;

@Stateless(name = "SecurityEJBServ", mappedName = "SecurityEJBServ")
@TransactionManagement(TransactionManagementType.BEAN)
public class SecurityEJBServBean implements SecurityEJBServ,
                                            SecurityEJBServLocal {
    @PersistenceContext(unitName="reg")
       private EntityManager em;
       @Resource
       private EJBContext context;
    public int authenticate(SecUserInfo voSecUserInfo) throws Exception
        {   
            int vblogin = 0;
           SecurityDAO voSecurityDAO = new SecurityDAO();
            boolean vbRsl = true;
            
            try
            {
              if(voSecUserInfo == null)
              {
                  throw new ApplicationException("insert info");
                }
                if (voSecUserInfo.getUserId() == null || voSecUserInfo.getUserId().length() == 0)
                {
                        throw new ApplicationException("กรุณาระบุชื่อผู้ใช้งาน");
                }
                if (voSecUserInfo.getUserPassword() == null || voSecUserInfo.getUserPassword().length() == 0)
                {
                        throw new ApplicationException("กรุณาระบุรหัสผ่าน");
                }
                if (voSecUserInfo != null)
                {
                    if(voSecurityDAO.validateUser(em,voSecUserInfo.getUserId()) == true)
                    {
                        if(voSecurityDAO.validatePass(em,voSecUserInfo.getUserId(),voSecUserInfo.getUserPassword()) == true)
                        {
                                                                                        
                            vblogin = voSecurityDAO.Login(em,voSecUserInfo);
                            
                            System.out.println("47"+vblogin);
                        }
                        else
                        {
                            vblogin = -2;
                            throw new ApplicationException("รหัสผ่านไม่ถูกต้อง");
                        }
                    }
                    else
                    {       vblogin = -1;
                            throw new ApplicationException("ชื่อผู้ใช้งานไม่ถูกต้อง");
                    }
                }
                else
                {
                      
                    throw new ApplicationException("insert info");
                }
               
               
            }
            catch(ApplicationException ae)
            {
                    throw new ApplicationException(ae.getMessage());
            }
            catch(Exception e)
            {
               throw new Exception(new StringBuffer("SecurityEJBServBean.authenticate : ").append(e.getMessage()).toString()) ;
            }
            
             return vblogin;
       
        }
    
    public UserContext getSecUserInfo(String paUserId ,String paIPAddress) throws Exception
    {
        UserContext  voUserContext= new UserContext() ;
        String vaFirstName = "";
        SecUserInfo voSecUserInfo = em.find(SecUserInfo.class, paUserId);
        if (voSecUserInfo == null) {
              throw new ApplicationException("Security Group with Id: " + paUserId + "  is not found.");
          }
        else{
                vaFirstName = voSecUserInfo.getFirstName();
                String vaLastName = voSecUserInfo.getLastName();
                String vaAgentId = voSecUserInfo.getAgentId();
                voUserContext.setUserId(paUserId);
                voUserContext.setFirstName(vaFirstName);
                voUserContext.setLastName(vaLastName);
                voUserContext.setAgentId(vaAgentId);
                voUserContext.setIpaddress(paIPAddress);
            
            }

        return voUserContext;
    }
    
}