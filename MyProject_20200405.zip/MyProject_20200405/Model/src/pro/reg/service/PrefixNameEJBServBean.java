package pro.reg.service;

import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import pro.reg.data.PrefixName;

@Stateless(name = "PrefixNameEJBServ", mappedName = "PrefixNameEJBServ")
@TransactionManagement(TransactionManagementType.BEAN)
public class PrefixNameEJBServBean implements PrefixNameEJBServ, PrefixNameEJBServLocal
{
    @PersistenceContext(unitName="reg")
    private EntityManager em;
    public PrefixNameEJBServBean()
    {
    }
    public List<PrefixName> searchPrefixNameActiveOnly(String paPrefixCode, String paPrefixName, String paSortOrder) throws Exception
    {
       List<PrefixName> voCrdTypInfoList = null;
       PrefixNameDAO voCrdTypDAO = new PrefixNameDAO();
       try
       {

          voCrdTypInfoList = voCrdTypDAO.searchPrefixNameActiveOnly(em, paPrefixCode, paPrefixName, paSortOrder);

       }
       catch (Exception e)
       {
          throw new Exception(new StringBuffer("PrefixNameEJBServBean.searchPrefixNameActiveOnly : ").append(e.getMessage()).toString());
       }

       return voCrdTypInfoList;
    }

    public PrefixName getPrefixNameActiveOnly(String paPrefixCode) throws Exception
    {
       PrefixName voPrefixName = null;
       PrefixNameDAO voCrdTypDAO = new PrefixNameDAO();
       try
       {

          voPrefixName = voCrdTypDAO.getPrefixNameActiveOnly(em, paPrefixCode);

       }
       catch (Exception e)
       {
          throw new Exception(new StringBuffer("PrefixNameEJBServBean.getPrefixNameActiveOnly : ").append(e.getMessage()).toString());
       }

       return voPrefixName;
    }    
    
}
