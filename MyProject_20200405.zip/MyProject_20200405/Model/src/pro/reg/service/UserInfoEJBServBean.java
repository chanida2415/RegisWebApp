package pro.reg.service;

import javax.annotation.Resource;

import javax.ejb.EJBContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import pro.reg.data.Cmpinfo;

import pro.reg.data.SecUserInfo;

import reg.exception.ApplicationException;

@Stateless(name = "UserInfoEJBServ", mappedName = "UserInfoEJBServ")
@TransactionManagement(TransactionManagementType.BEAN)
public class UserInfoEJBServBean  implements UserInfoEJBServ, UserInfoEJBServLocal
{
  @PersistenceContext(unitName="reg") 
  private EntityManager em;

  @Resource
  private EJBContext context;
  public UserInfoEJBServBean()
  {
  }
  public void insertUserInfo(SecUserInfo poSecUserInfo) throws ApplicationException, Exception
  {
    boolean vbRsl = true;
    try
    {
      System.err.println("37 Bean");
        
      context.getUserTransaction().begin();
      UserInfoDAO voUserInfoDAO = new UserInfoDAO();
        
      if (poSecUserInfo == null)
      {
        throw new ApplicationException("ข้อมูลไม่ครบถ้วน กรุณาตรวจสอบ");
      }

      else if (poSecUserInfo.getUserId() == null ||poSecUserInfo.getUserId().length() == 0)
      {
        throw new ApplicationException("ข้อมูลไม่ครบถ้วน กรุณาตรวจสอบ");
      }
      else if (poSecUserInfo.getUserId() == null ||poSecUserInfo.getUserId().length() == 0)
      {
        throw new ApplicationException("ข้อมูลไม่ครบถ้วน กรุณาตรวจสอบ");
      }

      if (voUserInfoDAO.validateUserInfoForInsert(em,poSecUserInfo.getUserId()) == false)
      {
        voUserInfoDAO.insertUserInfo(em, poSecUserInfo);
      }
      else
      {
        throw new ApplicationException("มีข้อมูลในระบบแล้ว ไม่สามารถเพิ่มได้");
      }
      vbRsl = true;
      System.err.println("84 Bean");
      context.getUserTransaction().commit();

    }
    catch (ApplicationException ae)
    {
      context.getUserTransaction().rollback();
      throw new ApplicationException(ae.getMessage());
    }
    catch (Exception e)
    {
      context.getUserTransaction().rollback();
      throw new Exception(e.getMessage());
    }
    
  }
  
}
