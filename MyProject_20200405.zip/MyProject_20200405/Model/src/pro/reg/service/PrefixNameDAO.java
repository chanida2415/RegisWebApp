package pro.reg.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import pro.reg.data.PrefixName;

public class PrefixNameDAO
{
    public PrefixNameDAO()
    {
        super();
    }
    public List<PrefixName> searchPrefixNameActiveOnly(EntityManager em, String paPrefixCode, String paPrefixName, String paSortOrder) throws Exception
    {
       StringBuffer jpqlStmt = new StringBuffer();
       jpqlStmt.append(" SELECT prefixName   ");
       jpqlStmt.append(" FROM PrefixName prefixName ");
       jpqlStmt.append(" WHERE prefixName.recStatus <> 0  ");

       if (paPrefixCode != null && paPrefixCode.length() > 0)
       {
          jpqlStmt.append(" AND prefixName.prefixCode = ?1  ");
       }

       if (paPrefixName != null && paPrefixName.length() > 0)
       {
          jpqlStmt.append(" AND prefixName.prefixName LIKE CONCAT(CONCAT('%', ?2), '%')  ");
       }


       if (paSortOrder != null && paSortOrder.length() > 0)
       {
          jpqlStmt.append(paSortOrder);
       }
       else
       {
          jpqlStmt.append(" ORDER BY prefixName.prefixCode ");
       }

       Query voQuery = em.createQuery(jpqlStmt.toString());

       if (paPrefixCode != null && paPrefixCode.length() > 0)
       {
          voQuery.setParameter(1, paPrefixCode);
       }

       if (paPrefixName != null && paPrefixName.length() > 0)
       {
          voQuery.setParameter(2, paPrefixName);
       }


       return voQuery.getResultList();
    }

    public PrefixName getPrefixNameActiveOnly(EntityManager em, String paCrdTypCde) throws Exception
    {
       StringBuffer jpqlStmt = new StringBuffer();
       jpqlStmt.append(" SELECT prefixName   ");
       jpqlStmt.append(" FROM PrefixName prefixName ");
       jpqlStmt.append(" WHERE prefixName.recStatus <> 0 ");
       jpqlStmt.append(" AND prefixName.prefixCode = ?1 ");

       Query voQuery = em.createQuery(jpqlStmt.toString());
       voQuery.setParameter(1, paCrdTypCde);

       PrefixName voPrefixName = null;
       List voList = voQuery.getResultList();
       if (voList != null && voList.size() != 0)
       {
          voPrefixName = (PrefixName)voList.get(0);
       }

       return voPrefixName;
    }    
}
