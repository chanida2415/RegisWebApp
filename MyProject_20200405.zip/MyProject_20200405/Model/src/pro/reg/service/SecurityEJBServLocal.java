package pro.reg.service;

import javax.ejb.Local;

import pro.reg.data.SecUserInfo;

@Local
public interface SecurityEJBServLocal {
 int authenticate(SecUserInfo voSecUserInfo) throws Exception;
    UserContext getSecUserInfo(String paUserId,String vaIPAddress) throws Exception;

}
