package pro.reg.service;

import javax.ejb.Remote;

import pro.reg.data.SecChangePassword;

import reg.exception.ApplicationException;

@Remote
public interface changePasswordEJBServ
{
  void insertChangePassword(SecChangePassword poSecChangePassword) throws ApplicationException, Exception;
}
