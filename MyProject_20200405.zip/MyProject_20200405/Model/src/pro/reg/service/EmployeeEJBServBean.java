package pro.reg.service;

import javax.annotation.Resource;

import javax.ejb.EJBContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import pro.reg.data.EmployeeInfo;

import pro.util.SearchResult;

import reg.exception.ApplicationException;

@Stateless(name = "EmployeeEJBServ", mappedName = "EmployeeEJBServ")
@TransactionManagement(TransactionManagementType.BEAN)
public class EmployeeEJBServBean implements EmployeeEJBServ, EmployeeEJBServLocal
{
    @PersistenceContext(unitName="reg") 
    private EntityManager em;

    @Resource
    private EJBContext context;
    
    public EmployeeInfo getEmployee(String paCitizenId) throws Exception
    {
      return em.find(EmployeeInfo.class, paCitizenId);
    }
    public SearchResult<EmployeeInfo> searchEmployee(String paCompanyId, String paFristname,String paLastname, String paCitizenId, String paSortOrder, int pnPageNumber,byte pnRowPerPage) throws Exception
    { 
      
      SearchResult<EmployeeInfo> voEmployeeList = null;
      EmployeeDAO voEmployeeDAO = new EmployeeDAO();
      try
      {
        voEmployeeList = voEmployeeDAO.searchEmployee(em, paCompanyId, paFristname, paLastname, paCitizenId, paSortOrder, pnPageNumber, pnRowPerPage);
      }
      catch (Exception e)
      {
        throw new Exception(new StringBuffer("EmployeeEJBServBean.searchEmployee : ").append(e.getMessage()).toString());
      }
      return voEmployeeList;
    }
    public void insertEmployeeInfo(EmployeeInfo poEmployeeInfo) throws ApplicationException, Exception
    {
      boolean vbRsl = true;
      try
      {         
        context.getUserTransaction().begin();
        EmployeeDAO voEmployeeDAO = new EmployeeDAO();
          
        if (poEmployeeInfo == null)
        {
          throw new ApplicationException("ข้อมูลไม่ครบถ้วน กรุณาตรวจสอบ");
        }

        else if (poEmployeeInfo.getCitizenId() == null ||poEmployeeInfo.getCitizenId().length() == 0)
        {
          throw new ApplicationException("ข้อมูลไม่ครบถ้วน กรุณาตรวจสอบ");
        }


        if (voEmployeeDAO.validateEmployeeForInsert(em,poEmployeeInfo.getCitizenId()) == false)
        {
          voEmployeeDAO.insertEmployeeInfo(em, poEmployeeInfo);
        }
        else
        {
          throw new ApplicationException("มีข้อมูลในระบบแล้ว ไม่สามารถเพิ่มได้");
        }
        vbRsl = true;
        System.err.println("84 Bean");
        context.getUserTransaction().commit();

      }
      catch (ApplicationException ae)
      {
        context.getUserTransaction().rollback();
        throw new ApplicationException(ae.getMessage());
      }
      catch (Exception e)
      {
        context.getUserTransaction().rollback();
        throw new Exception(e.getMessage());
      }
      
    }
    
    public void updateEmployees(EmployeeInfo poEmployeeInfo) throws Exception
    {
        EmployeeDAO voEmployeeDAO = new EmployeeDAO();
      boolean vbRsl = false;
      try
      {
        context.getUserTransaction().begin();

       
        if (voEmployeeDAO.validateEmployeeForUpdate(em,poEmployeeInfo.getCitizenId())== true)
        {
          voEmployeeDAO.updateEmployeeInfo(em ,poEmployeeInfo);
        }
        else
        {
            throw new ApplicationException("ไม่พบข้อมูล <b>" + poEmployeeInfo.getCitizenId() + "</b> ในระบบ");
        }
        vbRsl = true;
      
        context.getUserTransaction().commit();
        // return vnEmail;    
      }
      catch (ApplicationException ae)
      {
        context.getUserTransaction().rollback();
        throw new ApplicationException(ae.getMessage());
      }
      catch (Exception e)
      {
        context.getUserTransaction().rollback();
        throw new Exception(e.getMessage());
      }
      
    }
    public void deleteEmployee(EmployeeInfo poEmployeeInfo) throws Exception 
    {
      EmployeeDAO voEmployee = new EmployeeDAO();
      try
      {
         context.getUserTransaction().begin();
         
         int a = voEmployee.deleteEmployee(em, poEmployeeInfo);
        if(a == 0)
        {
          throw new ApplicationException("ไม่สามารถลบข้อมูลได้");
        }
         context.getUserTransaction().commit();
      }
          
      catch (ApplicationException ae)
      {
        context.getUserTransaction().rollback();
        throw new ApplicationException(ae.getMessage());
      }
      catch(Exception e)
      {
         try
         {
            context.getUserTransaction().rollback();
         }
         catch(Exception ee){System.out.println();}
         throw new Exception(new StringBuffer("EmployeeEJBServBean.deleteEmployee : ").append(e.getMessage()).toString()) ;
      }
    }
}
