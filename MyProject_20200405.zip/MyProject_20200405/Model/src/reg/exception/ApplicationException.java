package reg.exception;


public class ApplicationException extends  java.lang.Exception
{
   public ApplicationException()
   {
   }
   
   public ApplicationException(String s)
   {
      super(s);
   }
}
